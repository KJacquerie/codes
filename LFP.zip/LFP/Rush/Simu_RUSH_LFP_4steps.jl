# Defines output directory
#saved file name
file_name = "Rush"
test_name = "LFP"
const gamma_mat = [0.05]#[0. 0.1 0.2 ]

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf
using DSP

# Include DCN model
include("RUSH_LFP_4steps.jl")
include("RUSH_PARAMS_4steps.jl")



# Simulation parameters
const T = 42000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const Ttransient = 1001
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C = 1.

const VNa = 55.
const VK = -85.
const VCa = 120.
const tetas= -63
const ks= -7.8
const tetah = -72.
const kh = 1.1
const sigm = 10.3
const sign = 9.3
const teta = 1

# Model parameters (mean) - Ecells
const gNa_E = 120.
const gKd_E = 10.
const gNaleak_E = 0.01429
const gKleak_E = 0.08571
const gCaT_E = 0.3

# Model parameters (mean) - Icells
const gNa_I = 120.
const gKd_I = 10.
const gNaleak_I = 0.01429
const gKleak_I = 0.08571
const gCaT_I = 0.3


# Simulations
const nEcells = 150 # Number of excitatory cells
const nIcells = 150 # Number of inhibitory cells
const ncells = nEcells+nIcells

#simulateTOY_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)
const IappE = 0.
const IstepE = 0.
const tstepEinit = 21500
const tstepEfinal = 21503
const IappI = 15.
const IstepI1 = -16.2
const IstepI2 = -16.2
const IstepI3 = -16.2
const IstepI4 = -16.2
const tstepIinit1 = 21000
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

#@time (Vnoconnect, LFPnoconnect_E, LFPnoconnect_I) = simulateTOY_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepinit,tstepfinal,IstepE,IstepI,0.,0.,0.,0.,0.,0.)
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells #1

const n_net = 1

const SPB_depol1 = zeros(ncells,n_net)
const SPB_hyperpol1 = zeros(ncells,n_net)
const PER_depol1 = zeros(ncells,n_net)
const PER_hyperpol1 = zeros(ncells,n_net)
const DC_depol1 = zeros(ncells,n_net)
const DC_hyperpol1 = zeros(ncells,n_net)
const IBF_depol1 = zeros(ncells,n_net)
const IBF_hyperpol1 = zeros(ncells,n_net)
const freq_depol_vec1 = zeros(ncells,n_net)
const freq_hyperpol_vec1 = zeros(ncells,n_net)
const Vconnect_spk = zeros(ncells,T)




for i=1:length(gamma_mat)
    gamma = gamma_mat[i]
    println("gamma=",gamma)
    #cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/LFP/%s/Results_%s/n%d/gamma%d/",file_name, test_name,ncells, gamma*100))
    cd(@sprintf("/Volumes/SSD250/PhD/2020-Project/LFP/%s/Results_%s/n%d/gamma%d/",file_name, test_name,ncells, gamma*100))


    C_vec = C.*ones(ncells)#(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKdvec_E = gKd_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNaleakvec_E = gNaleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKleakvec_E = gKleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gCaTvec_E = gCaT_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKdvec_I = gKd_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNaleakvec_I = gNaleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKleakvec_I = gKleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gCaTvec_I = gCaT_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    @time (Vconnect_spk, LFPconnect_E, LFPconnect_I)  = simulateRUSH_ncells_spk(gamma, ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB,gNavec_E, gKdvec_E, gNaleakvec_E, gKleakvec_E, gCaTvec_E, gNavec_I, gKdvec_I, gNaleakvec_I, gKleakvec_I, gCaTvec_I,C_vec)
    responsetype = Lowpass(100; fs=1000/(dt))
    designmethod = Butterworth(4)
    LFPconnect_E_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_E)
    LFPconnect_I_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_I)

    index = gamma*100
    writedlm(@sprintf("LFP_E_%d.dat",index), LFPconnect_E_filt, header = false)
    writedlm(@sprintf("LFP_I_%d.dat",index), LFPconnect_I_filt, header = false)

    j=1
    (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)

    SPB_depol1[:,j] = PARAMS_depol[:,1]
    SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
    PER_depol1[:,j] = PARAMS_depol[:,2]
    PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
    DC_depol1[:,j] = PARAMS_depol[:,3]
    DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
    IBF_depol1[:,j] = PARAMS_depol[:,4]
    IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
    freq_depol_vec1[:,j] = freq_depol
    freq_hyperpol_vec1[:,j] = freq_hyperpol

    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)

end
