# Defines output directory
file_name="Drion100";
test_name="LFP"
const gamma_mat=[0.2]

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf
using DSP

# Include DCN model
include("Drion_LFP_plot_cells.jl")
include("Drion_PARAMS_4steps.jl")


# Simulation parameters
const T = 4000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Ttransient= 101
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)
const fcutoff = 100

# Model parameters (global)
const C = 1.
const VNa = 50
const VK = -85
const VCa = 120
const Vl = -55
const VH = -20
const Kd = 170

# Model parameters (mean) - Ecells
const gl_E = 0.055
const gNa_E = 170
const gKd_E = 40
const k1_E = 1.e-1
const k2_E = 0.1e-1
const gH_E = 0.01
const gKCa_E = 4
const gCaT_E = 0.55

# Model parameters (mean) - Icells
const gl_I = 0.055
const gNa_I = 170
const gKd_I = 40
const k1_I = 1.e-1
const k2_I = 0.1e-1
const gH_I = 0.01
const gKCa_I = 4
const gCaT_I = 0.55

# Simulations
const nEcells = 5 # Number of excitatory cells
const nIcells = 5 # Number of inhibitory cells
const ncells = nEcells+nIcells

# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 550
const tstepEfinal = 553
const IappI = 1.
const IstepI1 = -3.6
const IstepI2 = -3.6
const IstepI3 = -3.6
const IstepI4 = -3.6
const tstepIinit1 = 500
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

# Synaptic connections
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells


const n_net = 1


const SPB_depol1 = zeros(ncells,n_net)
const SPB_hyperpol1 = zeros(ncells,n_net)
const PER_depol1 = zeros(ncells,n_net)
const PER_hyperpol1 = zeros(ncells,n_net)
const DC_depol1 = zeros(ncells,n_net)
const DC_hyperpol1 = zeros(ncells,n_net)
const IBF_depol1 = zeros(ncells,n_net)
const IBF_hyperpol1 = zeros(ncells,n_net)
const freq_depol_vec1 = zeros(ncells,n_net)
const freq_hyperpol_vec1 = zeros(ncells,n_net)
const Vconnect_spk = zeros(ncells,T)

for i=1:length(gamma_mat)
    gamma = gamma_mat[i]
    println("gamma=",gamma)
    cd(@sprintf("/Volumes/SSD250/PhD/2020-Project/LFP/%s/V/",file_name))

    #function simu_LFP_ncells(n_net::int64, ncells::Int64, nEcells::Int64, nIcells::Int64,IappE::Float64,IappI::Float64,tstepEinit::Int64,tstepEfinal::Int64,IstepE::Float64,tstepIinit1::Int64,tstepIinit2::Int64,tstepIinit3::Int64,tstepIinit4::Int64,tstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEEAMPA::Float64,gEIAMPA::Float64,gIEGABAA::Float64,gIIGABAA::Float64,gIEGABAB::Float64,gIIGABAB::Float64)
        # array initilisation
        SPB_depol1 = zeros(ncells,n_net)
        SPB_hyperpol1 = zeros(ncells,n_net)
        PER_depol1 = zeros(ncells,n_net)
        PER_hyperpol1 = zeros(ncells,n_net)
        DC_depol1 = zeros(ncells,n_net)
        DC_hyperpol1 = zeros(ncells,n_net)
        IBF_depol1 = zeros(ncells,n_net)
        IBF_hyperpol1 = zeros(ncells,n_net)
        freq_depol_vec1 = zeros(ncells,n_net)
        freq_hyperpol_vec1 = zeros(ncells,n_net)

        C_vec = C*ones(ncells)#(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gNavec_E = gNa_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gKdvec_E = gKd_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gHvec_E = gH_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gCaTvec_E = gCaT_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gKCavec_E = gKCa_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        glvec_E = gl_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        k1vec_E = k1_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        k2vec_E = k2_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

        gNavec_I = gNa_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gKdvec_I = gKd_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gHvec_I = gH_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gCaTvec_I = gCaT_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        gKCavec_I = gKCa_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        glvec_I = gl_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        k1vec_I = k1_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
        k2vec_I = k2_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))



        @time (VV, Vconnect_spk,  LFPconnect_E, LFPconnect_I) = simulateTOY_ncells(gamma, ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB, gNavec_E, gKdvec_E, gHvec_E, gCaTvec_E, gKCavec_E, glvec_E, k1vec_E, k2vec_E, gNavec_I, gKdvec_I, gHvec_I, gCaTvec_I, gKCavec_I, glvec_I, k1vec_I, k2vec_I, C_vec)

        responsetype = Lowpass(fcutoff; fs=1000/(dt))
        designmethod = Butterworth(4)
        LFPconnect_E_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_E)
        LFPconnect_I_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_I)

        index = gamma*100
        writedlm(@sprintf("LFP_E_%d.dat", index), LFPconnect_E_filt, header = false)
        writedlm(@sprintf("LFP_I_%d.dat", index), LFPconnect_I_filt, header = false)
        writedlm(@sprintf("V%d.dat", index), VV, header = false)

         j=1
         (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)

         SPB_depol1[:,j] = PARAMS_depol[:,1]
         SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
         PER_depol1[:,j] = PARAMS_depol[:,2]
         PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
         DC_depol1[:,j] = PARAMS_depol[:,3]
         DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
         IBF_depol1[:,j] = PARAMS_depol[:,4]
         IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
         freq_depol_vec1[:,j] = freq_depol
         freq_hyperpol_vec1[:,j] = freq_hyperpol

         writedlm("SPB_depol1.dat", SPB_depol1, header = false)
         writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
         writedlm("PER_depol1.dat", PER_depol1, header = false)
         writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
         writedlm("DC_depol1.dat", DC_depol1, header = false)
         writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
         writedlm("IBF_depol1.dat", IBF_depol1, header = false)
         writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
         writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
         writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)

end
