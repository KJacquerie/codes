# gating functions
boltz(V::Float64,A::Float64,B::Float64) = 1/(1 + exp((V+A)/B))
tauX(V::Float64,A::Float64,B::Float64,D::Float64,E::Float64) = A - B/(1+exp((V+D)/E))
mNainf(V::Float64) = boltz(V,35.5,-5.29)
taumNa(V::Float64) = tauX(V,1.32,1.26,120.,-25.)
hNainf(V::Float64) = boltz(V,48.9,5.18)
tauhNa(V::Float64) = (0.67/(1+exp((V+62.9)/-10.0)))*(1.5 + 1/(1+exp((V+34.9)/3.6)))
mKdinf(V::Float64) = boltz(V,12.3,-11.8)
taumKd(V::Float64) = tauX(V,7.2,6.4,28.3,-19.2)
mCaTinf(V::Float64) = boltz(V,67.1,-7.2)
taumCaT(V::Float64) = tauX(V,21.7,21.3,68.1,-20.5)
hCaTinf(V::Float64) = boltz(V,80.1,5.5)
tauhCaT(V::Float64) = 2*tauX(V,205.,89.8,55.,-16.9)
mHinf(V::Float64) = boltz(V,80.,6.)
taumH(V::Float64) = tauX(V,272.,-1149.,42.2,-8.73)
mKCainf(Ca::Float64) = (Ca/(Ca+Kd))^2
Tm(V::Float64) = 1/(1+exp(-(V-2)/5))

ICaT(V::Float64,mCaT::Float64,hCaT::Float64,gCaT::Float64) = gCaT*mCaT^3*hCaT*(V-VCa)

function dV(gNa::Float64, gKd::Float64, gl::Float64, V::Float64, mNa::Float64, hNa::Float64, mKd::Float64, mCaT::Float64, hCaT::Float64, mH::Float64, Ca::Float64, Iapp::Float64, Istep::Float64, gCaT::Float64, gH::Float64, gKCa::Float64, C::Float64)
  (dt)*(1/C)*(-gNa*mNa^3*hNa*(V-VNa) -gKd*mKd^4*(V-VK) -gl*(V-Vl) -ICaT(V,mCaT,hCaT,gCaT) -gKCa*mKCainf(Ca)*(V-VK) -gH*mH*(V-VH) +Iapp +Istep)
end

dmNa(V::Float64,mNa::Float64) = (dt)*((1/taumNa(V))*(mNainf(V) - mNa))
dhNa(V::Float64,hNa::Float64) = (dt)*((1/tauhNa(V))*(hNainf(V) - hNa))
dmKd(V::Float64,mKd::Float64) = (dt)*((1/taumKd(V))*(mKdinf(V) - mKd))
dmCaT(V::Float64,mCaT::Float64) = (dt)*((1/taumCaT(V))*(mCaTinf(V) - mCaT))
dhCaT(V::Float64,hCaT::Float64) = (dt)*((1/tauhCaT(V))*(hCaTinf(V) - hCaT))
dmH(V::Float64,mH::Float64) = (dt)*((1/taumH(V))*(mHinf(V) - mH))
dCa(V::Float64,mCaT::Float64,hCaT::Float64,Ca::Float64,gCaT::Float64,k1::Float64,k2::Float64) = (dt)*(-k1*ICaT(V,mCaT,hCaT,gCaT) -k2*Ca)
dAMPA(V::Float64,AMPA::Float64) = (dt)*(1.1*Tm(V)*(1-AMPA)-0.19*AMPA)
dGABAA(V::Float64,GABAA::Float64) = (dt)*(0.53*Tm(V)*(1-GABAA)-0.18*GABAA)
dGABAB(V::Float64,GABAB::Float64) = (dt)*(0.016*Tm(V)*(1-GABAB)-0.0047*GABAB)

function simulateTOY_ncells(gamma::Float64,ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,TstepEinit::Int64,TstepEfinal::Int64,IstepE::Float64,TstepIinit1::Int64,TstepIinit2::Int64,TstepIinit3::Int64,TstepIinit4::Int64,TstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64, gNavec_E::Array{Float64}, gKdvec_E::Array{Float64}, gHvec_E::Array{Float64}, gCaTvec_E::Array{Float64}, gKCavec_E::Array{Float64}, glvec_E::Array{Float64}, k1vec_E::Array{Float64}, k2vec_E::Array{Float64}, gNavec_I::Array{Float64}, gKdvec_I::Array{Float64}, gHvec_I::Array{Float64}, gCaTvec_I::Array{Float64}, gKCavec_I::Array{Float64}, glvec_I::Array{Float64}, k1vec_I::Array{Float64}, k2vec_I::Array{Float64}, C_vec::Array{Float64})

  if(gamma==0.0)



    SYN = [gEE*ones(nEcells,nEcells) gEI*ones(nEcells,nIcells);gIE*ones(nIcells,nEcells) gII*ones(nIcells,nIcells);gIE2*ones(nIcells,nEcells) gII2*ones(nIcells,nIcells)]

  else
        SYN = [(gEE/4)*(rand(nEcells,nEcells)-0.5*ones(nEcells, nEcells)).+gEE (gEI/4)*(rand(nEcells,nIcells)-0.5*ones(nEcells, nIcells)).+gEI;(gIE/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE (gII/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII;(gIE2/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE2 (gII2/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII2]
  end

  # Initial conditions
  V=-60*ones(ncells)
  Vprev=-60*ones(ncells)
  mNa=mNainf(V[1])*ones(ncells)
  hNa=hNainf(V[1])*ones(ncells)
  mKd=mKdinf(V[1])*ones(ncells)
  mCaT=mCaTinf(V[1])*ones(ncells)
  hCaT=hCaTinf(V[1])*ones(ncells)
  mH=mHinf(V[1])*ones(ncells)
  Ca=((-k1_E/k2_E)*ICaT(V[1],mCaT[1],hCaT[1],gCaT_E[1]))*ones(ncells)
  AMPA=zeros(ncells)
  GABAA=zeros(ncells)
  GABAB=zeros(ncells)


  LFP_E=zeros(Tdt)
  LFP_I=zeros(Tdt)


  Spkt = zeros(ncells,T)
  lncells::Array{Int64} = ones(ncells,1)

  # Step start and stop values
  TstartE::Int64 = convert(Int64,TstepEinit/dt)
  TstopE::Int64 = convert(Int64,TstepEfinal/dt)
  TstartI1::Int64 = convert(Int64,TstepIinit1/dt)
  TstartI2::Int64 = convert(Int64,TstepIinit2/dt)
  TstartI3::Int64 = convert(Int64,TstepIinit3/dt)
  TstartI4::Int64 = convert(Int64,TstepIinit4/dt)
  TstopI::Int64 = convert(Int64,TstepIfinal/dt)

  for z = 1:Tdt
    Isyn=zeros(ncells)

    for j = 1:ncells
      ll = copy(lncells[j])

      if j<=nEcells
        Iapp = IappE
        if z >= TstartE && z<= TstopE
          Iappstep = IstepE
        else
          Iappstep = 0.
        end
        V[j] += dV(gNavec_E[j], gKdvec_E[j], glvec_E[j], V[j], mNa[j], hNa[j], mKd[j], mCaT[j], hCaT[j], mH[j], Ca[j], Iapp, Iappstep, gCaTvec_E[j], gHvec_E[j], gKCavec_E[j], C_vec[j])
        Ca[j] += dCa(Vprev[j],mCaT[j],hCaT[j],Ca[j],gCaTvec_E[j],k1vec_E[j], k2vec_E[j])
      end

      if j>nEcells && j<=ncells
        Iapp = IappI
        if z >= TstartI1 && z< TstartI2
          Iappstep = IstepI1
        elseif z >= TstartI2 && z< TstartI3
          Iappstep = IstepI2
        elseif z >= TstartI3 && z< TstartI4
          Iappstep = IstepI3
        elseif z >= TstartI4 && z< TstopI
          Iappstep = IstepI4
        else
          Iappstep = 0.
        end
        V[j] += dV(gNavec_I[j], gKdvec_I[j], glvec_I[j], V[j], mNa[j], hNa[j], mKd[j], mCaT[j], hCaT[j], mH[j], Ca[j], Iapp, Iappstep, gCaTvec_I[j], gHvec_I[j], gKCavec_I[j], C_vec[j])
        Ca[j] += dCa(Vprev[j],mCaT[j],hCaT[j],Ca[j],gCaTvec_I[j],k1vec_I[j], k2vec_I[j])
      end

      for k = 1:nEcells
        if k!=j
          Isyn[j] += SYN[k,j]*AMPA[k]*(Vprev[j]-0)
          V[j] += (dt)*(1/C)*(-SYN[k,j]*AMPA[k]*(Vprev[j]-0))
        end
      end
      for l = nEcells+1:ncells
        if l!=j
          Isyn[j] += SYN[l,j]*GABAA[l]*(Vprev[j]+70)+SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85)
          V[j] += (dt)*(1/C)*(-SYN[l,j]*GABAA[l]*(Vprev[j]+70))
          V[j] += (dt)*(1/C)*(-SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85))
        end
      end

      mNa[j] += dmNa(Vprev[j],mNa[j])
      hNa[j] += dhNa(Vprev[j],hNa[j])
      mKd[j] += dmKd(Vprev[j],mKd[j])
      mCaT[j] += dmCaT(Vprev[j],mCaT[j])
      hCaT[j] += dhCaT(Vprev[j],hCaT[j])
      mH[j] += dmH(Vprev[j],mH[j])

      AMPA[j] += dAMPA(Vprev[j],AMPA[j])
      GABAA[j] += dGABAA(Vprev[j],GABAA[j])
      GABAB[j] += dGABAB(Vprev[j],GABAB[j])

      if Vprev[j] < -20. && V[j] >= -20.
        Spkt[j,ll] = t[z]
        lncells[j] += 1
      end

      Vprev = copy(V)
    end

    #VV[z,:] = copy(V')
    LFP_E[z] = (1/nEcells).*sum(Isyn[1:nEcells])
    LFP_I[z] = (1/nIcells).*sum(Isyn[1+nEcells:ncells])

  end

  return Spkt, LFP_E, LFP_I
  #return  LFP_E, LFP_I
end
