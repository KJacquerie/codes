# Define output directory
file_name = "HM"
test_name = "LFP"
const gamma_mat = [0. 0.1 0.2 ]

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf
using DSP

# Include model
include("HM_LFP_4steps.jl")
include("HM_PARAMS_4steps.jl")

# Simulation parameters
const T = 42000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const Ttransient = 1001
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)


# Model parameters (global)
const C= 0.29 #nF
const VNa = 45
const VCa = 120
const VK = -105

# Model parameters - Ecells
const gNa_E = 12.
const gNap_E = 7.e-3
const gNaleak_E = 2.65e-3
const gA_E = 20.e-3
const gA2_E = 15.e-3
const gKleak_E = 7.e-3
const gK2a_E = 38.e-3
const gK2b_E = 26.e-3
const gc_E = 1.
const gL_E = 0.8
const gT_E= 1.

# Model parameters - Icells
const gNa_I = 12.
const gNap_I = 7.e-3
const gNaleak_I = 2.65e-3
const gA_I = 20.e-3
const gA2_I = 15.e-3
const gKleak_I = 7.e-3
const gK2a_I = 38.e-3
const gK2b_I = 26.e-3
const gc_I = 1.
const gL_I = 0.8
const gT_I= 1.

# Simulations
const nEcells = 150 # Number of excitatory cells
const nIcells = 150 # Number of inhibitory cells
const ncells = nEcells+nIcells

# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 41500
const tstepEfinal = 41503
const IappI = 1.
const IstepI1 = -1.
const IstepI2 = -1.
const IstepI3 = -1.
const IstepI4 = -1.
const tstepIinit1 = 21000
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

#Synaptic connexion
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.01/nEcells
const gIEGABAA = 0.04/nIcells
const gIEGABAB = .01/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

const n_net =1

const SPB_depol1 = zeros(ncells,n_net)
const SPB_hyperpol1 = zeros(ncells,n_net)
const PER_depol1 = zeros(ncells,n_net)
const PER_hyperpol1 = zeros(ncells,n_net)
const DC_depol1 = zeros(ncells,n_net)
const DC_hyperpol1 = zeros(ncells,n_net)
const IBF_depol1 = zeros(ncells,n_net)
const IBF_hyperpol1 = zeros(ncells,n_net)
const freq_depol_vec1 = zeros(ncells,n_net)
const freq_hyperpol_vec1 = zeros(ncells,n_net)
const Vconnect_spk = zeros(ncells,T)


for i=1:length(gamma_mat)
    gamma = gamma_mat[i]
    println("gamma=",gamma)
    cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/LFP/%s/Results_%s/n%d/gamma%d/",file_name, test_name,ncells, gamma*100))

    # Functions

    C_vec = C.*ones(ncells)

    gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNapvec_E = gNap_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNaleakvec_E = gNaleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gAvec_E = gA_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gA2vec_E = gA2_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKleakvec_E = gKleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gK2avec_E = gK2a_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gK2bvec_E = gK2b_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gcvec_E = gc_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gLvec_E = gL_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gTvec_E = gT_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNapvec_I = gNap_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNaleakvec_I = gNaleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gAvec_I = gA_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gA2vec_I = gA2_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKleakvec_I = gKleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gK2avec_I = gK2a_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gK2bvec_I = gK2b_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gcvec_I = gc_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gLvec_I = gL_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gTvec_I = gT_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    @time (Vconnect_spk, LFPconnect_E, LFPconnect_I) = simulateHM_ncells_spk(gamma,ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB,gNavec_E, gNapvec_E, gK2avec_E, gK2bvec_E, gcvec_E, gTvec_E, gLvec_E, gAvec_E, gA2vec_E, gNaleakvec_E, gKleakvec_E, gNavec_I, gNapvec_I, gK2avec_I, gK2bvec_I, gcvec_I, gTvec_I, gLvec_I, gAvec_I, gA2vec_I, gNaleakvec_I, gKleakvec_I, C_vec)
    responsetype = Lowpass(100; fs=1000/(dt))
    designmethod = Butterworth(4)
    LFPconnect_E_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_E)
    LFPconnect_I_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_I)

    index = gamma*100
    writedlm(@sprintf("LFP_E_%d.dat",index), LFPconnect_E_filt, header = false)
    writedlm(@sprintf("LFP_I_%d.dat",index), LFPconnect_I_filt, header = false)

    j=1
    (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)

    SPB_depol1[:,j] = PARAMS_depol[:,1]
    SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
    PER_depol1[:,j] = PARAMS_depol[:,2]
    PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
    DC_depol1[:,j] = PARAMS_depol[:,3]
    DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
    IBF_depol1[:,j] = PARAMS_depol[:,4]
    IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
    freq_depol_vec1[:,j] = freq_depol
    freq_hyperpol_vec1[:,j] = freq_hyperpol

    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)

end
