# gating functions
mCaTinf(V::Float64) = 1/(1+exp(-(V+65)/7.8))
hCaTinf(V::Float64,thetah::Float64,kh::Float64) = 1/(1+exp((V-thetah)/kh))
tauhCaT(V::Float64,thetah::Float64,kh::Float64) = (1/(1+exp((V-thetah)/kh)))*exp((V+162.3)/17.8)+20.0
mHinf(V::Float64) = 1/(1+exp((V+69)/7.1))
taumH(V::Float64) = 1000/(exp((V+66.4)/9.3)+exp(-(V+81.6)/13))
alphan(V::Float64,sigK::Float64) = -0.01*(V+45.7-sigK)/(exp(-0.1*(V+45.7-sigK))-1)
betan(V::Float64,sigK::Float64) = 0.125*exp(-(V+55.7-sigK)/80)
ninf(V::Float64,sigK::Float64) = alphan(V,sigK)/(alphan(V,sigK)+betan(V,sigK))
taun(V::Float64,sigK::Float64) = 1/(alphan(V,sigK)+betan(V,sigK))
alpham(V::Float64,sigNa::Float64) = -0.1*(V+29.7-sigNa)/(exp(-0.1*(V+29.7-sigNa))-1)
betam(V::Float64,sigNa::Float64) = 4*exp(-(V+54.7-sigNa)/18)
minf(V::Float64,sigNa::Float64) = alpham(V,sigNa)/(alpham(V,sigNa)+betam(V,sigNa))

Tm(V::Float64) = 1/(1+exp(-(V-2)/5))

function dV(C::Float64, V::Float64, hCaT::Float64, mH::Float64, n::Float64, Iapp::Float64, Iappstep::Float64, gCaT::Float64, gH::Float64, gKd::Float64, gNa::Float64, gNaP::Float64, gl::Float64)
  (dt)*(1/C)*(-gCaT*mCaTinf(V)^3*hCaT*(V-VCa) -gH*mH^2*(V-VH) -gKd*n^4*(V-VK) -gNa*minf(V,sigNa)^3*(0.85-n)*(V-VNa) -gNaP*minf(V,sigNaP)^3*(V-VNa) - gl*(V-Vl) + Iapp + Iappstep)
end

dhCaT(V::Float64,hCaT::Float64,thetah::Float64,kh::Float64) = (dt)*((2/tauhCaT(V,thetah,kh))*(hCaTinf(V,thetah,kh) - hCaT))
dmH(V::Float64,mH::Float64) = (dt)*((1/taumH(V))*(mHinf(V) - mH))
dn(V::Float64,n::Float64,sigK::Float64) = (dt)*(((200/7)/taun(V,sigK))*(ninf(V,sigK) - n))

dAMPA(V::Float64,AMPA::Float64) = (dt)*(1.1*Tm(V)*(1-AMPA)-0.19*AMPA)
dGABAA(V::Float64,GABAA::Float64) = (dt)*(0.53*Tm(V)*(1-GABAA)-0.18*GABAA)
dGABAB(V::Float64,GABAB::Float64) = (dt)*(0.016*Tm(V)*(1-GABAB)-0.0047*GABAB)

function simulateWANG_ncells_spk(gamma::Float64, ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,TstepEinit::Int64,TstepEfinal::Int64,IstepE::Float64,TstepIinit1::Int64,TstepIinit2::Int64,TstepIinit3::Int64,TstepIinit4::Int64,TstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64, gCaTvec_E::Array{Float64}, gHvec_E::Array{Float64}, gKdvec_E::Array{Float64}, gNavec_E::Array{Float64}, gNaPvec_E::Array{Float64}, glvec_E, gCaTvec_I::Array{Float64}, gHvec_I::Array{Float64}, gKdvec_I::Array{Float64}, gNavec_I::Array{Float64}, gNaPvec_I::Array{Float64}, glvec_I::Array{Float64}, C_vec)

  # Synaptic connections
  if(gamma==0.0)
	SYN = [gEE*ones(nEcells,nEcells) gEI*ones(nEcells,nIcells);gIE*ones(nIcells,nEcells) gII*ones(nIcells,nIcells);gIE2*ones(nIcells,nEcells) gII2*ones(nIcells,nIcells)]
  else
    SYN = [(gEE/4)*(rand(nEcells,nEcells)-0.5*ones(nEcells, nEcells)).+gEE (gEI/4)*(rand(nEcells,nIcells)-0.5*ones(nEcells, nIcells)).+gEI;(gIE/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE (gII/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII;(gIE2/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE2 (gII2/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII2]
  end
  # Initial conditions
  V=-70*ones(ncells)
  Vprev=-70*ones(ncells)
  hCaT=hCaTinf(V[1],thetah,kh)*ones(ncells)
  mH=mHinf(V[1])*ones(ncells)
  n=ninf(V[1],sigK)*ones(ncells)

  AMPA=zeros(ncells)
  GABAA=zeros(ncells)
  GABAB=zeros(ncells)

  Spkt = zeros(ncells,T)
  lncells::Array{Int64} = ones(ncells,1)

  #VV = zeros(Tdt,ncells)
  LFP_E=zeros(Tdt)
  LFP_I=zeros(Tdt)

  # Step start and stop values
  TstartE::Int64 = convert(Int64,TstepEinit/dt)
  TstopE::Int64 = convert(Int64,TstepEfinal/dt)
  TstartI1::Int64 = convert(Int64,TstepIinit1/dt)
  TstartI2::Int64 = convert(Int64,TstepIinit2/dt)
  TstartI3::Int64 = convert(Int64,TstepIinit3/dt)
  TstartI4::Int64 = convert(Int64,TstepIinit4/dt)
  TstopI::Int64 = convert(Int64,TstepIfinal/dt)

  for z = 1:Tdt
    Isyn=zeros(ncells)

    for j = 1:ncells
      ll = copy(lncells[j])

      if j<=nEcells
        Iapp = IappE
        if z >= TstartE && z<= TstopE
          Iappstep = IstepE
        else
          Iappstep = 0.
        end

        V[j] += dV(C_vec[j], V[j], hCaT[j], mH[j], n[j], Iapp, Iappstep, gCaTvec_E[j], gHvec_E[j], gKdvec_E[j], gNavec_E[j], gNaPvec_E[j], glvec_E[j])
      end

      if j>nEcells && j<=ncells
        Iapp = IappI
        if z >= TstartI1 && z< TstartI2
          Iappstep = IstepI1
        elseif z >= TstartI2 && z< TstartI3
          Iappstep = IstepI2
        elseif z >= TstartI3 && z< TstartI4
          Iappstep = IstepI3
        elseif z >= TstartI4 && z< TstopI
          Iappstep = IstepI4
        else
          Iappstep = 0.
        end
        V[j] += dV(C_vec[j], V[j], hCaT[j], mH[j], n[j], Iapp, Iappstep, gCaTvec_I[j], gHvec_I[j], gKdvec_I[j], gNavec_I[j], gNaPvec_I[j], glvec_I[j])
      end

      for k = 1:nEcells
        if k!=j
          Isyn[j] += SYN[k,j]*AMPA[k]*(Vprev[j]-0)
          V[j] += (dt)*(1/C)*(-SYN[k,j]*AMPA[k]*(Vprev[j]-0))
        end
      end
      for l = nEcells+1:ncells
        if l!=j
          Isyn[j] += SYN[l,j]*GABAA[l]*(Vprev[j]+70)+SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85)
          V[j] += (dt)*(1/C)*(-SYN[l,j]*GABAA[l]*(Vprev[j]+70))
          V[j] += (dt)*(1/C)*(-SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85))
        end
      end

      hCaT[j] += dhCaT(Vprev[j],hCaT[j],thetah,kh)
      mH[j] += dmH(Vprev[j],mH[j])
      n[j] += dn(Vprev[j],n[j],sigK)

      AMPA[j] += dAMPA(Vprev[j],AMPA[j])
      GABAA[j] += dGABAA(Vprev[j],GABAA[j])
      GABAB[j] += dGABAB(Vprev[j],GABAB[j])

      if Vprev[j] < -20. && V[j] >= -20.
        Spkt[j,ll] = t[z]
        lncells[j] += 1
      end

      Vprev = copy(V)
    end

    #VV[z,:] = copy(V')
    LFP_E[z] = (1/nEcells).*sum(Isyn[1:nEcells])
    LFP_I[z] = (1/nIcells).*sum(Isyn[1+nEcells:ncells])

  end

  #return VV, LFP_E, LFP_I
  #return (VV, Spkt)
  return Spkt, LFP_E, LFP_I
end
