clear ALL
close all
clc 

% time vector
T = 42000;
dt = 0.01;
Tdt = T/dt;
t = dt:dt:T;

%%
Name = 'Drion100'; 
ncells = 200; 
var = 0; 

% LFP vector
LFP_E_d0 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_E_%d.dat',Name,ncells, var,var));
LFP_I_d0 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_I_%d.dat',Name,ncells, var,var));



%%
Name = 'Drion100'; 
ncells = 200; 
var = 20; 

% LFP vector
LFP_E_d2 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_E_%d.dat',Name,ncells, var,var));
LFP_I_d2 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_I_%d.dat',Name,ncells, var,var));



%%
Name = 'Wang'; 
var = 0; 

LFP_E_w0 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_E_%d.dat',Name,ncells, var,var));
LFP_I_w0 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_I_%d.dat',Name,ncells, var,var));



%%
var = 20; 

LFP_E_w2 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_E_%d.dat',Name,ncells, var,var));
LFP_I_w2 = load(sprintf('../%s/Results_LFP/n%d/gamma%d/LFP_I_%d.dat',Name,ncells, var,var));





%% ZOOM FIGURE
interv = 20500/dt:23000/dt; 
pt=11;
ptx = 6.2; 
pty = 1.75; 
color_vec = [1/256 1/256 1/256]*110;
var = 0; 
Name = 'Drion'; 
figure
plot(t(interv)*1e-3, LFP_I_d0(interv), 'color', color_vec)
xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
ylim([min(LFP_I_d0(interv))-0.4 max(LFP_I_d0(interv))+0.4])
box off
title('')
xticks([21,22])
xticklabels({'0','1'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
yticks([-0.5,0])
yticklabels({'',''})
%b = get(gca,'YTickLabel');
%set(gca,'YTickLabel',b,'fontsize',pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-depsc')
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-dpdf')

%%
pt=11;
var = 20; 
Name = 'Drion'; 
figure
plot(t(interv)*1e-3, LFP_I_d2(interv), 'color', color_vec)
xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
ylim([min(LFP_I_d0(interv))-0.1 max(LFP_I_d0(interv))+0.1])
box off
title('')
xticks([21,22])
xticklabels({'0','1'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
yticks([-0.5,0])
yticklabels({'',''})
%b = get(gca,'YTickLabel');
%set(gca,'YTickLabel',b,'fontsize',pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-depsc')
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-dpdf')
%%
pt=11;
var = 0; 
Name = 'Wang'; 
figure
plot(t(interv)*1e-3, LFP_I_w0(interv), 'color', color_vec)
xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
ylim([min(LFP_I_w0(interv))-0.1 max(LFP_I_w0(interv))+0.1])
box off
title('')
xticks([21,22])
xticklabels({'0','1'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
yticks([-0.5,0])
yticklabels({'',''})
%b = get(gca,'YTickLabel');
%set(gca,'YTickLabel',b,'fontsize',pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-depsc')
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-dpdf')

%%
Name='Wang'; 
var =20; 
figure
plot(t(interv)*1e-3, LFP_I_w2(interv), 'color', color_vec)
xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
ylim([min(LFP_I_w0(interv))-0.1 max(LFP_I_w0(interv))+0.1])
box off
title('')
xticks([21,22])
xticklabels({'0','1'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
yticks([-0.5,0])
yticklabels({'',''})
%b = get(gca,'YTickLabel');
%set(gca,'YTickLabel',b,'fontsize',pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-depsc')
print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-dpdf')


%%
% %% Figure
% Name = 'Drion'; 
% var = 0; 
% figure
% subplot(2,1,1)
% plot(t*1e-3,LFP_E_d0) 
% xticks([0])
% xticklabels({'',''})
% box off
% ylim([min(LFP_E_d0) max(LFP_E_d0)])
% xlim([min(t*1e-3) max(t*1e-3)])
% 
% subplot(2,1,2)
% plot(t*1e-3,LFP_I_d0)
% ylim([min(LFP_I_d0) max(LFP_I_d0)])
% xlim([min(t*1e-3) max(t*1e-3)])
% box off
% title('')
% xticks([21,26])
% xticklabels({'0','5'})
% a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'fontsize',pt)
% %yticks([-20,30])
% %yticklabels({'0','50'})
% %b = get(gca,'YTickLabel');
% %set(gca,'YTickLabel',b,'fontsize',pt)
% set(gcf,'PaperPositionMode','auto');
% set(gcf, 'PaperUnits', 'centimeters');
% set(gcf, 'PaperPosition', [0 0 8 5]);
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-depsc')
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-dpdf')
% 
% 
% %%
% Name = 'Drion'; 
% var = 20; 
% figure
% subplot(2,1,1)
% plot(t*1e-3,LFP_E_d2) 
% xticks([0])
% xticklabels({'',''})
% box off
% ylim([min(LFP_E_d2) max(LFP_E_d2)])
% xlim([min(t*1e-3) max(t*1e-3)])
% 
% subplot(2,1,2)
% plot(t*1e-3,LFP_I_d2)
% ylim([min(LFP_I_d2) max(LFP_I_d2)])
% xlim([min(t*1e-3) max(t*1e-3)])
% box off
% title('')
% xticks([21,26])
% xticklabels({'0','5'})
% a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'fontsize',pt)
% %yticks([-20,30])
% %yticklabels({'0','50'})
% %b = get(gca,'YTickLabel');
% %set(gca,'YTickLabel',b,'fontsize',pt)
% set(gcf,'PaperPositionMode','auto');
% set(gcf, 'PaperUnits', 'centimeters');
% set(gcf, 'PaperPosition', [0 0 8 5]);
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-depsc')
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-dpdf')
% 
% %% Figure
% Name = 'Wang'; 
% var = 0; 
% figure
% subplot(2,1,1)
% plot(t*1e-3,LFP_E_w0) 
% xticks([0])
% xticklabels({'',''})
% box off
% ylim([min(LFP_E_w0) max(LFP_E_w0)])
% xlim([min(t*1e-3) max(t*1e-3)])
% 
% subplot(2,1,2)
% plot(t*1e-3,LFP_I_w0)
% ylim([min(LFP_I_w0) max(LFP_I_w0)])
% xlim([min(t*1e-3) max(t*1e-3)])
% box off
% title('')
% xticks([21,26])
% xticklabels({'0','5'})
% a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'fontsize',pt)
% %yticks([-20,30])
% %yticklabels({'0','50'})
% %b = get(gca,'YTickLabel');
% %set(gca,'YTickLabel',b,'fontsize',pt)
% set(gcf,'PaperPositionMode','auto');
% set(gcf, 'PaperUnits', 'centimeters');
% set(gcf, 'PaperPosition', [0 0 8 5]);
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-depsc')
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-dpdf')
% 
% 
% %%
% Name = 'Wang'; 
% var = 20; 
% figure
% subplot(2,1,1)
% plot(t*1e-3,LFP_E_w2) 
% xticks([0])
% xticklabels({'',''})
% box off
% ylim([min(LFP_E_w2) max(LFP_E_w2)])
% xlim([min(t*1e-3) max(t*1e-3)])
% 
% subplot(2,1,2)
% plot(t*1e-3,LFP_I_w2)
% ylim([min(LFP_I_w2) max(LFP_I_w2)])
% xlim([min(t*1e-3) max(t*1e-3)])
% box off
% title('')
% xticks([21,26])
% xticklabels({'0','5'})
% a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'fontsize',pt)
% %yticks([-20,30])
% %yticklabels({'0','50'})
% %b = get(gca,'YTickLabel');
% %set(gca,'YTickLabel',b,'fontsize',pt)
% set(gcf,'PaperPositionMode','auto');
% set(gcf, 'PaperUnits', 'centimeters');
% set(gcf, 'PaperPosition', [0 0 8 5]);
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-depsc')
% print(sprintf('Figures/V/LFPtrace%s_%d', Name, var),'-dpdf')
