% clc
% clear all 
% close all 

%%
Name = 'Drion100'; 
var = 0; 
T = 4000;
dt = 0.01;
Tdt = T/dt;
t = dt:dt:T;

%[V0, LFP_E0, LFP_I0] = load_data(Name, 0);
%[V20, LFP_E20, LFP_I20] = load_data(Name, 20);

plot_trace(V0, t, 'Drion', 0); 
plot_LFP(LFP_E0, LFP_I0, t, 'Drion', 0); 
plot_trace(V20, t, 'Drion', 20); 
plot_LFP(LFP_E20, LFP_I20, t, 'Drion', 20); 

%%
function [V, LFP_E, LFP_I]= load_data(Name, var)
    V =load(sprintf('../%s/V/V%d.dat',Name,var));
    LFP_E = load(sprintf('../%s/V/LFP_E_%d.dat',Name,var));
    LFP_I = load(sprintf('../%s/V/LFP_I_%d.dat',Name,var));
end

%%
function plot_trace(V, t, Name, var)
    ncells = size(V,2);
    figure
    pt=11; 
    for i=2:1:ncells-1
        subplot(ncells,1,i)
        plot(t,V(:,i))
        box off
        set(gca,'visible','off')
        %set(gca,'xtick',[])
        %set(gca,'XColor', 'none','YColor','none')
    %     if (i==ncells)
    %         set(gca,'visible','on')
    %         xticks([0,500])
    %         xticklabels({'0','500'})
    %         a = get(gca,'XTickLabel');
    %         set(gca,'XTickLabel',a,'fontsize',pt)
    %         set(gca,'ytick',[])
    %     end
    end

    %xlim([min(t)-100 max(t)+100])
    %ylim([min(LFP_I_d0(20000/dt:23000/dt))-0.1 max(LFP_I_d0(20000/dt:23000/dt))+0.1])
    box off
    title('')
    xticks([2100,2600])
    xticklabels({'500','1000'})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    %yticks([-20,30])
    %yticklabels({'0','50'})
    %b = get(gca,'YTickLabel');
    %set(gca,'YTickLabel',b,'fontsize',pt)
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 8 5]);
    print(sprintf('Figures/V/V%s_%d', Name, var),'-depsc')
    print(sprintf('Figures/V/V%s_%d', Name, var),'-dpdf')
end

function plot_LFP(LFP_E, LFP_I,t,  Name, var)
    figure
    subplot(2,1,1)
    plot(t, LFP_E)
    set(gca,'visible','off')
    box off
    subplot(2,1,2)
    plot(t,LFP_I)
    set(gca,'visible','off')
    box off
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 8 5]);
    print(sprintf('Figures/V/LFPcells%s_%d', Name, var),'-depsc')
    print(sprintf('Figures/V/LFPcells%s_%d', Name, var),'-dpdf')

end

function plot_spect(LFP,dt,  Name, var)
    noverlap =250/dt; 
    window = 750/dt; 
    fs=1000/dt;
    SNR = 20; 
    freq_max = 5e-3;

    figure(3)
    spectrogram(LFP,window,noverlap,[],fs,'MinThreshold',-SNR,'yaxis')
    ylim([0 freq_max])
end

