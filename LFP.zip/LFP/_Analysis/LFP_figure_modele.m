%LFP figure pour tous les modeles

clear ALL
close all
clc 

gamma = [0 10 20]; 
%noverlap = 1000/dt; 
%window = 5000/dt;
% fs=1000/dt;
% PARAM: Name, ncells, var, dt, freq-max, SNR


%% DRION

for j=1:1:3
    for i=1:1:3
        LFP_figure('Drion100',100, gamma(i), 0.01, 5e-3, 30)
        LFP_figure('Drion100',200, gamma(i), 0.01, 5e-3, 30)
    end
end
%%
LFP_figure('Drion100',300, gamma(1), 0.01, 5e-3, 30)
LFP_figure('Drion100',300, gamma(2), 0.01, 5e-3, 30)
LFP_figure('Drion100',300, gamma(3), 0.01, 5e-3, 30)

%% Destexhe
%n=100
LFP_figure('Destexhe',100, gamma(1), 0.005, 5e-3, 65)
LFP_figure('Destexhe',100, gamma(2), 0.005, 5e-3, 70)
LFP_figure('Destexhe',100, gamma(3), 0.005, 5e-3, 75)
%%
%n=200
LFP_figure('Destexhe',200, gamma(1), 0.005, 5e-3, 65)
LFP_figure('Destexhe',200, gamma(2), 0.005, 5e-3, 70)
LFP_figure('Destexhe',200, gamma(3), 0.005, 5e-3, 75)
%%
%n=300
LFP_figure('Destexhe',300, gamma(1), 0.005, 5e-3, 65)
LFP_figure('Destexhe',300, gamma(2), 0.005, 5e-3, 70)
LFP_figure('Destexhe',300, gamma(3), 0.005, 5e-3, 75)

%% Destexhe98
%n=100
LFP_figure('Destexhe98', 100, gamma(1), 0.005, 10e-3, 90)
LFP_figure('Destexhe98', 100, gamma(2), 0.005, 10e-3, 90)
LFP_figure('Destexhe98', 100, gamma(3), 0.005, 10e-3, 90)
%%
%n=200
LFP_figure('Destexhe98', 200, gamma(1), 0.005, 10e-3, 90)
LFP_figure('Destexhe98', 200, gamma(2), 0.005, 10e-3, 90)
LFP_figure('Destexhe98', 200, gamma(3), 0.005, 10e-3, 90)
%%
%n=300
LFP_figure('Destexhe98', 300, gamma(1), 0.005, 10e-3, 90)
LFP_figure('Destexhe98', 300, gamma(2), 0.005, 10e-3, 90)
LFP_figure('Destexhe98', 300, gamma(3), 0.005, 10e-3, 90)

%% Destexheu98
%n=100
LFP_figure('Destexheu98', 100, gamma(1), 0.005, 5e-3, 30)
LFP_figure('Destexheu98', 100, gamma(2), 0.005, 5e-3, 30)
LFP_figure('Destexheu98', 100, gamma(3), 0.005, 5e-3, 30)
%%
%n=200
LFP_figure('Destexheu98', 200, gamma(1), 0.005, 5e-3, 30)
LFP_figure('Destexheu98', 200, gamma(2), 0.005, 5e-3, 30)
LFP_figure('Destexheu98', 200, gamma(3), 0.005, 5e-3, 30)
%%
%n=300
LFP_figure('Destexheu98', 300, gamma(1), 0.005, 5e-3, 30)
LFP_figure('Destexheu98', 300, gamma(2), 0.005, 5e-3, 30)
LFP_figure('Destexheu98', 300, gamma(3), 0.005, 5e-3, 30)

%% HM
%n=100;
LFP_figure('HM',100,  gamma(1), 0.005, 5e-3, 38)
LFP_figure('HM',100,  gamma(2), 0.005, 5e-3, 39)
LFP_figure('HM',100,  gamma(3), 0.005, 5e-3, 58)
%%
LFP_figure('HM',200,  gamma(1), 0.005, 5e-3, 38)
LFP_figure('HM',200,  gamma(2), 0.005, 5e-3, 39)
LFP_figure('HM',200,  gamma(3), 0.005, 5e-3, 60)
%window = 2000/dt au lieu de 5000/dt
%%
LFP_figure('HM',300,  gamma(1), 0.005, 5e-3, 38)
LFP_figure('HM',300,  gamma(2), 0.005, 5e-3, 39)
LFP_figure('HM',300,  gamma(3), 0.005, 8e-3, 75)
%window = 2000/dt au lieu de 5000/dt

%% WANG
%n=100
LFP_figure('Wang', 100, gamma(1), 0.01, 10e-3, 40)
LFP_figure('Wang', 100, gamma(2), 0.01, 10e-3, 45)
LFP_figure('Wang', 100, gamma(3), 0.01, 10e-3, 45)

%%
%n=200
LFP_figure('Wang', 200, gamma(1), 0.01, 10e-3, 40)
LFP_figure('Wang', 200, gamma(2), 0.01, 10e-3, 40)
LFP_figure('Wang', 200, gamma(3), 0.01, 10e-3, 65)
%%
%n=300
LFP_figure('Wang', 300, gamma(1), 0.01, 10e-3, 40)
LFP_figure('Wang', 300, gamma(2), 0.01, 10e-3, 40)
LFP_figure('Wang', 300, gamma(3), 0.01, 10e-3, 65)
% 
%% WANGCA
%n=100
LFP_figure('WangCa', 100, gamma(1), 0.01, 8e-3, 30)
LFP_figure('WangCa', 100, gamma(2), 0.01, 8e-3, 30)
LFP_figure('WangCa', 100, gamma(3), 0.01, 8e-3, 30)

%%
%n=200
LFP_figure('WangCa', 200, gamma(1), 0.01, 5e-3, 30)
LFP_figure('WangCa', 200, gamma(2), 0.01, 5e-3, 30)
LFP_figure('WangCa', 200, gamma(3), 0.01, 5e-3, 45)
%%
%n=300
LFP_figure('WangCa', 300, gamma(1), 0.01, 5e-3, 30)
LFP_figure('WangCa', 300, gamma(2), 0.01, 5e-3, 30)
LFP_figure('WangCa', 300, gamma(3), 0.01, 5e-3, 45)

 
%%  RUSH
%n=100
LFP_figure('Rush', 100, gamma(1), 0.005, 5e-3, 25)
LFP_figure('Rush', 100, gamma(2), 0.005, 8e-3, 40)
LFP_figure('Rush', 100, gamma(3), 0.005, 8e-3, 45)
LFP_figure('Rush', 100, 5, 0.005, 8e-3, 40)

%%
%n=200
LFP_figure('Rush', 200, gamma(1), 0.005, 5e-3, 25)
LFP_figure('Rush', 200, 5, 0.005, 8e-3, 40)
LFP_figure('Rush', 200, gamma(2), 0.005, 8e-3, 40)
LFP_figure('Rush', 200, gamma(3), 0.005, 8e-3, 45)
%%
%n=300
LFP_figure('Rush', 300, gamma(1), 0.005, 5e-3, 25)
LFP_figure('Rush', 300, 5, 0.005, 8e-3, 40)
LFP_figure('Rush', 300, gamma(2), 0.005, 8e-3, 40)
LFP_figure('Rush', 300, gamma(3), 0.005, 8e-3, 45)
%% 
% %n=100
LFP_figure('RushCa', 100, gamma(1), 0.005, 5e-3, 25)
LFP_figure('RushCa', 100, gamma(2), 0.005, 8e-3, 40)
LFP_figure('RushCa', 100, gamma(3), 0.005, 8e-3, 45)
LFP_figure('RushCa', 100, 5, 0.005, 5e-3, 25)
%%
%n=200
LFP_figure('RushCa', 200, gamma(1), 0.005, 5e-3, 25)
LFP_figure('RushCa', 200, gamma(2), 0.005, 5e-3, 35)
LFP_figure('RushCa', 200, gamma(3), 0.005, 8e-3, 45)
LFP_figure('RushCa', 200, 5, 0.005, 5e-3, 25)
%%
%n=300
LFP_figure('RushCa', 300, gamma(1), 0.005, 5e-3, 25)
LFP_figure('RushCa', 300, gamma(2), 0.005, 4e-3, 35)
LFP_figure('RushCa', 300, gamma(3), 0.005, 4e-3, 50)
LFP_figure('RushCa', 300, 5, 0.005, 5e-3, 25)


