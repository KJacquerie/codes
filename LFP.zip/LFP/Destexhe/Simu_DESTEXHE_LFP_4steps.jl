# Defines output directory
file_name="Destexhe";
test_name="LFP"
const gamma_mat=[0. 0.1 0.2]

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf
using DSP

# Include DCN model
include("DESTEXHE_LFP_4steps.jl")
include("Destexhe_PARAMS_4steps.jl")

# Simulation parameters
const T = 42000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const Ttransient = 1001
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C = 1e-3 # nF

const VNa = 50.
const VK = -100.
const Vleak=-82
const VCa = 120
const Vtraub=-63.

# Model parameters (mean) - Ecells
const gNa_E = 0.4 # 0.1
const gNaleak_E = 0.
const gKleak_E = 0.
const gleak_E= 5e-5
const gK_E = 0.08 #0.08 /0.01
const gCa_E = 0.006

# Model parameters (mean) - Icells
const gNa_I = 0.4 # 0.1
const gNaleak_I = 0.
const gKleak_I = 0.
const gleak_I= 5e-5
const gK_I = 0.08 #0.01/0.08
const gCa_I = 0.006

# Simulations
const nEcells = 150 # Number of excitatory cells
const nIcells = 150 # Number of inhibitory cells
const ncells = nEcells+nIcells

# Excitation
const IappE = 0.1e-3
const IstepE = 0.
const tstepEinit = 20500
const tstepEfinal = 20503
const IappI = 0.4e-3
const IstepI1 = -0.7e-3
const IstepI2 = -0.7e-3
const IstepI3 = -0.7e-3
const IstepI4 = -0.7e-3
const tstepIinit1 = 21000
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

# Synaptic connections
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1e-3/nEcells
const gIEGABAA = 0.2e-3/nIcells
const gIEGABAB = 1.e-3/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

const n_net = 1

const SPB_depol1 = zeros(ncells,n_net)
const SPB_hyperpol1 = zeros(ncells,n_net)
const PER_depol1 = zeros(ncells,n_net)
const PER_hyperpol1 = zeros(ncells,n_net)
const DC_depol1 = zeros(ncells,n_net)
const DC_hyperpol1 = zeros(ncells,n_net)
const IBF_depol1 = zeros(ncells,n_net)
const IBF_hyperpol1 = zeros(ncells,n_net)
const freq_depol_vec1 = zeros(ncells,n_net)
const freq_hyperpol_vec1 = zeros(ncells,n_net)
const Vconnect_spk = zeros(ncells,T)


for i=1:length(gamma_mat)
    gamma = gamma_mat[i]
    println("gamma=",gamma)
    cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/LFP/%s/Results_%s/n%d/gamma%d/",file_name, test_name,ncells, gamma*100))

    #=
    SPB_depol1 = zeros(ncells,n_net)
    SPB_hyperpol1 = zeros(ncells,n_net)
    PER_depol1 = zeros(ncells,n_net)
    PER_hyperpol1 = zeros(ncells,n_net)
    DC_depol1 = zeros(ncells,n_net)
    DC_hyperpol1 = zeros(ncells,n_net)
    IBF_depol1 = zeros(ncells,n_net)
    IBF_hyperpol1 = zeros(ncells,n_net)
    freq_depol_vec1 = zeros(ncells,n_net)
    freq_hyperpol_vec1 = zeros(ncells,n_net)
    =#

    C_vec = C*ones(ncells)#*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    gNavec_E = gNa_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNaleakvec_E = gNaleak_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKleakvec_E = gKleak_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gleakvec_E= gleak_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKvec_E = gK_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gCavec_E = gCa_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    gNavec_I = gNa_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gNaleakvec_I = gNaleak_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKleakvec_I = gKleak_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gleakvec_I= gleak_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gKvec_I = gK_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gCavec_I = gCa_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    @time (Vconnect_spk, LFPconnect_E, LFPconnect_I) = simulateDESTEXHE_ncells(gamma, ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB, gNavec_E, gNaleakvec_E,gKleakvec_E, gleakvec_E, gKvec_E, gCavec_E, gNavec_I, gNaleakvec_I,gKleakvec_I, gleakvec_I, gKvec_I, gCavec_I, C_vec)

    responsetype = Lowpass(100; fs=1000/(dt))
    designmethod = Butterworth(4)
    LFPconnect_E_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_E)
    LFPconnect_I_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_I)

    index = gamma*100
    writedlm(@sprintf("LFP_E_%d.dat",index), LFPconnect_E_filt, header = false)
    writedlm(@sprintf("LFP_I_%d.dat",index), LFPconnect_I_filt, header = false)

    j=1
    (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)

    SPB_depol1[:,j] = PARAMS_depol[:,1]
    SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
    PER_depol1[:,j] = PARAMS_depol[:,2]
    PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
    DC_depol1[:,j] = PARAMS_depol[:,3]
    DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
    IBF_depol1[:,j] = PARAMS_depol[:,4]
    IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
    freq_depol_vec1[:,j] = freq_depol
    freq_hyperpol_vec1[:,j] = freq_hyperpol

    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)

end
