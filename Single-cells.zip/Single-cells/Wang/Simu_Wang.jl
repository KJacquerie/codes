# Defines output directory
#cd("/Users/kathleen/Documents/2017-2018/TFE/Single-cells/Wang 94 JULIA")
const file_name = "Wang"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include model
include("Wang_model.jl")


# Simulation parameters
const T=2000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = range(dt,T,length=Tdt)

# Model parameters
#const nsimu = 10
#const z = 1.
const C = 1.
const VCa = 120.
const VH = -40.
const VK = -80.
const VNa = 55.
const Vl = -70.

const sigK = 10.
const sigNa = 6.
const sigNaP = -5.
const thetah = -79.
const kh = 5.

const gCaT = 1.
const gH = 0.04
const gKd = 30.
const gNa = 42.
const gNaP = 9.
const gl = 0.12

# simulation parameters
#=
const name_expm = "HIB"
Tstepinit = 500
Tstepfinal = T
Iapp = 3.
Istep = -4.3
=#
const name_expm = "PIR"
Tstepinit = 500
Tstepfinal = 1000
Iapp = -2.5
Istep = -2.5


@time y = simulateTC_wang(C,Iapp, Istep, Tstepinit, Tstepfinal,gCaT)
writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s.dat", file_name, name_expm), t, header=false)
writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s.dat", file_name, name_expm), y, header=false)

plot(t,y)
