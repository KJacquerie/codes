# Defines output directory
name="WangMap"

# Loads packages
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView


# Include model
include("Wang_SWITCH.jl")


# Simulation parameters
const T = 7000
const Ttransient = 500

const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,round(Ttransient/dt))

const dt2 = 0.001
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,round(Ttransient/dt2))

const dt3 = 0.0001
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))


# Model parameters
const VCa = 120.
const VH = -40.
const VK = -80.
const VNa = 55.
const Vl = -70.
const sigK = 10.
const sigNa = 6.
const sigNaP = -5.
const thetah = -79.
const kh = 5.
const gH = 0.04
const gKd = 30.
const gNa = 42.
const gNaP = 9.
const gl = 0.12
const gCaT = 1.

# excitation
const T1 = 1500
const T2 = T
const Iapp = 3.
#const Istep = -4.3



Cvec=exp10.(range(1,2, length=10))
Ivec = [-3.2 -3.3 -3.5 -3.7 -3.9 -4.1 -4.3 -4.5 -4.7 -4.9 -5.]
(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)

Cvec1=exp10.(range(0,1, length=10))
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)


Cvec2=exp10.(range(-1,0, length=10))
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3=exp10.(range(-2,-1, length=10))
Ivec3 =  Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end, :];switch1[2:end, :]; switch[2:end, :]]
Cvec_TOT = [Cvec3; Cvec2[2:end, :];Cvec1[2:end, :]; Cvec[2:end, :]]

imshow(switch_TOT, cmap="gray")


writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Wang/Map/Cvec.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Wang/Map/switch_TOT.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Wang/Map/Ivec.dat", Ivec, header=false)
