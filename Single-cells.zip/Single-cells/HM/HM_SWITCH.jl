# gating functions

# sodium activation
alpha_m(V::Float64) = 0.091*(V+38)/(1-exp(-(V+38)/5))
beta_m(V::Float64) = -0.062*(V+38)/(1-exp((V+38)/5))
m_inf(V::Float64) = alpha_m(V) / (alpha_m(V) + beta_m(V))
tau_m(V::Float64) = 1 / (alpha_m(V) + beta_m(V))

# sodium inactivation
alpha_h(V::Float64) = 0.016*exp((-55-V)/15)
beta_h(V::Float64) = 2.07/(exp((17-V)/21)+1)
h_inf(V::Float64) = alpha_h(V) / (alpha_h(V) + beta_h(V))
tau_h(V::Float64) = 1 / (alpha_h(V) + beta_h(V))

# NaP
alpha_mp(V::Float64) = 0.091*(V+38)/(1-exp(-(V+38)/5))
beta_mp(V::Float64) = -0.062*(V+38)/(1-exp((V+38)/5))
mp_inf(V::Float64) = 1/(1+exp((-49-V)/5)) # c'est normal ici que alpha et beta n'apparaissent pas ?
tau_mp(V::Float64) = 1 / (alpha_mp(V) + beta_mp(V))

# A activation
mA_inf(V::Float64) = 1/(1+exp(-(V+60)/8.5))
tau_mA(V::Float64) = 0.37 + 1/(exp((V+35.82)/19.697)+exp((V+79.69)/-12.7))


# A inactivation
hA_inf(V::Float64) = 1/(1+exp((V+78)/6))
function tau_hA(V::Float64)
    if V < -63
        tau_hA = 1/(exp((V+46.05)/5)+exp((V+238.4)/-37.45))
    else
        tau_hA = 19
    end
    return tau_hA
end

# CALCIUM T-type activation
mt_inf(V::Float64) = 1/(1+exp(-(V+57)/6.2))
tau_mt(V::Float64) = 0.612 + 1/(exp(-(V+131.6)/16.7)+exp((V+16.8)/18.2))

# CALCIUM T-Type inactivation
ht_inf(V::Float64) = 1/(1+exp((V+81)/4.03))
function tau_ht(V::Float64)
    if V < -80
        tau_ht = exp((V+467)/66.6)
    else
        tau_ht = exp(-(V+21.88)/10.2)+28
    end
    return tau_ht
end

# Potassium activation
mK2_inf(V::Float64) = 1/(1+exp((V+43)/-17))
tau_mK2(V::Float64) = 1/(exp((V-81)/25.6)+exp((V+132)/-18)) + 9.9

#Potassium inactivation type A
hK2a_inf(V::Float64) = 1/(1+exp((V+58)/10.6))
tau_hK2a(V::Float64) = 1/(exp((V-1.329)/200)+exp((V+130)/-7.1))+120

#Potassium inactivation type B
hK2b_inf(V::Float64) = 1/(1+exp((V+58)/10.6))
function tau_hK2b(V::Float64)
    if V < -70
        tau_hK2b = 1/(exp((V-1.329)/200)+exp((V+130)/-7.1))+120
    else
        tau_hK2b = 8.9
    end
    return tau_hK2b
end


# C-type Potassium
alpha_mc(V::Float64, CaL::Float64) = 2500*CaL*exp(V/24)
beta_mc(V::Float64) = 0.1*exp(-V/24)
mc_inf(V::Float64, CaL::Float64) = alpha_mc(V, CaL) / (alpha_mc(V, CaL) + beta_mc(V))
tau_mc(V::Float64, CaL::Float64) = 1 / (alpha_mc(V, CaL) + beta_mc(V))

# L-Type calcium
alpha_ml(V::Float64) = 1.6/(1+exp(-0.072*(V-5)))
beta_ml(V::Float64) = 0.02*(V-1.31)/(exp((V-1.31)/5.36)-1)
ml_inf(V::Float64) = alpha_ml(V) / (alpha_ml(V) + beta_ml(V))
tau_ml(V::Float64) = 1 / (alpha_ml(V) + beta_ml(V))

# potassium type A2 activation
mA2_inf(V::Float64) = 1/(1+exp(-(V+36)/20))
tau_mA2(V::Float64) = 0.37 + 1/(exp((V+35.82)/19.697)+exp((V+79.69)/-12.7))
#=
function tau_mA2(V::Float64)
    if V < -63
        tau_mA2 = 0.37 + 1/(exp((V+35.82)/19.697)+exp((V+79.69)/-12.7))
    else
        tau_mA2 = 19
    end
    return tau_mA2
end
=#


# potassium type A2 inactivation
hA2_inf(V::Float64) = 1/(1+exp((V+78)/6))
function tau_hA2(V::Float64)
    if V < -73
        tau_hA2 = 1/(exp((V+46.05)/5)+exp((V+238.4)/-37.45))
    else
        tau_hA2 = 60
    end
    return tau_hA2
end

# GHK equation of the IT calcium current
#=
function ITGHK(V::Float64, Ca::Float64)
    z = 2
    F = 96485.3399e-3
    R = 8.314
    T = 310
    Cao = 2e-3

    G = ((z^2*F^2*V)/(R*T))*((Ca-(Cao*exp(-(z*F*V)/(R*T))))/(1-exp(-(z*F*V)/(R*T))))
    return G
end
=#

## DIFFERENTIAL EQUATIONS FOR THE 17 VARIABLES
function dV_HM(dtbis::Float64, Cbis::Float64, V::Float64, m::Float64, h::Float64, mp::Float64, mK2::Float64, hK2a::Float64, hK2b::Float64, mc::Float64, mt::Float64, ht::Float64, ml::Float64, mA::Float64, hA::Float64, mA2::Float64, hA2::Float64, Iapp::Float64, Istep::Float64)
(dtbis)*(1/Cbis)*(-gNa*m^3*h*(V-VNa) - gNap*mp*(V-VNa) - gK2a*mK2*hK2a*(V-VK) - gK2b*mK2*hK2b*(V-VK) - gc*mc*(V-VK) - gT*mt^2*ht*(V-VCa) - gL*ml^2*(V-VCa) - gA*mA^4*hA*(V-VK) - gA2*mA2^4*hA2*(V-VK) - gNaleak*(V-VNa) - gKleak*(V-VK) + Iapp + Istep)
end

dm(dtbis::Float64,V::Float64, m::Float64)                 = (dtbis)* (1/tau_m(V)) * (m_inf(V) - m)
dh(dtbis::Float64,V::Float64, h::Float64)                 = (dtbis)* (1/tau_h(V)) * (h_inf(V) - h)
dmp(dtbis::Float64,V::Float64,mp::Float64)                = (dtbis)* (1/tau_mp(V)) * (mp_inf(V) - mp)
dmA(dtbis::Float64,V::Float64, mA::Float64)               = (dtbis)* (1/tau_mA(V)) * (mA_inf(V) - mA)
dhA(dtbis::Float64,V::Float64, hA::Float64)               = (dtbis)* (1/tau_hA(V)) * (hA_inf(V) - hA)
dmt(dtbis::Float64,V::Float64, mt::Float64)               = (dtbis)* (1/tau_mt(V)) * (mt_inf(V) - mt)
dht(dtbis::Float64,V::Float64, ht::Float64)               = (dtbis)* (1/tau_ht(V)) * (ht_inf(V) - ht)
dmK2(dtbis::Float64,V::Float64, mK2::Float64)             = (dtbis)* (1/tau_mK2(V)) * (mK2_inf(V) - mK2)
dhK2a(dtbis::Float64,V::Float64, hK2a::Float64)           = (dtbis)* (1/tau_hK2a(V)) * (hK2a_inf(V) - hK2a)
dhK2b(dtbis::Float64,V::Float64, hK2b::Float64)           = (dtbis)* (1/tau_hK2b(V)) * (hK2b_inf(V) - hK2b)
dmc(dtbis::Float64,V::Float64, mc::Float64, CaL::Float64) = (dtbis)* (1/tau_mc(V,CaL)) * (mc_inf(V,CaL) - mc)
dml(dtbis::Float64,V::Float64, ml::Float64)               = (dtbis)* (1/tau_ml(V)) * (ml_inf(V) - ml)
dCaT(dtbis::Float64,V::Float64, mt::Float64,ht::Float64, CaT::Float64, gT::Float64) = (dtbis) * (((-5.18e-3*(gT*mt^2*ht*(V-VCa)))/(0.1*29000)) - CaT)  #??
dCaL(dtbis::Float64,V::Float64, ml::Float64, CaL::Float64) = (dtbis) * (((-5.18e-3*(gL*ml^2*(V-VCa)))/(0.1*29000)) - CaL); #??
dmA2(dtbis::Float64,V::Float64, mA2::Float64)             = (dtbis)* (1/tau_mA2(V)) * (mA2_inf(V) - mA2)
dhA2(dtbis::Float64,V::Float64, hA2::Float64)             = (dtbis)* (1/tau_hA2(V)) * (hA2_inf(V) - hA2)

function simulateHM_spkt(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64,  Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Istep::Float64,  Cbis::Float64)
    # Initial values
    V::Float64 = -60.
    Vprev::Float64 = -60.
    CaT::Float64 = 50.e-9
    CaL::Float64 = 50.e-9
    m::Float64 = m_inf(V)
    h::Float64 = h_inf(V)
    mp::Float64 = mp_inf(V)
    mA::Float64 = mA_inf(V)
    hA::Float64 = hA_inf(V)
    mt::Float64 = mt_inf(V)
    ht::Float64 = ht_inf(V)
    mK2::Float64 = mK2_inf(V)
    hK2a::Float64 = hK2a_inf(V)
    hK2b::Float64 = hK2b_inf(V)
    mc::Float64 = mc_inf(V,CaL)
    ml::Float64 = ml_inf(V)
    mA2::Float64 = mA2_inf(V)
    hA2::Float64 = hA2_inf(V)


    spkA1 = zeros(Tdtbis)
    l1=1
    spkB1 = zeros(Tdtbis)
    k1=1
    spkA2 = zeros(Tdtbis)
    l2=1
    spkB2 = zeros(Tdtbis)
    k2=1
    firing_flag=0

    Tstart::Int64 = convert(Int64, round(Tstepinit/dtbis))
    Tstop::Int64 = convert(Int64, round(Tstepfinal/dtbis))


    for z= 1:Tdtbis

        if z>=Tstart && z<=Tstop
          Iappstep = Istep
        else
          Iappstep = 0.
        end

        V +=dV_HM(dtbis, Cbis,V, m, h, mp, mK2, hK2a, hK2b, mc, mt, ht, ml, mA, hA, mA2, hA2, Iapp, Iappstep)
        m +=dm(dtbis,Vprev,m)
        h +=dh(dtbis,Vprev,h)
        mp +=dmp(dtbis,Vprev,mp)
        mA +=dmA(dtbis,Vprev,mA)
        hA +=dhA(dtbis,Vprev,hA)
        mt +=dmt(dtbis,Vprev,mt)
        ht +=dht(dtbis,Vprev,ht)
        mK2 +=dmK2(dtbis,Vprev,mK2)
        hK2a +=dhK2a(dtbis,Vprev,hK2a)
        hK2b +=dhK2b(dtbis,Vprev,hK2b)
        mc +=dmc(dtbis,Vprev,mc, CaL)
        ml +=dml(dtbis,Vprev,ml)
        CaT += dCaT(dtbis,Vprev,mt,ht,CaT, gT)
        CaL += dCaL(dtbis,Vprev,ml,CaL)
        mA2 += dmA2(dtbis,Vprev,mA2)
        hA2 += dhA2(dtbis,Vprev,hA2)



    if z >= Tstart+TdtTransientbis && z< Tstop
        if Vprev < -50. && V >= -50.
        spkA2[l2] = tbis[z]
        l2 +=1
      end
      if Vprev < -10. && V >= -10.
        if firing_flag==0
          spkB2[k2] = tbis[z]
          firing_flag=1
          k2 +=1
        else
          firing_flag=1
        end
      end
      if Vprev > -10. && V <= -10. && firing_flag==1
        firing_flag=0
      end
    else
      if z>=TdtTransientbis && z<Tstart
        if Vprev < -50. && V >= -50.
          spkA1[l1] = tbis[z]
          l1+=1
        end
        if Vprev < -10. && V >= -10.
          if firing_flag==0
            spkB1[k1] = tbis[z]
            k1+=1
            firing_flag=1
          else
            firing_flag=1
          end
        end
        if Vprev > -10. && V <= -10. && firing_flag==1
          firing_flag=0
        end
      end
    end


    Vprev = copy(V)
    #VV[z] = copy(V)
  end
  return spkA1, spkB1,spkA2, spkB2
end



function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
  ISI = zeros(5000000)
  l::Int64 = 1
  for i = 2:length(Spkt)
      ISI[l] = Spkt[i] - Spkt[i-1]
      l += 1
  end
  return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
  f = findall(ISI .== 0)
    if f[1] > 1
      ISI = ISI[1:f[1]-1]
    else
      ISI = [0.]
    end
  return ISI
end

function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end

function computeFrequ(ISI::Array{Float64})
  maxISI = maximum(ISI)
  intraburst = findall(ISI .<=maxISI/3)
  IBP = mean(ISI[intraburst])
  IBF = 1000/IBP
  return IBF
end


function computeSwitch(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64,  Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Ivecbis::Array{Float64}, Cvecbis::Array{Float64})
  lC =  length(Cvecbis)
  lI =  length(Ivecbis)
  FP_T = zeros(lC, lI)
  FP_B = zeros(lC, lI)
  switch = zeros(lC, lI)
  freq_T = zeros(lC, lI)
  freq_B = zeros(lC, lI)

  for j=1:lI
    display(j)
      for i=1:lC
          display(i)
          @time (spiketimesA1, spiketimesB1,spiketimesA2, spiketimesB2 ) = simulateHM_spkt(Tdtbis, dtbis, tbis, TdtTransientbis, Iapp,Tstepinit,Tstepfinal,Ivecbis[j],Cvecbis[i])
          if sum(spiketimesA1) .== 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 0. #Silent
          elseif sum(spiketimesA1) .> 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB1))) ).== 1
              FP_T[i,j] = 2. #bursting
              freq_T[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB1))))
          else
              FP_T[i,j] = 3. #spiking
              freq_T[i,j]=1000/mean(remove0(ISIfunc(remove0(spiketimesB1))))
          end
          if sum(spiketimesA2) .== 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 0. #Silent
          elseif sum(spiketimesA2) .> 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB2))) ).== 1
              FP_B[i,j] = 2. #bursting
              freq_B[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB2))))
          else
              FP_B[i,j] = 3. #spiking
              freq_B[i,j] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB2))))
          end
          if(FP_T[i,j]==3. && FP_B[i,j]==2. && freq_T[i,j]<freq_B[i,j])
              switch[i,j] = 1.
          elseif(FP_T[i,j]==3. && FP_B[i,j]==2.)
              switch[i,j] = 0.5 #crit. non respected
          end
      end
  end


  return switch, FP_T, FP_B, freq_T, freq_B
end


function simulateHM_plot(Tdtbis::Int64, dtbis::Float64, Cbis::Float64)
    # Initial values
    V::Float64 = -60.
    Vprev::Float64 = -60.
    CaT::Float64 = 50.e-9
    CaL::Float64 = 50.e-9
    m::Float64 = m_inf(V)
    h::Float64 = h_inf(V)
    mp::Float64 = mp_inf(V)
    mA::Float64 = mA_inf(V)
    hA::Float64 = hA_inf(V)
    mt::Float64 = mt_inf(V)
    ht::Float64 = ht_inf(V)
    mK2::Float64 = mK2_inf(V)
    hK2a::Float64 = hK2a_inf(V)
    hK2b::Float64 = hK2b_inf(V)
    mc::Float64 = mc_inf(V,CaL)
    ml::Float64 = ml_inf(V)
    mA2::Float64 = mA2_inf(V)
    hA2::Float64 = hA2_inf(V)

    VV=zeros(Tdtbis)

    Tstep1::Int64 = convert(Int64,round(T1/dtbis))
    Tstep2::Int64 = convert(Int64,round(T2/dtbis))
    Tstep3::Int64 = convert(Int64, round(T3/dtbis))
    TstepFinal::Int64 = convert(Int64,round(Tstop/dtbis))


    for z= 1:Tdtbis


        if z >= Tstep1 && z< Tstep2
          Iappstep = Istep1
        elseif z >= Tstep2 && z< Tstep3
          Iappstep = Istep2
        elseif z >= Tstep3 && z< TstepFinal
          Iappstep = Istep3
        else
          Iappstep = 0.
        end


        V +=dV_HM(dtbis,Cbis, V, m, h, mp, mK2, hK2a, hK2b, mc, mt, ht, ml, mA, hA, mA2, hA2, Iapp, Iappstep)
        m +=dm(dtbis,Vprev,m)
        h +=dh(dtbis,Vprev,h)
        mp +=dmp(dtbis,Vprev,mp)
        mA +=dmA(dtbis,Vprev,mA)
        hA +=dhA(dtbis,Vprev,hA)
        mt +=dmt(dtbis,Vprev,mt)
        ht +=dht(dtbis,Vprev,ht)
        mK2 +=dmK2(dtbis,Vprev,mK2)
        hK2a +=dhK2a(dtbis,Vprev,hK2a)
        hK2b +=dhK2b(dtbis,Vprev,hK2b)
        mc +=dmc(dtbis,Vprev,mc, CaL)
        ml +=dml(dtbis,Vprev,ml)
        CaT += dCaT(dtbis,Vprev,mt,ht,CaT, gT)
        CaL += dCaL(dtbis,Vprev,ml,CaL)
        mA2 += dmA2(dtbis,Vprev,mA2)
        hA2 += dhA2(dtbis,Vprev,hA2)




        Vprev = copy(V)
        VV[z] = copy(V)

    end
    return VV
end
