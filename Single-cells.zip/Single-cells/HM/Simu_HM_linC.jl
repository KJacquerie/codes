# Define output directory
name="HMMap"

# Load packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include model
include("HM_SWITCH.jl")


# Simulations parameters
# Simulation parameters
const T = 7000
const Ttransient = 500

const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,round(Ttransient/dt))

const dt2 = 0.001
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,round(Ttransient/dt2))

const dt3 = 0.0001
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))

# Model parameters
const VNa = 45
const VCa = 120
const gNa = 12 #[mS]
const gNap = 7.e-3 # [nS]
const gNaleak = 2.65e-3 # dans le papier >> 0.25 nS
const VK = -105
const gA = 20.e-3
const gA2 = 15.e-3
const gKleak = 7.e-3
const gK2a = 38.e-3
const gK2b = 26.e-3
const gc = 1 # ok
const gL = 0.8
const gT=1. #1.5

const Cnom = 0.29 #nF


#excitation
const Iapp=1.
const T1= 1500
const T2= T


#Cvec = exp10.(range(1,2, length=10))*Cnom
Ivec = [ -0.6 -0.7 -0.8 -0.9 -1. -1.1 -1.2] #until -1.1 switch ok
#(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)

Cvec1 = collect(1:0.1:5)*Cnom
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)


Cvec2 = collect(0.1:0.1:1)*Cnom
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3 = collect(0.01:0.01:0.1)*Cnom
Ivec3 = Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end, :];switch1[2:end, :]]#; switch[2:end, :]]
#figure(901)
imshow(switch_TOT, cmap="gray")

Cvec_TOT = [Cvec3; Cvec2[2:end, :];Cvec1[2:end, :]]#; Cvec[2:end, :]]
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/HM/Map/Cvec_lin.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/HM/Map/switch_TOT_lin.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/HM/Map/Ivec_lin.dat", Ivec, header=false)

#=
Cvecplot=[ 0.01 0.05 0.1 0.5 1. 5. ]*Cnom#[0.01 0.02 0.05 0.1 0.2 0.5 1 5]
PyPlot.close("all")
figure
for i=1:length(Cvecplot)
    if(Cvecplot[i]<=1.e-1*Cnom)
        Tdtplot = Tdt3
        tplot=t3
        dtplot=dt3
        TdtTransientplot = TdtTransient3
    else
        if(Cvecplot[i]<=1.*Cnom)
            Tdtplot=Tdt2
            tplot=t2
            dtplot=dt2
            TdtTransientplot = TdtTransient2
        else
            Tdtplot=Tdt
            tplot=t
            dtplot=dt
            TdtTransientplot = TdtTransient
        end
    end
    @time VV = simulateHM_plot(Tdtplot,dtplot,Cvecplot[i])
    subplot(3,2,i)
    Vplot = plot(tplot[TdtTransientplot:end],VV[TdtTransientplot:end],"-")
    axis([500,T,-90,60])
end
#savefig("../Analysis/Vplot_HMSWITCH4_Cplot.eps")

=#
#=
Cvec=logspace(1.,2.,10)*Cnom
FP=zeros(length(Cvec),4) #4 steps par C simulé
switch=zeros(length(Cvec)) # oui ou non il y a eu un step
freq=zeros(length(Cvec),4) # donne la frequence du FP a chaque step
for i=1:length(Cvec)
    display(i)
    @time (spiketimesA, spiketimesB)= simulateHM_spkt(Tdt, dt, t, TdtTransient,Cvec[i])
    for jj=1:4
        if sum(spiketimesA[:,jj]) .== 0 && sum(spiketimesB[:,jj]) .== 0
            FP[i,jj] = 0. #Silent
            freq[i,jj] =0.
        elseif sum(spiketimesA[:,jj]) .> 0 && sum(spiketimesB[:,jj]) .== 0
            FP[i,jj] = 1. #Slow oscillation
            freq[i,jj] =0.
        elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[:,jj]))) ).== 1
            FP[i,jj] = 2. #bursting
            freq[i,jj]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        else
            FP[i,jj] = 3. #spiking
            freq[i,jj] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        end
    end
    if(FP[i,1]==3. && FP[i,2]==2. && freq[i,1]*1.5<=freq[i,2])
        switch[i] = 5.
    elseif(FP[i,2]==3. && FP[i,3]==2. && freq[i,2]*1.5<=freq[i,3])
        switch[i] = 5.
    elseif(FP[i,3]==3. && FP[i,4]==2. && freq[i,3]*1.5<=freq[i,4])
        switch[i] = 5.
    end
end



Cvec2=logspace(-1.,1.,15)*Cnom
FP2=zeros(length(Cvec2),4)
switch2=zeros(length(Cvec2))
freq2=zeros(length(Cvec2),4)
for i=1:length(Cvec2)
    display(i)
    @time (spiketimesA, spiketimesB) = simulateHM_spkt(Tdt2, dt2, t2, TdtTransient2, Cvec2[i])
    for jj=1:4
        if sum(spiketimesA[:,jj]) .== 0 && sum(spiketimesB[:,jj]) .== 0
            FP2[i,jj] = 0. #Silent
        elseif sum(spiketimesA[:,jj]) .> 0 && sum(spiketimesB[:,jj]) .== 0
            FP2[i,jj] = 1. #Slow oscillation
        elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[:,jj]))) ).== 1
            FP2[i,jj] = 2. #bursting
            freq2[i,jj]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        else
            FP2[i,jj] = 3. #spiking
            freq2[i,jj] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        end
    end
    if(FP2[i,1]==3. && FP2[i,2]==2. && freq2[i,1]*1.5<=freq2[i,2])
        switch2[i] = 5.
    elseif(FP2[i,2]==3. && FP2[i,3]==2. && freq2[i,2]*1.5<=freq2[i,3])
        switch2[i] = 5.
    elseif(FP2[i,3]==3. && FP2[i,4]==2. && freq2[i,3]*1.5<=freq2[i,4])
        switch2[i] = 5.
    end
end

Cvec3=logspace(-2.,-1.,5)*Cnom
FP3=zeros(length(Cvec3),4)
switch3=zeros(length(Cvec3))
freq3=zeros(length(Cvec3),4)
for i=1:length(Cvec3)
    display(i)
    @time (spiketimesA, spiketimesB) = simulateHM_spkt(Tdt3, dt3, t3, TdtTransient3,Cvec3[i])
    for jj=1:4
        if sum(spiketimesA[:,jj]) .== 0 && sum(spiketimesB[:,jj]) .== 0
            FP3[i,jj] = 0. #Silent
        elseif sum(spiketimesA[:,jj]) .> 0 && sum(spiketimesB[:,jj]) .== 0
            FP3[i,jj] = 1. #Slow oscillation
        elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[:,jj]))) ).== 1
            FP3[i,jj] = 2. #bursting
            freq3[i,jj]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        else
            FP3[i,jj] = 3. #spiking
            freq3[i,jj] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        end
    end
    if(FP3[i,1]==3. && FP3[i,2]==2. && freq3[i,1]*1.5<=freq3[i,2])
        switch3[i] = 5.
    elseif(FP3[i,2]==3. && FP3[i,3]==2. && freq3[i,2]*1.5<=freq3[i,3])
        switch3[i] = 5.
    elseif(FP3[i,3]==3. && FP3[i,4]==2. && freq3[i,3]*1.5<=freq3[i,4])
        switch3[i] = 5.
    end
end

#PyPlot.close("all")
figure(2)
hold("on")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,1];FP2[:,1];FP[:,1]],"*")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,2]+0.1;FP2[:,2]+0.1;FP[:,2]+0.1],"o")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,3]+0.2;FP2[:,3]+0.2;FP[:,3]+0.2],".")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,4]+0.3;FP2[:,4]+0.3;FP[:,4]+0.3],"+")
semilogx([Cvec3;Cvec2;Cvec],[switch3-0.5;switch2-0.5;switch-0.5],"^")
hold("off")
xlim([0.005*C,200*C])
ylim([-1,5])
savefig("../Analysis/Vplot_HMSWITCH4_FPvsC.eps")

figure(3)
hold("on")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,1];freq2[:,1];freq[:,1]],"*")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,2];freq2[:,2];freq[:,2]],"o")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,3];freq2[:,3];freq[:,3]],".")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,4];freq2[:,4];freq[:,4]],"+")
hold("off")
savefig("../Analysis/Vplot_HMSWITCH4_freq.eps")
=#
#=
writedlm(@sprintf("../Analysis/%s_FP.dat", name), FP, header=false)
writedlm(@sprintf("../Analysis/%s_FP2.dat", name), FP2, header=false)
writedlm(@sprintf("../Analysis/%s_FP3.dat", name), FP3, header=false)
writedlm(@sprintf("../Analysis/%s_Cvec.dat", name), Cvec, header=false)
writedlm(@sprintf("../Analysis/%s_Cvec2.dat", name), Cvec2, header=false)
writedlm(@sprintf("../Analysis/%s_Cvec3.dat", name), Cvec3, header=false)
=#
