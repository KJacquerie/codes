# Define output directory
#cd("")
const file_name = "HM"

# Load packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include model
include("HM_model.jl")

# Simulations parameters
const T = 2000
const dt = 0.0001
const Tdt = convert(Int64,T/dt)
const t = range(dt,T,length=Tdt)

# Model parameters
const C = 0.29 #/50 #nF

const VNa = 45
const VCa = 120
const VK = -105

const gNa = 12 # [uS]
const gNap = 7.e-3
const gNaleak = 2.65e-3
const gA = 20.e-3 #120e-3
const gA2 = 15.e-3
const gKleak = 7.e-3
const gK2a = 38.e-3
const gK2b = 26.e-3
const gc = 1
const gL = 0.8


const name_expm = "HIB"
const Iapp = 1.#0.
const Istep = -0.9#-0.5
const Tstepinit = 500
const Tstepfinal = T
const gT =1.

#=
const name_expm = "PIR"
const Iapp = 0.
const Istep = -0.3
const Tstepinit = 500
const Tstepfinal = 1000
const gT =0.4
=#
# Simulations
@time (yy, mm) = simulateTC(Iapp, Tstepinit, Tstepfinal, Istep,gT)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s.dat", file_name, name_expm), t, header=false)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s.dat", file_name, name_expm), yy, header=false)

plot(t, yy)
