# Defines output directory
#cd("/Users/kathleen/Documents/2017-2018/TFE/Single-cells/RushCa")

const file_name = "RushCa"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include DCN model
include("RushCa_model.jl")

# Simulation parameters
#const T = 200
#const T = 1600
const T = 2000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const t = range(dt,T,length=Tdt)

# Model parameters
const C = 0.1
const VNa = 55
const VK = -85
const VCa = 120

const gNa = 120
const gKd = 10
const gNaleak = 0.01429
const gKleak = 0.08571
const gCaT = 0.3

const tetas= -63
const ks= -7.8
const tetah = -72
const kh = 1.1
const sigm = 10.3
const sign = 9.3
const teta = 1

const coef_red_h = 1.5
const coef_red_m = 1/10
const coef_red_n = 5*0.035



# Excitation

name_expm = "HIB"
Iapp = 15.#3.
Tstepinit= 500
Tstepfinal = T
Istep = -16.2


#= name_expm = "PIR"

Iapp = 0.#3.
Tstepinit= 500
Tstepfinal = 1000
Istep = -1.5
gCaT = 0.3
=#

@time yy1 = simulateTC(C, Iapp, Tstepinit, Tstepfinal, Istep, gCaT)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s.dat", file_name, name_expm), t, header=false)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s.dat", file_name, name_expm), yy1, header=false)

plot(t,yy1)

#PIR T=2000
#=
test_name = "PIR"
Iapp = 0.#3.
Tstepinit= 500
Tstepfinal = 1000
Istep = -1.5
gCaT = 0.3
=#
