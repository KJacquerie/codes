# gating functions
# calcium activation
mCaTinf(V::Float64) = 1/(1+exp((V-tetas)/ks))
taumCaT(V::Float64) = coef_red_m*((1.7 + exp(-(V+28.8)/13.5))/(1+exp(-(V+63)/7.8)))

#calcium inactivation
hCaTinf(V::Float64) = 1/(0.5 + sqrt(0.25 + exp((V-tetah)/kh)))
tauhCaT(V::Float64) = coef_red_h*(exp((V+150)/18)/(1.5 + sqrt(0.25 + exp((V-80)/4))) + 30)

#sodium activation
alpham(V::Float64) = 0.1*(V+35-sigm)/(1 - exp(-0.1*(V+35-sigm)))
betam(V::Float64) = 4*exp(-0.05*(V+60-sigm))
minf(V::Float64) = alpham(V)/(alpham(V)+betam(V))

#sodium inactivation
alphan(V::Float64) = 0.01*(V+50-sign)/(1 - exp(-0.1*(V+50-sign)))
betan(V::Float64) = 0.125*exp(-0.0125*(V+60-sign))
ninf(V::Float64) = alphan(V)/(alphan(V)+betan(V))
taun(V::Float64) = coef_red_n*(0.05/(alphan(V)+betan(V)))


function dV(C::Float64, V::Float64, n::Float64, gCaT::Float64, mCaT::Float64, hCaT::Float64, Iapp::Float64, Istep::Float64)
  (dt)*(1/C)*(-gNa*minf(V)^3*(0.85-n)*(V-VNa) - gKd*n^4*(V-VK) - gCaT*mCaT^3*hCaT*(V-VCa) - gNaleak*(V-VNa) - gKleak*(V-VK) + Iapp + Istep )
end

dhCaT(V::Float64,hCaT::Float64) = (dt)*((teta/tauhCaT(V))*(hCaTinf(V) - hCaT)) #OK
dmCaT(V::Float64,mCaT::Float64) = (dt)*(mCaTinf(V) - mCaT)/taumCaT(V)
dn(V::Float64,n::Float64) = (dt)*((1/taun(V))*(ninf(V) - n)) #OK


function simulateTC(C::Float64, Iapp::Float64, Tstepinit::Int64,Tstepfinal::Int64, Istep::Float64, gCaT::Float64)
  V::Float64=-60.
  Vprev::Float64=-60.
  hCaT::Float64=hCaTinf(V)
  mCaT::Float64=mCaTinf(V)
  n::Float64=ninf(V)

  VV = zeros(Tdt)
  Tstart::Int64 = convert(Int64,Tstepinit/dt)
  Tstop::Int64 = convert(Int64,Tstepfinal/dt)

  for z = 1:Tdt
    n += dn(V,n)
    mCaT += dmCaT(V,mCaT)
    hCaT += dhCaT(V,hCaT)

    if z >= Tstart && z<= Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end

    V += dV(C, V, n, gCaT, mCaT, hCaT, Iapp, Iappstep)

    Vprev=copy(V)
    VV[z] = copy(V)

  end

  return VV
end
