# gating functions
# calcium activation
mCaTinf(V::Float64) = 1/(1+exp((V-tetas)/ks))
taumCaT(V::Float64) = coef_red_m*((1.7 + exp(-(V+28.8)/13.5))/(1+exp(-(V+63)/7.8)))

#calcium inactivation
hCaTinf(V::Float64) = 1/(0.5 + sqrt(0.25 + exp((V-tetah)/kh)))
tauhCaT(V::Float64) = coef_red_h*(exp((V+150)/18)/(1.5 + sqrt(0.25 + exp((V-80)/4))) + 30)

#sodium activation
alpham(V::Float64) = 0.1*(V+35-sigm)/(1 - exp(-0.1*(V+35-sigm)))
betam(V::Float64) = 4*exp(-0.05*(V+60-sigm))
minf(V::Float64) = alpham(V)/(alpham(V)+betam(V))

#sodium inactivation
alphan(V::Float64) = 0.01*(V+50-sign)/(1 - exp(-0.1*(V+50-sign)))
betan(V::Float64) = 0.125*exp(-0.0125*(V+60-sign))
ninf(V::Float64) = alphan(V)/(alphan(V)+betan(V))
taun(V::Float64) = coef_red_n*(0.05/(alphan(V)+betan(V)))


function dV(dtbis::Float64, C::Float64, V::Float64, n::Float64, mCaT::Float64, hCaT::Float64, Iapp::Float64, Istep::Float64)
  (dtbis)*(1/C)*(-gNa*minf(V)^3*(0.85-n)*(V-VNa) - gKd*n^4*(V-VK) - gCaT*mCaT^3*hCaT*(V-VCa) - gNaleak*(V-VNa) - gKleak*(V-VK) + Iapp + Istep )
end

dhCaT(dtbis::Float64, V::Float64,hCaT::Float64) = (dtbis)*((teta/tauhCaT(V))*(hCaTinf(V) - hCaT)) #OK
dmCaT(dtbis::Float64, V::Float64,mCaT::Float64) = (dtbis)*(mCaTinf(V) - mCaT)/taumCaT(V)
dn(dtbis::Float64, V::Float64,n::Float64) = (dtbis)*((1/taun(V))*(ninf(V) - n)) #OK


function simulateRushCa_spkt(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64, Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Istep::Float64,Cbis::Float64)
  V::Float64=-60.
  Vprev::Float64=-60.
  hCaT::Float64=hCaTinf(V)
  mCaT::Float64=mCaTinf(V)
  n::Float64=ninf(V)


  spkA1 = zeros(Tdtbis)
  l1=1
  spkB1 = zeros(Tdtbis)
  k1=1
  spkA2 = zeros(Tdtbis)
  l2=1
  spkB2 = zeros(Tdtbis)
  k2=1
  firing_flag=0

  Tstart::Int64 = convert(Int64, round(Tstepinit/dtbis))
  Tstop::Int64 = convert(Int64, round(Tstepfinal/dtbis))


  for z = 1:Tdtbis


    if z>=Tstart && z<=Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end

    V += dV(dtbis,Cbis, V, n, mCaT, hCaT, Iapp, Iappstep)
    n += dn(dtbis, Vprev,n)
    mCaT += dmCaT(dtbis, Vprev,mCaT)
    hCaT += dhCaT(dtbis, Vprev,hCaT)

    if z >= Tstart+TdtTransientbis && z< Tstop
      if Vprev < -50. && V >= -50.
        spkA2[l2] = tbis[z]
        l2 +=1
      end
      if Vprev < -10. && V >= -10.
        if firing_flag==0
          spkB2[k2] = tbis[z]
          firing_flag=1
          k2 +=1
        else
          firing_flag=1
        end
      end
      if Vprev > -10. && V <= -10. && firing_flag==1
        firing_flag=0
      end
    else
      if z>=TdtTransientbis && z<Tstart
        if Vprev < -50. && V >= -50.
          spkA1[l1] = tbis[z]
          l1+=1
        end
        if Vprev < -10. && V >= -10.
          if firing_flag==0
              spkB1[k1] = tbis[z]
            k1+=1
            firing_flag=1
          else
            firing_flag=1
          end
        end
        if Vprev > -10. && V <= -10. && firing_flag==1
          firing_flag=0
            end
      end
    end


    Vprev = copy(V)
    #VV[z] = copy(V)
  end

  return spkA1, spkB1,spkA2, spkB2
end

function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
  ISI = zeros(5000000)
  l::Int64 = 1
  for i = 2:length(Spkt)
      ISI[l] = Spkt[i] - Spkt[i-1]
      l += 1
  end
  return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
  f = findall(ISI .== 0)
    if f[1] > 1
      ISI = ISI[1:f[1]-1]
    else
      ISI = [0.]
    end
  return ISI
end

function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end



function computeFrequ(ISI::Array{Float64})
  maxISI = maximum(ISI)
  intraburst = findall(ISI .<=maxISI/3)
  IBP = mean(ISI[intraburst])
  IBF = 1000/IBP
  return IBF
end



function computeSwitch(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64,  Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Ivecbis::Array{Float64}, Cvecbis::Array{Float64})
  lC =  length(Cvecbis)
  lI =  length(Ivecbis)
  FP_T = zeros(lC, lI)
  FP_B = zeros(lC, lI)
  switch = zeros(lC, lI)
  freq_T = zeros(lC, lI)
  freq_B = zeros(lC, lI)

  for j=1:lI
    display(j)
      for i=1:lC
          display(i)
          @time (spiketimesA1, spiketimesB1,spiketimesA2, spiketimesB2 ) = simulateRushCa_spkt(Tdtbis, dtbis, tbis, TdtTransientbis, Iapp,Tstepinit,Tstepfinal,Ivecbis[j],Cvecbis[i])
          if sum(spiketimesA1) .== 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 0. #Silent
          elseif sum(spiketimesA1) .> 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB1))) ).== 1
              FP_T[i,j] = 2. #bursting
              freq_T[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB1))))
          else
              FP_T[i,j] = 3. #spiking
              freq_T[i,j]=1000/mean(remove0(ISIfunc(remove0(spiketimesB1))))
          end
          if sum(spiketimesA2) .== 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 0. #Silent
          elseif sum(spiketimesA2) .> 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB2))) ).== 1
              FP_B[i,j] = 2. #bursting
              freq_B[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB2))))
          else
              FP_B[i,j] = 3. #spiking
              freq_B[i,j] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB2))))
          end
          if(FP_T[i,j]==3. && FP_B[i,j]==2. && freq_T[i,j]<freq_B[i,j])
              switch[i,j] = 1.
          elseif(FP_T[i,j]==3. && FP_B[i,j]==2.)
              switch[i,j] = 0.5 #crit. non respected
          end
      end
  end


  return switch, FP_T, FP_B, freq_T, freq_B
end


### A ADAPTER
function simulateRushCa_plot(Tdtbis::Int64, dtbis::Float64,C::Float64)
  V::Float64=-60.
  Vprev::Float64=-60.
  hCaT::Float64=hCaTinf(V)
  mCaT::Float64=mCaTinf(V)
  n::Float64=ninf(V)

  #VV = zeros(Tdtbis)

  Tstart::Int64 = convert(Int64, round(Tstepinit/dtbis))
  Tstop::Int64 = convert(Int64, round(Tstepfinal/dtbis))


  for z = 1:Tdtbis

    if z>=Tstart && z<=Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end


    V += dV(dtbis,C, V, n, mCaT, hCaT, Iapp, Iappstep)
    n += dn(dtbis, Vprev,n)
    mCaT += dmCaT(dtbis, Vprev,mCaT)
    hCaT += dhCaT(dtbis, Vprev,hCaT)

    Vprev=copy(V)
    VV[z] = copy(V)

  end

  return VV
end
