# Defines output directory
#cd("./")
name="DrionMap"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include DCN model
include("Drion_SWITCH.jl")

# Simulation parameters
const T = 7000
const Ttransient = 500

const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,Ttransient/dt)

const dt2 = 0.001
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,Ttransient/dt2)

const dt3 = 0.0001
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))


# Model parameters
const VNa = 50
const VK = -85
const VCa = 120
const Vl = -55
const VH = -20
const Kd = 170

const gl = 0.055
const gNa = 170
const gKd = 40
const k1=1.e-1
const k2= 0.1e-1
const gCaT = 0.55
const gH = 0.01
const gKCa = 4.



#excitation
const Iapp=1.
#const Istep=-2.5
const T1= 1500
const T2= T

Ivec = [-1. -1.1 -1.2 -1.3 -1.4 -1.5 -1.6 -1.7 -1.8 -1.9 -2. -2.1 -2.2 -2.3 -2.4 -2.5 -2.6 -2.7 -2.8 -2.9 -3.]
Cvec = exp10.(range(1,2, length=10))
(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)

Cvec1 = exp10.(range(0,1, length=10))
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)


Cvec2 = exp10.(range(-1,0, length=10))
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3 = exp10.(range(-2,-1, length=10))
Ivec3 = Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end, :];switch1[2:end, :]; switch[2:end, :]]
#figure(101)
imshow(switch_TOT, cmap="gray")
Cvec_TOT = [Cvec3; Cvec2[2:end, :];Cvec1[2:end, :]; Cvec[2:end, :]]
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Drion/Map/Cvec.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Drion/Map/switch_TOT.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Drion/Map/Ivec.dat", Ivec, header=false)






# PLOT
#=
Cvecplot=[0.01 0.05 0.1 0.2 0.5 1. 5. 10.]
PyPlot.close("all")
figure
for i=1:length(Cvecplot)
    if(Cvecplot[i]<=1.e-1)
        Tdtplot = Tdt3
        tplot=t3
        dtplot=dt3
        TdtTransientplot = TdtTransient3
    else
        if(Cvecplot[i]<=1.)
            Tdtplot=Tdt2
            tplot=t2
            dtplot=dt2
            TdtTransientplot = TdtTransient2
        else
            Tdtplot=Tdt
            tplot=t
            dtplot=dt
            TdtTransientplot = TdtTransient
        end
    end
    @time VV = simulateCaT_plot(Tdtplot,dtplot,Iapp,T1,T2,Istep,Cvecplot[i])
    subplot(4,2,i)
    Vplot = plot(tplot[TdtTransientplot:end],VV[TdtTransientplot:end],"-")
    axis([500,T,-90,60])
end
=#
