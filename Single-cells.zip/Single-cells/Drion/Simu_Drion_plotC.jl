# Defines output directory
#cd("./")
file_name="Drion"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include  model
include("Drion_model.jl")

# Simulation parameters
const T = 2000
const dt = 0.001
const Tdt = convert(Int64,T/dt)
const t = range(dt,T,length=Tdt)#linspace(dt,T,Tdt)

# Model parameters
const C = 0.1
const VNa = 50
const VK = -85
const VCa = 120
const Vl = -59#55
const VH = -20
const Kd = 170

const gl = 0.055
const gNa = 170
const gKd = 40
const gCa=0.55
const gKCa= 4.
const gH = 0.01
const k1= 1.e-1
const k2=0.1e-1


# excitation

const name_expm = "C"
const Iapp = 1.
const Istep = -1.9
const Tstep = 500
const Tstep_end = T


# run model
@time yy1 = simulateTOY(Iapp,Tstep,Tstep_end,Istep,gCa,gH,gKCa,k1,k2)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s%d.dat", file_name, name_expm, C), t, header=false)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s%d.dat", file_name, name_expm, C), yy1, header=false)

Vplot = plot(t,yy1)
