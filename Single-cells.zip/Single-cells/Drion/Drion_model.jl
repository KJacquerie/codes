# gating functions
boltz(V::Float64,A::Float64,B::Float64) = 1/(1 + exp((V+A)/B))
tauX(V::Float64,A::Float64,B::Float64,D::Float64,E::Float64) = A - B/(1+exp((V+D)/E))
mNainf(V::Float64) = boltz(V,35.5,-5.29)
taumNa(V::Float64) = tauX(V,1.32,1.26,120.,-25.)
hNainf(V::Float64) = boltz(V,48.9,5.18)
tauhNa(V::Float64) = (0.67/(1+exp((V+62.9)/-10.0)))*(1.5 + 1/(1+exp((V+34.9)/3.6)))
mKdinf(V::Float64) = boltz(V,12.3,-11.8)
taumKd(V::Float64) = tauX(V,7.2,6.4,28.3,-19.2)
mCaTinf(V::Float64) = boltz(V,67.1,-7.2)
taumCaT(V::Float64) = tauX(V,21.7,21.3,68.1,-20.5)
hCaTinf(V::Float64) = boltz(V,80.1,5.5)
tauhCaT(V::Float64) = 2*tauX(V,205.,89.8,55.,-16.9)
mHinf(V::Float64) = boltz(V,80.,6.)
taumH(V::Float64) = tauX(V,272.,-1149.,42.2,-8.73)
mKCainf(Ca::Float64) = (Ca/(Ca+Kd))^2

ICaT(V::Float64,mCaT::Float64,hCaT::Float64,gCaT::Float64) = gCaT*mCaT^3*hCaT*(V-VCa)

function dV(V::Float64, mNa::Float64, hNa::Float64, mKd::Float64, mCaT::Float64, hCaT::Float64, mH::Float64, Ca::Float64, Iapp::Float64, Istep::Float64, gCaT::Float64, gH::Float64, gKCa::Float64)
  (dt)*(1/C)*(-gNa*mNa^3*hNa*(V-VNa) -gKd*mKd^4*(V-VK) -gl*(V-Vl) -ICaT(V,mCaT,hCaT,gCaT) -gKCa*mKCainf(Ca)*(V-VK) -gH*mH*(V-VH) +Iapp +Istep)
end

dmNa(V::Float64,mNa::Float64) = (dt)*((1/taumNa(V))*(mNainf(V) - mNa))
dhNa(V::Float64,hNa::Float64) = (dt)*((1/tauhNa(V))*(hNainf(V) - hNa))
dmKd(V::Float64,mKd::Float64) = (dt)*((1/taumKd(V))*(mKdinf(V) - mKd))
dmCaT(V::Float64,mCaT::Float64) = (dt)*((1/taumCaT(V))*(mCaTinf(V) - mCaT))
dhCaT(V::Float64,hCaT::Float64) = (dt)*((1/tauhCaT(V))*(hCaTinf(V) - hCaT))
dmH(V::Float64,mH::Float64) = (dt)*((1/taumH(V))*(mHinf(V) - mH))
dCa(V::Float64,mCaT::Float64,hCaT::Float64,Ca::Float64,gCaT::Float64,k1::Float64,k2::Float64) = (dt)*(-k1*ICaT(V,mCaT,hCaT,gCaT) -k2*Ca)

function simulateTOY(Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64,gCaT::Float64,gH::Float64,gKCa::Float64,k1::Float64,k2::Float64)
  V::Float64=-60.
  Vprev=-60.
  Ca::Float64=20.
  mNa::Float64=mNainf(V)
  hNa::Float64=hNainf(V)
  mKd::Float64=mKdinf(V)
  mCaT::Float64=mCaTinf(V)
  hCaT::Float64=hCaTinf(V)
  mH::Float64=mHinf(V)

  VV = zeros(Tdt)

  Tstart::Int64 = convert(Int64,round(Tstepinit/dt))
  Tstop::Int64 = convert(Int64,round(Tstepfinal/dt))

  for z = 1:Tdt

    if z >= Tstart && z<= Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end

    V += dV(V, mNa, hNa, mKd, mCaT, hCaT, mH, Ca, Iapp, Iappstep, gCaT, gH, gKCa)

    Ca += dCa(Vprev,mCaT,hCaT,Ca,gCaT,k1,k2)
    mNa += dmNa(Vprev,mNa)
    hNa += dhNa(Vprev,hNa)
    mKd += dmKd(Vprev,mKd)
    mCaT += dmCaT(Vprev,mCaT)
    hCaT += dhCaT(Vprev,hCaT)
    mH += dmH(Vprev,mH)

    Vprev = copy(V)
    VV[z] = copy(V)
  end

  return VV
end
