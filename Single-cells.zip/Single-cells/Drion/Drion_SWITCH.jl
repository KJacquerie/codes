# gating functions
boltz(V::Float64,A::Float64,B::Float64) = 1/(1 + exp((V+A)/B))
tauX(V::Float64,A::Float64,B::Float64,D::Float64,E::Float64) = A - B/(1+exp((V+D)/E))
mNainf(V::Float64) = boltz(V,35.5,-5.29)
taumNa(V::Float64) = tauX(V,1.32,1.26,120.,-25.)
hNainf(V::Float64) = boltz(V,48.9,5.18)
tauhNa(V::Float64) = (0.67/(1+exp((V+62.9)/-10.0)))*(1.5 + 1/(1+exp((V+34.9)/3.6)))
mKdinf(V::Float64) = boltz(V,12.3,-11.8)
taumKd(V::Float64) = tauX(V,7.2,6.4,28.3,-19.2)
mCaTinf(V::Float64) = boltz(V,67.1,-7.2)
taumCaT(V::Float64) = tauX(V,21.7,21.3,68.1,-20.5)
hCaTinf(V::Float64) = boltz(V,80.1,5.5)
tauhCaT(V::Float64) = 2*tauX(V,205.,89.8,55.,-16.9)
mHinf(V::Float64) = boltz(V,80.,6.)
taumH(V::Float64) = tauX(V,272.,-1149.,42.2,-8.73)
mKCainf(Ca::Float64) = (Ca/(Ca+Kd))^2

ICaT(V::Float64,mCaT::Float64,hCaT::Float64,gCaT::Float64) = gCaT*mCaT^3*hCaT*(V-VCa)

function dV(dtbis::Float64,V::Float64, C::Float64, mNa::Float64, hNa::Float64, mKd::Float64, mCaT::Float64, hCaT::Float64, mH::Float64, Ca::Float64, Iapp::Float64, Istep::Float64, gCaT::Float64, gH::Float64, gKCa::Float64)
  (dtbis)*(1/C)*(-gNa*mNa^3*hNa*(V-VNa) -gKd*mKd^4*(V-VK) -gl*(V-Vl) -ICaT(V,mCaT,hCaT,gCaT) -gKCa*mKCainf(Ca)*(V-VK) -gH*mH*(V-VH) +Iapp +Istep)
end

dmNa(dtbis::Float64, V::Float64,mNa::Float64) = (dtbis)*((1/taumNa(V))*(mNainf(V) - mNa))
dhNa(dtbis::Float64,V::Float64,hNa::Float64) = (dtbis)*((1/tauhNa(V))*(hNainf(V) - hNa))
dmKd(dtbis::Float64,V::Float64,mKd::Float64) = (dtbis)*((1/taumKd(V))*(mKdinf(V) - mKd))
dmCaT(dtbis::Float64,V::Float64,mCaT::Float64) = (dtbis)*((1/taumCaT(V))*(mCaTinf(V) - mCaT))
dhCaT(dtbis::Float64,V::Float64,hCaT::Float64) = (dtbis)*((1/tauhCaT(V))*(hCaTinf(V) - hCaT))
dmH(dtbis::Float64,V::Float64,mH::Float64) = (dtbis)*((1/taumH(V))*(mHinf(V) - mH))
dCa(dtbis::Float64,V::Float64,mCaT::Float64,hCaT::Float64,Ca::Float64,gCaT::Float64,k1::Float64,k2::Float64) = (dtbis)*(-k1*ICaT(V,mCaT,hCaT,gCaT) -k2*Ca)

function simulateCaT_spkt(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64, Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64,Cbis::Float64)
  V::Float64=-60.
  Vprev=-60.
  Ca::Float64=20.
  mNa::Float64=mNainf(V)
  hNa::Float64=hNainf(V)
  mKd::Float64=mKdinf(V)
  mCaT::Float64=mCaTinf(V)
  hCaT::Float64=hCaTinf(V)
  mH::Float64=mHinf(V)

  spkA1 = zeros(Tdtbis)
  l1=1
  spkB1 = zeros(Tdtbis)
  kk1=1
  spkA2 = zeros(Tdtbis)
  l2=1
  spkB2 = zeros(Tdtbis)
  kk2=1
  firing_flag=0

  Tstart::Int64 = convert(Int64,round(Tstepinit/dtbis))
  Tstop::Int64 = convert(Int64,round(Tstepfinal/dtbis))

  for z = 1:Tdtbis

    if z >= Tstart && z<= Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end

    V += dV(dtbis,V, Cbis, mNa, hNa, mKd, mCaT, hCaT, mH, Ca, Iapp, Iappstep, gCaT, gH, gKCa)

    Ca += dCa(dtbis, Vprev,mCaT,hCaT,Ca,gCaT,k1,k2)
    mNa += dmNa(dtbis, Vprev,mNa)
    hNa += dhNa(dtbis, Vprev,hNa)
    mKd += dmKd(dtbis,Vprev,mKd)
    mCaT += dmCaT(dtbis,Vprev,mCaT)
    hCaT += dhCaT(dtbis,Vprev,hCaT)
    mH += dmH(dtbis,Vprev,mH)
    if z >= Tstart+TdtTransientbis && z< Tstop
      if Vprev < -50. && V >= -50.
        spkA2[l2] = tbis[z]
        l2 +=1
      end
      if Vprev < -10. && V >= -10.
        if firing_flag==0
          spkB2[kk2] = tbis[z]
          firing_flag=1
          kk2 +=1
        else
          firing_flag=1
        end
      end
      if Vprev > -10. && V <= -10. && firing_flag==1
        firing_flag=0
      end
    else
      if z>=TdtTransientbis && z<Tstart
        if Vprev < -50. && V >= -50.
          spkA1[l1] = tbis[z]
          l1+=1
        end
        if Vprev < -10. && V >= -10.
          if firing_flag==0
            spkB1[kk1] = tbis[z]
            kk1+=1
            firing_flag=1
          else
            firing_flag=1
          end
        end
        if Vprev > -10. && V <= -10. && firing_flag==1
          firing_flag=0
        end
      end
    end

    Vprev = copy(V)
    #VV[z] = copy(V)
  end

  #return VV
  return spkA1, spkB1, spkA2, spkB2
end

function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
  ISI = zeros(5000000)
  l::Int64 = 1
  for i = 2:length(Spkt)
      ISI[l] = Spkt[i] - Spkt[i-1]
      l += 1
  end
  return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
  f = findall(ISI .== 0)
    if f[1] > 1
      ISI = ISI[1:f[1]-1]
    else
      ISI = [0.]
    end
  return ISI
end
#=
function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if(ISII[1]==0.0 && length(ISII)==1)
    bursting = 0
  else minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end
=#

function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end

function computeFrequ(ISI::Array{Float64})
  maxISI = maximum(ISI)
  intraburst = findall(ISI .<=maxISI/3)
  IBP = mean(ISI[intraburst])
  IBF = 1000/IBP
  return IBF
end

function computeSwitch(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64,  Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Ivecbis::Array{Float64}, Cvecbis::Array{Float64})
  lC =  length(Cvecbis)
  lI =  length(Ivecbis)
  FP_T = zeros(lC, lI)
  FP_B = zeros(lC, lI)
  switch = zeros(lC, lI)
  freq_T = zeros(lC, lI)
  freq_B = zeros(lC, lI)

  for j=1:lI
    display(j)
      for i=1:lC
          display(i)
          @time (spiketimesA1, spiketimesB1,spiketimesA2, spiketimesB2 ) = simulateCaT_spkt(Tdtbis, dtbis, tbis, TdtTransientbis, Iapp,Tstepinit,Tstepfinal,Ivecbis[j],Cvecbis[i])
          if sum(spiketimesA1) .== 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 0. #Silent
          elseif sum(spiketimesA1) .> 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB1))) ).== 1
              FP_T[i,j] = 2. #bursting
              freq_T[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB1))))
          else
              FP_T[i,j] = 3. #spiking
              freq_T[i,j]=1000/mean(remove0(ISIfunc(remove0(spiketimesB1))))
          end
          if sum(spiketimesA2) .== 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 0. #Silent
          elseif sum(spiketimesA2) .> 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB2))) ).== 1
              FP_B[i,j] = 2. #bursting
              freq_B[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB2))))
          else
              FP_B[i,j] = 3. #spiking
              freq_B[i,j] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB2))))
          end
          if(FP_T[i,j]==3. && FP_B[i,j]==2. && freq_T[i,j]<freq_B[i,j])
              switch[i,j] = 1.
          elseif(FP_T[i,j]==3. && FP_B[i,j]==2.)
              switch[i,j] = 0.5 #crit. non respected
          end
      end
  end


  return switch, FP_T, FP_B, freq_T, freq_B
end


function dV_plot(dtbis::Float64, V::Float64, C::Float64, mNa::Float64, hNa::Float64, mKd::Float64, mCaT::Float64, hCaT::Float64, mH::Float64, Ca::Float64, Iapp::Float64, Istep::Float64, gCaT::Float64, gH::Float64, gKCa::Float64)
  (dtbis)*(1/C)*(-gNa*mNa^3*hNa*(V-VNa) -gKd*mKd^4*(V-VK) -gl*(V-Vl) -ICaT(V,mCaT,hCaT,gCaT) -gKCa*mKCainf(Ca)*(V-VK) -gH*mH*(V-VH) +Iapp +Istep)
end

function simulateCaT_plot(Tdtbis::Int64, dtbis::Float64,Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64, C::Float64)
  V::Float64=-60.
  Vprev=-60.
  Ca::Float64=20.
  mNa::Float64=mNainf(V)
  hNa::Float64=hNainf(V)
  mKd::Float64=mKdinf(V)
  mCaT::Float64=mCaTinf(V)
  hCaT::Float64=hCaTinf(V)
  mH::Float64=mHinf(V)

  VV = zeros(Tdtbis)

  Tstart::Int64 = convert(Int64,round(Tstepinit/dtbis))
  Tstop::Int64 = convert(Int64,round(Tstepfinal/dtbis))

  for z = 1:Tdtbis

    if z >= Tstart && z<= Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end

    V += dV_plot(dtbis, V, C, mNa, hNa, mKd, mCaT, hCaT, mH, Ca, Iapp, Iappstep, gCaT, gH, gKCa)

    Ca += dCa(dtbis, Vprev,mCaT,hCaT,Ca,gCaT,k1,k2)
    mNa += dmNa(dtbis, Vprev,mNa)
    hNa += dhNa(dtbis, Vprev,hNa)
    mKd += dmKd(dtbis, Vprev,mKd)
    mCaT += dmCaT(dtbis, Vprev,mCaT)
    hCaT += dhCaT(dtbis, Vprev,hCaT)
    mH += dmH(dtbis, Vprev,mH)

    Vprev = copy(V)
    VV[z] = copy(V)
  end

  return VV
end
