# Defines output directory

name="RushMap"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include model
include("Rush_SWITCH.jl")

# Simulation parameters
const T = 7000
const Ttransient = 500

const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,round(Ttransient/dt))

const dt2 = 0.001
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,round(Ttransient/dt2))

const dt3 = 0.0001
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))



# Model parameters
const VNa = 55
const VK = -85
const VCa = 120
const gNa = 120
const gKd = 10
const gNaleak = 0.01429
const gKleak = 0.08571
const gCaT = 0.3

const tetas= -63
const ks= -7.8
const tetah = -72
const kh = 1.1
const sigm = 10.3
const sign = 9.3
const teta = 1 #3

#excitation
const Iapp=15.
#const Istep=-16.1
const T1= 1500
const T2= T
const coef_red_h = 1.
const coef_red_n = 1.


#Cvec = exp10.(range(1,2, length=10))
Ivec = [-15.6 -15.7 -15.8 -15.9 -16. -16.1 -16.2 -16.3]# do not switch after -16.4 -16.5]
#(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)


Cvec1 = collect(1:0.1:5)
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)


Cvec2 = collect(0.1:0.1:1)
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3 = collect(0.01:0.01:0.1)
Ivec3 = Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end, :];switch1[2:end, :]]#; switch[2:end, :]]
Cvec_TOT = [Cvec3; Cvec2[2:end, :];Cvec1[2:end, :]]#; Cvec[2:end, :]]

writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Rush/Map/Cvec_lin.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Rush/Map/switch_TOT_lin.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Rush/Map/Ivec_lin.dat", Ivec, header=false)


#figure(201)
imshow(switch_TOT, cmap="gray")
