clear 
clc
close all
set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');


%%

mat_Drion = plotMap('Drion');

[idx_Drion, val_Drion] = findCol1(mat_Drion); 
Istep_Drion = findIstep_optim(idx_Drion, 'Drion'); 

%mat_Drion3 = plotMap('Drion3');
%[idx_Drion3, val_Drion3] = findCol1(mat_Drion3); 
%Istep_Drion3 = findIstep_optim(idx_Drion3, 'Drion3'); 

mat_D = plotMap('Destexhe');
[idx_D, val_D] = findCol1(mat_D); 
Istep_Destexhe = findIstep_optim(idx_D, 'Destexhe'); 

%mat_D98 = plotMap('Destexhe98');
%[idx_D98, val_D98] = findCol1(mat_D98);
%Istep_D98 = findIstep_optim(idx_D98, 'Destexhe98'); 

mat_Du98 = plotMap('Destexheu98');
[idx_Du98, val_Du98] = findCol1(mat_Du98); 
Istep_Du98 = findIstep_optim(idx_Du98, 'Destexheu98'); 

mat_HM = plotMap('HM');
[idx_HM, val_HM] = findCol1(mat_HM); 
Istep_HM = findIstep_optim(idx_HM, 'HM'); 

mat_Rush = plotMap('Rush');
[idx_Rush, val_Rush] = findCol1(mat_Rush); 
Istep_Rush = findIstep_optim(idx_Rush, 'Rush'); 

mat_RushCa = plotMap('RushCa');
[idx_RushCa, val_RushCa] = findCol1(mat_RushCa);
Istep_RushCa = findIstep_optim(idx_RushCa, 'RushCa'); 

mat_RushCa2 = plotMap('RushCa2');
[idx_RushCa2, val_RushCa2] = findCol1(mat_RushCa2);
Istep_RushCa2 = findIstep_optim(idx_RushCa2, 'RushCa2');

mat_Wang = plotMap('Wang');
[idx_Wang, val_Wang] = findCol1(mat_Wang); 
Istep_Wang = findIstep_optim(idx_Wang, 'Wang'); 

mat_WangCa = plotMap('WangCa');
[idx_WangCa, val_WangCa] = findCol1(mat_WangCa); 
Istep_WangCa = findIstep_optim(idx_WangCa, 'WangCa'); 


%%

    Cvec1 = 1:0.1:5;
    Cvec2 = 0.1:0.1:1;
    Cvec3 = 0.01:0.01:0.1;
    C = [Cvec3 Cvec2(2:end) Cvec1(2:end)];

mat_tot = [  mat_Drion(:,idx_Drion), mat_D(:,idx_D), mat_Du98(:,idx_Du98), mat_HM(:,idx_HM), mat_Wang(:,idx_Wang), mat_Rush(:,idx_Rush),  mat_WangCa(:,idx_WangCa) , mat_RushCa(:,idx_RushCa)]; 
%mat_tot = [ mat_D98(:,idx_D98), mat_HM(:,idx_HM), mat_Wang(:,idx_Wang), mat_Rush(:,idx_Rush),  mat_WangCa(:,idx_WangCa) , mat_RushCa(:,idx_RushCa)]; 


for i=1:1:size(mat_tot,1)
    for j=1:1:size(mat_tot,2)
        if mat_tot(i,j)==0.5
            mat_tot(i,j)=1;
        end
       
    end
end

pt=18; 
figure
imagesc(mat_tot)
colormap gray
yticks([1 10 19 34 59])
yticklabels({'0.01','0.1','1', '2.5', '5'})
ylabel('C', 'interpreter','latex','fontsize',pt)
xlabel('Models', 'interpreter','latex','fontsize',pt)
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
xticks(1:8)
xticklabels({'Dr','D','Du98', 'HM', 'W', 'R', 'WCa', 'RCa'})
title('')
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 17 10]);

print('Figures/Map_lin_summary','-depsc')
print('Figures/Map_lin_summary','-dpdf')



%% FIND COL WITH MAX NUMBER OF 1

function [idx_max, val_max] = findCol1(value) 
    idx_max = 0; 
    val_max = 0;

    for i=1:1:size(value,2)
       for j=1:1:size(value,1)
            if(value(j,i)==0.5)
                value(j,i)=1;
            end
        end
        val_tmp = length(find(value(:,i)==1 ));
        if(val_tmp>val_max)
            val_max = val_tmp; 
            idx_max = i;
        end

    end
end

%% PLOT MAP

function value = plotMap(Name)%, ticky_mat,  ticky)
    value = load(sprintf('../%s/Map/switch_TOT_lin.dat',Name));
    Ivec = load(sprintf('../%s/Map/Ivec_lin.dat',Name));
    Cvec_julia = load(sprintf('../%s/Map/Cvec_lin.dat',Name));
 
    Cvec1 = 1:0.1:5;
    Cvec2 = 0.1:0.1:1;
    Cvec3 = 0.01:0.01:0.1;
    C = [Cvec3 Cvec2(2:end) Cvec1(2:end)];% Cvec(2:end)]; 
    
    ticky = {length(Ivec)};
    %ticky_mat = zeros(1,length(Ivec)); 
    index=1;
    indexbis=1;
    step=3;
    for zz=1:step:length(Ivec)
        ticky{index} = num2str(Ivec(zz));
        ticky_mat(index) = indexbis;
        indexbis=indexbis+step;
        index=index+1;
    end
    
    pt=18; 
    figure
    imagesc(value)
    colormap gray
    yticks([1 10 19 34 59])
    yticklabels({'0.01','0.1','1', '2.5', '5'})
    ylabel('C', 'interpreter','latex','fontsize',pt)
    xticks(ticky_mat)
    xticklabels(ticky)
    xlabel('Istep', 'interpreter','latex','fontsize',pt)
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    title('')
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 17 20]);
    print(sprintf('Figures/Map/%s_Map_lin', Name),'-depsc')
    print(sprintf('Figures/Map/%s_Map_lin', Name),'-dpdf')
    

end

%% 

function Istep = findIstep_optim(idx, Name) 
    Ivec = load(sprintf('../%s/Map/Ivec_lin.dat',Name));
    Istep =Ivec(idx);
end