close all 
clear all 
clc


set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');


%%

 plot_V('Drion', 'HIB')
 plot_V('Drion', 'PIR')
 plot_C('Drion', 'C0')
 plot_C('Drion','C1')
 plot_V('Destexhe', 'HIB')
 plot_V('Destexhe', 'PIR')

 plot_V('Destexhe98', 'HIB')
 plot_V('Destexhe98', 'PIR')
 
 plot_V('Destexheu98', 'HIB')
 plot_V('Destexheu98', 'PIR')
  
 plot_V('HM', 'HIB')
 plot_V('HM', 'PIR')
  
 plot_V('Rush', 'HIB')
 plot_V('Rush', 'PIR')
 
 plot_V('RushCa', 'HIB')
 plot_V('RushCa', 'PIR')
  
  plot_V('Wang', 'HIB')
  plot_V('Wang', 'PIR')
  plot_C('Wang', 'C0')
  plot_C('Wang','C1')
 
  
 plot_V('WangCa', 'HIB')
 plot_V('WangCa', 'PIR')
plot_C('WangCa', 'C1.0')
plot_C('WangCa', 'C0.2')
%%
function plot_V (Name, Name_expm)
    pt=11;
    t= load(sprintf('../%s/V/t_%s.dat',Name, Name_expm));
    V = load(sprintf('../%s/V/V_%s.dat',Name, Name_expm));
    figure
    plot(t,V, 'color', [64/256 64/256 64/256])
    ylim([-110 70])
    xlim([min(t)-100 max(t)+100])
    box off
    title('')
    xticks([500,1000])
    xticklabels({'500','1000'})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    yticks([-20,30])
    yticklabels({'0','50'})
    b = get(gca,'YTickLabel');
    set(gca,'YTickLabel',b,'fontsize',pt)
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 8 3]);
    print(sprintf('Figures/V/%s_%s', Name, Name_expm),'-depsc')
    print(sprintf('Figures/V/%s_%s', Name, Name_expm),'-dpdf')

end

%%
function plot_C (Name, Name_expm)
    pt=11;
    t= load(sprintf('../%s/V/t_%s.dat',Name, Name_expm));
    V = load(sprintf('../%s/V/V_%s.dat',Name, Name_expm));
    if(strcmp(Name_expm, 'C1.0'))
        Name_expm='C1';
    end
    if(strcmp(Name_expm, 'C0.2'))
        Name_expm='C0';
    end
    figure
    plot(t,V, 'color', [64/256 64/256 64/256])
    ylim([-110 70])
    xlim([min(t)-100 max(t)+100])
    box off
    title('')
    xticks([500,1000])
    xticklabels({'500','1000'})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    yticks([-20,30])
    yticklabels({'0','50'})
    b = get(gca,'YTickLabel');
    set(gca,'YTickLabel',b,'fontsize',pt)
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 8 3]);
    print(sprintf('Figures/V/%s_%s', Name, Name_expm),'-depsc')
    print(sprintf('Figures/V/%s_%s', Name, Name_expm),'-dpdf')

end
