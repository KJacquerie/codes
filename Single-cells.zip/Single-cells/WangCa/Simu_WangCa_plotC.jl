# Defines output directory
#cd("./")
file_name="WangCa"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf


# Include model
include("WangCa_model.jl")


# Simulation parameters
const T = 2000
const dt = 0.001
const Ttransient = 500

const Tdt = convert(Int64,T/dt)
const t = range(dt,T,length=Tdt)
const TdtTransient = convert(Int64,Ttransient/dt)



# Model parameters
const VCa = 120.
const VH = -40.
const VK = -80.
const VNa = 55.
const Vl = -70.
const sigK = 10.
const sigNa = 6.
const sigNaP = -5.
const thetah = -79.
const kh = 5.
const gH = 0.04
const gKd = 30.
const gNa = 42.
const gNaP = 9.
const gl = 0.12
const gCaT =  1.

const theta_red = 5.

# excitation

const name_expm = "C"
const C=0.1
const T1 = 500
const T2 = T
const Iapp = 3.
const Istep = -4.3

yy = simulateTC_wangca(C,Iapp, Istep, T1, T2, gCaT)
writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s%s.dat", file_name, name_expm, C), t, header=false)
writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s%s.dat", file_name, name_expm, C), yy, header=false)

plot(t,yy)
