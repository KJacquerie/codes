# gating functions
# calcium activation
mCaTinf(V::Float64) = 1/(1+exp(-(V+65)/7.8))
taumCaT(V::Float64) = theta_red/2*(1.7 + exp(-(V+2+28.8)/13.5))/(1+exp(-(V+63+2)/7.8))

#calcium inactivation
hCaTinf(V::Float64,thetah::Float64,kh::Float64) = 1/(1+exp((V-thetah)/kh))
tauhCaT(V::Float64,thetah::Float64,kh::Float64) = theta_red*((1/(1+exp((V-thetah)/kh)))*exp((V+162.3)/17.8)+20.0)

#H activation
mHinf(V::Float64) = 1/(1+exp((V+69)/7.1))
taumH(V::Float64) = 1000/(exp((V+66.4)/9.3)+exp(-(V+81.6)/13))

# potassium activation
alphan(V::Float64,sigK::Float64) = -0.01*(V+45.7-sigK)/(exp(-0.1*(V+45.7-sigK))-1)
betan(V::Float64,sigK::Float64) = 0.125*exp(-(V+55.7-sigK)/80)
ninf(V::Float64,sigK::Float64) = alphan(V,sigK)/(alphan(V,sigK)+betan(V,sigK))
taun(V::Float64,sigK::Float64) = 1/(alphan(V,sigK)+betan(V,sigK))

#sodium activation
alpham(V::Float64,sigNa::Float64) = -0.1*(V+29.7-sigNa)/(exp(-0.1*(V+29.7-sigNa))-1)
betam(V::Float64,sigNa::Float64) = 4*exp(-(V+54.7-sigNa)/18)
minf(V::Float64,sigNa::Float64) = alpham(V,sigNa)/(alpham(V,sigNa)+betam(V,sigNa))

function dV_wang(C::Float64, V::Float64, mCaT::Float64, hCaT::Float64, mH::Float64, n::Float64, Iapp::Float64, Iappstep::Float64, gCaT::Float64)
  (dt)*(1/C)*(-gCaT*mCaT^3*hCaT*(V-VCa) -gH*mH^2*(V-VH) -gKd*n^4*(V-VK) -gNa*minf(V,sigNa)^3*(0.85-n)*(V-VNa) -gNaP*minf(V,sigNaP)^3*(V-VNa) - gl*(V-Vl) + Iapp + Iappstep)
end
dmCaT(V::Float64,mCaT::Float64) = (dt)*((1/taumCaT(V))*(mCaTinf(V)- mCaT))
dhCaT(V::Float64,hCaT::Float64,thetah::Float64,kh::Float64) = (dt)*((2/tauhCaT(V,thetah,kh))*(hCaTinf(V,thetah,kh) - hCaT))
dmH(V::Float64,mH::Float64) = (dt)*((1/taumH(V))*(mHinf(V) - mH))
dn(V::Float64,n::Float64,sigK::Float64) = (dt)*(((200/7)/taun(V,sigK))*(ninf(V,sigK) - n))

function simulateTC_wangca(C::Float64,Iapp::Float64, Istep::Float64, Tstepinit::Int64, Tstepfinal::Int64, gCaT::Float64)
  V::Float64=-70.
  Vprev::Float64=-70.
  mCaT::Float64 = mCaTinf(V)
  hCaT::Float64=hCaTinf(V,thetah,kh)
  mH::Float64=mHinf(V)
  n::Float64=ninf(V,sigK)

  VV = zeros(Tdt)
  Tstart::Int64 = convert(Int64, Tstepinit/dt)
  Tstop::Int64 = convert(Int64, Tstepfinal/dt)

  for z= 1:Tdt
    if z>=Tstart && z<=Tstop
      Iappstep = Istep
    else
      Iappstep = 0.
    end

    V += dV_wang(C,V,mCaT,hCaT,mH,n,Iapp,Iappstep, gCaT)
    mCaT+= dmCaT(Vprev, mCaT)
    hCaT += dhCaT(Vprev,hCaT,thetah,kh)
    mH += dmH(Vprev,mH)
    n += dn(Vprev,n,sigK)

    Vprev = copy(V)
    VV[z] = copy(V)
  end

  return VV
end
