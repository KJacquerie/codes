# Defines output directory
file_name="Destexhe"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

#include Model
include("Destexhe_model.jl")


#test_name = "tonic"

# Simulation Paramaters
const T = 2000
const dt = 0.0005
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)


# Models parameters
# V en mV
# g en S/cm2
const VNa = 50
const VK = -100
const Vleak= -82
const VCa = 120
const Vtraub=-63.

const gNa = 0.4
const gK = 0.08
const gNaleak = 0
const gKleak = 0
const gleak= 5e-5


const C = 1.e-3 #nF
const coef_red  = 1.
const coef_redm = 1.

# excitation

const name_expm = "HIB"
const Iapp = 0.4e-3
const Istep = -0.4e-3
const Tstepinit = 500
const Tstepfinal = T
const gCa = 0.006

#=
const name_expm = "PIR"
const Iapp = 0.1e-3
const Istep = -0.2e-3
const Tstepinit = 500
const Tstepfinal = 1000
const gCa = 0.003
=#

# run model
@time (yy,mm,hh)= simulateTC(Iapp, Tstepinit, Tstepfinal, Istep,gCa)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s.dat", file_name, name_expm), t, header=false)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s.dat", file_name,name_expm), yy, header=false)

plot(t, yy)
