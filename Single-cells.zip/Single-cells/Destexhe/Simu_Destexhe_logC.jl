# Defines output directory
#cd("./")"
name="DestexheMap"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView


#Include model
include("Destexhe_SWITCH.jl")


# Simulation parameters
const T = 7000
const Ttransient = 500

const dt = 0.05
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,round(Ttransient/dt))

const dt2 = 0.0005
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,round(Ttransient/dt2))

const dt3 = 0.00005
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))



# Models parameters
const VNa = 50
const VK = -100
const Vleak=-82
const VCa = 120
const Vtraub=-63.

const gNa = 0.4 # au lieu de 0.1
const gK = 0.08
const gNaleak = 0
const gKleak = 0
const gleak= 5e-5
const gCa = 0.006

#excitation
const Iapp=0.4e-3#0.4
#I1=-0.3e-3#-0.3
#I2=-0.4e-3#-0.4
#I3=-0.6e-3#-0.9

const T1= 1500
const T2= T

# NOMINAL VALUE
const Cnom = 1.e-3
const coef_red_h=1.
const coef_red_m=1.

Cvec = exp10.(range(1,2, length=10))*Cnom
Ivec = [-0.15e-3 -0.2e-3 -0.25e-3  -0.3e-3 -0.35e-3 -0.4e-3 -0.45e-3 -0.5e-3 -0.55e-3 -0.6e-3 -0.65e-3 ] # bounds 0.175 > 0.625
(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)


Cvec1=exp10.(range(0,1, length=10))*Cnom
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)


Cvec2=exp10.(range(-1,0, length=10))*Cnom
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3=exp10.(range(-2,-1, length=10))*Cnom
Ivec3 = Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end,:]; switch1[2:end,:]; switch[2:end,:]]
Cvec_TOT = [Cvec3; Cvec2[2:end,:]; Cvec1[2:end,:]; Cvec[2:end,:]]
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexhe/Map/Cvec.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexhe/Map/switch_TOT.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexhe/Map/Ivec.dat", Ivec, header=false)

#figure(100)
imshow(switch_TOT, cmap="gray")


#PLOT
#=
Cvecplot=[0.01 0.05 0.1 0.5 1. 5.]*Cnom #[0.01 0.02 0.05 0.1 0.2 0.5 1 5]*C
PyPlot.close("all")
figure
for i=1:length(Cvecplot)
    if(Cvecplot[i]<=0.1*Cnom)
        Tdtplot = Tdt3
        tplot=t3
        dtplot=dt3
        Ivec = [-0.8e-3 -0.9e-3 -1.e-3]

    else
        if(Cvecplot[i]<1.*Cnom)
            Tdtplot=Tdt2
            tplot=t2
            dtplot=dt2
            Ivec = [-0.43e-3 -0.48e-3 -0.65e-3]
        else
            Tdtplot=Tdt
            tplot=t
            dtplot=dt
            Ivec = Istepvec
        end
    end
    @time VV = simulateDestexhe_plot(Tdtplot,dtplot,Cvecplot[i], Ivec)
    subplot(3,2,i)
    Vplot = plot(tplot,VV,"-")
    axis([500,T,-90,60])
end
#savefig("../Analysis/Vplot_Destexhe_Cplot.eps")
=#

#FRANCI FP
#=
Cvec=logspace(-2.,-1.,10)
FP=zeros(length(Cvec),4)
switch=zeros(length(Cvec)) # oui ou non il y a eu un step
freq=zeros(length(Cvec),4) # donne la frequence du FP a chaque step
for i=1:length(Cvec)
    display(i)
    @time (spiketimesA, spiketimesB ) = simulateDestexhe_spkt(Tdt, dt, t, TdtTransient, Cvec[i])
    for jj=1:4
        if sum(spiketimesA[:,jj]) .== 0 && sum(spiketimesB[:,jj]) .== 0
            FP[i,jj] = 0. #Silent
            freq[i,jj] =0.
        elseif sum(spiketimesA[:,jj]) .> 0 && sum(spiketimesB[:,jj]) .== 0
            FP[i,jj] = 1. #Slow oscillation
            freq[i,jj] =0.
        elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[:,jj]))) ).== 1
            FP[i,jj] = 2. #bursting
            freq[i,jj]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        else
            FP[i,jj] = 3. #spiking
            freq[i,jj] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        end
    end
    if(FP[i,1]==3. && FP[i,2]==2. && freq[i,1]*1.5<=freq[i,2])
        switch[i] = 5.
    elseif(FP[i,2]==3. && FP[i,3]==2. && freq[i,2]*1.5<=freq[i,3])
        switch[i] = 5.
    elseif(FP[i,3]==3. && FP[i,4]==2. && freq[i,3]*1.5<=freq[i,4])
        switch[i] = 5.
    end
end

Cvec2=logspace(-4.,-2.,15)
FP2 =zeros(length(Cvec2),4)
switch2=zeros(length(Cvec2))
freq2=zeros(length(Cvec2),4)
for i=1:length(Cvec2)
    display(i)
    @time (spiketimesA, spiketimesB) = simulateDestexhe_spkt(Tdt2, dt2, t2, TdtTransient2, Cvec2[i])
    for jj=1:4
        if sum(spiketimesA[:,jj]) .== 0 && sum(spiketimesB[:,jj]) .== 0
            FP2[i,jj] = 0. #Silent
        elseif sum(spiketimesA[:,jj]) .> 0 && sum(spiketimesB[:,jj]) .== 0
            FP2[i,jj] = 1. #Slow oscillation
        elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[:,jj]))) ).== 1
            FP2[i,jj] = 2. #bursting
            freq2[i,jj]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        else
            FP2[i,jj] = 3. #spiking
            freq2[i,jj] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        end
    end
    if(FP2[i,1]==3. && FP2[i,2]==2. && freq2[i,1]*1.5<=freq2[i,2])
        switch2[i] = 5.
    elseif(FP2[i,2]==3. && FP2[i,3]==2. && freq2[i,2]*1.5<=freq2[i,3])
        switch2[i] = 5.
    elseif(FP2[i,3]==3. && FP2[i,4]==2. && freq2[i,3]*1.5<=freq2[i,4])
        switch2[i] = 5.
    end
end

Cvec3=logspace(-5.,-4.,5)
FP3=zeros(length(Cvec3),4)
switch3=zeros(length(Cvec3))
freq3=zeros(length(Cvec3),4)
for i=1:length(Cvec3)
    display(i)
    @time (spiketimesA, spiketimesB) = simulateDestexhe_spkt(Tdt3, dt3, t3, TdtTransient3,Cvec3[i])
    for jj=1:4
        if sum(spiketimesA[:,jj]) .== 0 && sum(spiketimesB[:,jj]) .== 0
            FP3[i,jj] = 0. #Silent
        elseif sum(spiketimesA[:,jj]) .> 0 && sum(spiketimesB[:,jj]) .== 0
            FP3[i,jj] = 1. #Slow oscillation
        elseif isbursting(remove0(ISIfunc(remove0(spiketimesB[:,jj]))) ).== 1
            FP3[i,jj] = 2. #bursting
            freq3[i,jj]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        else
            FP3[i,jj] = 3. #spiking
            freq3[i,jj] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB[:,jj]))))
        end
    end
    if(FP3[i,1]==3. && FP3[i,2]==2. && freq3[i,1]*1.5<=freq3[i,2])
        switch3[i] = 5.
    elseif(FP3[i,2]==3. && FP3[i,3]==2. && freq3[i,2]*1.5<=freq3[i,3])
        switch3[i] = 5.
    elseif(FP3[i,3]==3. && FP3[i,4]==2. && freq3[i,3]*1.5<=freq3[i,4])
        switch3[i] = 5.
    end
end

figure(2)
hold("on")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,1];FP2[:,1];FP[:,1]],"*")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,2]+0.1;FP2[:,2]+0.1;FP[:,2]+0.1],"o")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,3]+0.2;FP2[:,3]+0.2;FP[:,3]+0.2],".")
semilogx([Cvec3;Cvec2;Cvec],[FP3[:,4]+0.3;FP2[:,4]+0.3;FP[:,4]+0.3],"+")
semilogx([Cvec3;Cvec2;Cvec],[switch3-0.5;switch2-0.5;switch-0.5],"^")
hold("off")
xlim([0.005*Cnom,200*Cnom])
ylim([-1,5])
savefig("../Analysis/Vplot_DestexheSWITCH4_FPvsC.eps")

figure(3)
hold("on")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,1];freq2[:,1];freq[:,1]],"*")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,2];freq2[:,2];freq[:,2]],"o")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,3];freq2[:,3];freq[:,3]],".")
semilogx([Cvec3;Cvec2;Cvec],[freq3[:,4];freq2[:,4];freq[:,4]],"+")
hold("off")
savefig("../Analysis/Vplot_DestexheSWITCH4_freq.eps")
=#
#=
writedlm(@sprintf("../Analysis/%s_FP.dat", name), FP, header=false)
writedlm(@sprintf("../Analysis/%s_FP2.dat", name), FP2, header=false)
writedlm(@sprintf("../Analysis/%s_FP3.dat", name), FP3, header=false)
writedlm(@sprintf("../Analysis/%s_Cvec.dat", name), Cvec, header=false)
writedlm(@sprintf("../Analysis/%s_Cvec2.dat", name), Cvec2, header=false)
writedlm(@sprintf("../Analysis/%s_Cvec3.dat", name), Cvec3, header=false)
=#
