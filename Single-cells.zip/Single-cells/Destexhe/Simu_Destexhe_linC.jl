# Defines output directory
#cd("./")"
name="DestexheMap"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView


#Include model
include("Destexhe_SWITCH.jl")


# Simulation parameters
const T = 7000
const Ttransient = 500

const dt = 0.05
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,round(Ttransient/dt))

const dt2 = 0.0005
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,round(Ttransient/dt2))

const dt3 = 0.00005
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))



# Models parameters
const VNa = 50
const VK = -100
const Vleak=-82
const VCa = 120
const Vtraub=-63.

const gNa = 0.4 # au lieu de 0.1
const gK = 0.08
const gNaleak = 0
const gKleak = 0
const gleak= 5e-5
const gCa = 0.006

#excitation
const Iapp=0.4e-3#0.4
#I1=-0.3e-3#-0.3
#I2=-0.4e-3#-0.4
#I3=-0.6e-3#-0.9

const T1= 1500
const T2= T

# NOMINAL VALUE
const Cnom = 1.e-3
const coef_red_h=1.
const coef_red_m=1.

#Cvec = collect(1*Cnom:0.1*Cnom:5*Cnom) #exp10.(range(1,2, length=10))*Cnom
Ivec = [-0.15e-3 -0.2e-3 -0.25e-3  -0.3e-3 -0.35e-3 -0.4e-3 -0.45e-3 -0.5e-3 -0.55e-3 -0.6e-3 -0.65e-3 ] # bounds 0.175 > 0.625
#(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)


Cvec1=collect(1*Cnom:0.1*Cnom:5*Cnom)#exp10.(range(0,1, length=10))*Cnom
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)


Cvec2= collect(0.1*Cnom:0.1*Cnom:1*Cnom)
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3 = collect(0.01*Cnom:0.01*Cnom:0.1*Cnom)
Ivec3 = Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end,:]; switch1[2:end,:]]#; switch[2:end,:]]
Cvec_TOT = [Cvec3; Cvec2[2:end,:]; Cvec1[2:end,:]]#; switch[2:end,:]]
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexhe/Map/Cvec_lin.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexhe/Map/switch_TOT_lin.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexhe/Map/Ivec_lin.dat", Ivec, header=false)

#figure(100)
imshow(switch_TOT, cmap="gray")
