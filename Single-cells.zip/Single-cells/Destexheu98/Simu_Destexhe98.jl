# Defines output directory
#cd("/Users/...")

const file_name = "Destexheu98"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# ODE
include("Destexhe98_model.jl")

# Simulation Paramaters
const T = 2000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const t = range(dt,T,length=Tdt)


# Models parameters
# V en mV
# g en S/cm2
const C = 0.88  #e-3 # nF
const VNa = 50
const VK = -100
const VCa = 120
const Vleak= -70
const Vtraub=-52.

const gNa = 100.
const gNaleak = 0
const gK = 100.
const gKleak = 0
const gleak= 5e-2


const coef_red = 1.


# excitation

const name_expm = "HIB"
const Iapp = 1.
const Istep = -1.75
const Tstepinit = 500
const Tstepfinal = T
const gCa = 3.3


#=
const name_expm = "PIR"
const Iapp =-0.8
const Istep = -1.
const Tstepinit = 500
const Tstepfinal = 1000
const gCa = 3.3
=#


@time yy= simulateTC(Iapp, Tstepinit, Tstepfinal, Istep,gCa)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/t_%s.dat", file_name, name_expm), t, header=false)
#writedlm(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/%s/V/V_%s.dat", file_name, name_expm), yy, header=false)


plot(t, yy)
