# gating functions
V2(V::Float64) = V - Vtraub

# SODIUM activation
alpha_m(V::Float64) = 0.32 * (13 - V2(V)) / (exp((13-V2(V))/4) -1)
beta_m(V::Float64)  = 0.28 * (V2(V) - 40) / (exp((V2(V)-40)/5) -1)
tau_m(V::Float64) = 1 / (alpha_m(V) + beta_m(V))
m_inf(V::Float64) = alpha_m(V)/ (alpha_m(V) + beta_m(V))

# SODIUM inactivation
alpha_h(V::Float64) = 0.128 * exp((17-V2(V))/18)
beta_h(V::Float64)  = 4 / (1 + exp((40-V2(V))/5))
tau_h(V::Float64) = 1/ (alpha_h(V) + beta_h(V))
h_inf(V::Float64) = alpha_h(V)/ (alpha_h(V) + beta_h(V))

# POTASSIUM
alpha_n(V::Float64) = 0.032 * (15-V2(V)) / ( exp((15-V2(V))/5) - 1)
beta_n(V::Float64)  = 0.5 * exp((10-V2(V))/40)
tau_n(V::Float64) = 1/ (alpha_n(V) + beta_n(V))
n_inf(V::Float64) = alpha_n(V)/ (alpha_n(V) + beta_n(V))

# CALCIUM activation
mCa_inf(V::Float64) = 1/(1+exp(-(V+59)/6.2))
tau_mCa(V::Float64) = 0.204 + 0.333/( exp((V+18.8)/18.2) + exp(-(V+134)/16.7) )

# CALCIUM inactivation
hCa_inf(V::Float64) = 1/(1+exp((V+83)/4))

function tau_hCa(V::Float64)
    if(V<-80)
        tau=0.33*exp((V+469)/66.6)
    else
        tau=9.32 + 0.33*exp(-(V+24)/10.5)
    end
    return tau
end

# derivative functions
function dV_D98(dtbis::Float64, C::Float64,V::Float64, m::Float64, h::Float64, n::Float64, mCa::Float64, hCa::Float64, Iapp::Float64, Istep::Float64)
    (dtbis)*(1/C)*(-gNa*m^3*h*(V-VNa) - gK*n^4*(V-VK) - gCa*mCa^2*hCa*(V-VCa) - gNaleak*(V-VNa) -gleak*(V-Vleak) - gKleak*(V-VK) + Iapp + Istep  )
end


dm(dtbis::Float64, V::Float64, m::Float64)     = (dtbis)* ((1/tau_m(V))   *(m_inf(V) - m))
dh(dtbis::Float64, V::Float64, h::Float64)     = (dtbis)* ((1/tau_h(V))   *(h_inf(V) - h))
dn(dtbis::Float64, V::Float64, n::Float64)     = (dtbis)* ((1/tau_n(V))   *(n_inf(V) - n))
dmCa(dtbis::Float64, V::Float64, mCa::Float64) = (dtbis)* ((1/tau_mCa(V)) *(mCa_inf(V) - mCa))
dhCa(dtbis::Float64, V::Float64, hCa::Float64) = (dtbis)* ((1/tau_hCa(V)) *(hCa_inf(V) - hCa))



# simulations
function simulateD98_spkt(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64,  Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Istep::Float64,  Cbis::Float64)
# initial conditions
    V::Float64 = -74. #80
    Vprev::Float64 = -74. #80
    m::Float64 = m_inf(V)
    h::Float64 = h_inf(V)
    n::Float64 = n_inf(V)
    mCa::Float64 = mCa_inf(V)
    hCa::Float64 = hCa_inf(V)


    Tstart::Int64 = convert(Int64, round(Tstepinit/dtbis))
    Tstop::Int64 = convert(Int64, round(Tstepfinal/dtbis))

    spkA1 = zeros(Tdtbis)
    l1=1
    spkB1 = zeros(Tdtbis)
    k1=1
    spkA2 = zeros(Tdtbis)
    l2=1
    spkB2 = zeros(Tdtbis)
    k2=1
    firing_flag=0

    for z= 1:Tdtbis

        if z>=Tstart && z<=Tstop
          Iappstep = Istep
        else
          Iappstep = 0.
        end

        V  +=dV_D98(dtbis,Cbis, V, m, h, n, mCa, hCa, Iapp, Iappstep)
        m  +=dm(dtbis, Vprev,m)
        h  +=dh(dtbis,Vprev,h)
        n  +=dn(dtbis,Vprev,n)
        mCa+=dmCa(dtbis,Vprev,mCa)
        hCa+=dhCa(dtbis,Vprev,hCa)

        if z >= Tstart+TdtTransientbis && z< Tstop
          if Vprev < -50. && V >= -50.
            spkA2[l2] = tbis[z]
            l2 +=1
          end
          if Vprev < -10. && V >= -10.
            if firing_flag==0
              spkB2[k2] = tbis[z]
              firing_flag=1
              k2 +=1
            else
              firing_flag=1
            end
          end
          if Vprev > -10. && V <= -10. && firing_flag==1
            firing_flag=0
          end
        else
          if z>=TdtTransientbis && z<Tstart
            if Vprev < -50. && V >= -50.
              spkA1[l1] = tbis[z]
              l1+=1
            end
            if Vprev < -10. && V >= -10.
              if firing_flag==0
                spkB1[k1] = tbis[z]
                k1+=1
                firing_flag=1
              else
                firing_flag=1
              end
            end
            if Vprev > -10. && V <= -10. && firing_flag==1
              firing_flag=0
            end
          end
        end

        Vprev = copy(V)
        #VV[z] = copy(V)
    end

      #return VV
    return spkA1, spkB1, spkA2, spkB2
end


function ISIfunc(Spkt::Array{Float64})   # Computes the interspike intervals out of spike times
    ISI = zeros(5000000)
    l::Int64 = 1
    for i = 2:length(Spkt)
        ISI[l] = Spkt[i] - Spkt[i-1]
        l += 1
    end
        return ISI
end

function remove0(ISI::Array{Float64})    # Removes 0's in spike times/interspike intervals vectors
    f = findall(ISI .== 0)
    if f[1] > 1
        ISI = ISI[1:f[1]-1]
    else
        ISI = [0.]
    end
    return ISI
end

function isbursting(ISI::Array{Float64})   # Check if the neuron is bursting using the rule 3*minISI < maxISI
  bursting::Int64 = 0
  if minimum(ISI)*3 < maximum(ISI)
      bursting = 1
  end
  return bursting
end

function computeFrequ(ISI::Array{Float64})
  maxISI = maximum(ISI)
  intraburst = findall(ISI .<=maxISI/3)
  IBP = mean(ISI[intraburst])
  IBF = 1000/IBP
  return IBF
end


function computeSwitch(Tdtbis::Int64, dtbis::Float64, tbis::StepRangeLen{Float64,Base.TwicePrecision{Float64},Base.TwicePrecision{Float64}}, TdtTransientbis::Int64,  Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Ivecbis::Array{Float64}, Cvecbis::Array{Float64})
  lC =  length(Cvecbis)
  lI =  length(Ivecbis)
  FP_T = zeros(lC, lI)
  FP_B = zeros(lC, lI)
  switch = zeros(lC, lI)
  freq_T = zeros(lC, lI)
  freq_B = zeros(lC, lI)

  for j=1:lI
    display(j)
      for i=1:lC
          display(i)
          @time (spiketimesA1, spiketimesB1,spiketimesA2, spiketimesB2 ) = simulateD98_spkt(Tdtbis, dtbis, tbis, TdtTransientbis, Iapp,Tstepinit,Tstepfinal,Ivecbis[j],Cvecbis[i])
          if sum(spiketimesA1) .== 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 0. #Silent
          elseif sum(spiketimesA1) .> 0 && sum(spiketimesB1) .== 0
              FP_T[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB1))) ).== 1
              FP_T[i,j] = 2. #bursting
              freq_T[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB1))))
          else
              FP_T[i,j] = 3. #spiking
              freq_T[i,j]=1000/mean(remove0(ISIfunc(remove0(spiketimesB1))))
          end
          if sum(spiketimesA2) .== 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 0. #Silent
          elseif sum(spiketimesA2) .> 0 && sum(spiketimesB2) .== 0
              FP_B[i,j] = 1. #Slow oscillation
          elseif isbursting(remove0(ISIfunc(remove0(spiketimesB2))) ).== 1
              FP_B[i,j] = 2. #bursting
              freq_B[i,j]=computeFrequ(remove0(ISIfunc(remove0(spiketimesB2))))
          else
              FP_B[i,j] = 3. #spiking
              freq_B[i,j] = 1000/mean(remove0(ISIfunc(remove0(spiketimesB2))))
          end
          if(FP_T[i,j]==3. && FP_B[i,j]==2. && freq_T[i,j]<freq_B[i,j])
              switch[i,j] = 1.
          elseif(FP_T[i,j]==3. && FP_B[i,j]==2.)
              switch[i,j] = 0.5 #crit. non respected
          end
      end
  end


  return switch, FP_T, FP_B, freq_T, freq_B
end



function simulateD98_plot(Tdtbis::Int64, dtbis::Float64, C::Float64)
# initial conditions
    V::Float64 = -74. #80
    Vprev::Float64 = -74. #80
    m::Float64 = m_inf(V)
    h::Float64 = h_inf(V)
    n::Float64 = n_inf(V)
    mCa::Float64 = mCa_inf(V)
    hCa::Float64 = hCa_inf(V)

    VV = zeros(Tdtbis)

    Tstep1::Int64 = convert(Int64,round(T1/dtbis))
    Tstep2::Int64 = convert(Int64,round(T2/dtbis))
    Tstep3::Int64 = convert(Int64, round(T3/dtbis))
    TstepFinal::Int64 = convert(Int64,round(Tstop/dtbis))


    for z= 1:Tdtbis

        if z >= Tstep1 && z< Tstep2
          Iappstep = Istep1
        elseif z >= Tstep2 && z< Tstep3
          Iappstep = Istep2
        elseif z >= Tstep3 && z< TstepFinal
          Iappstep = Istep3
        else
          Iappstep = 0.
        end

        V  +=dV_D98(dtbis,C, V, m, h, n, mCa, hCa, Iapp, Iappstep)
        m  +=dm(dtbis, Vprev,m)
        h  +=dh(dtbis,Vprev,h)
        n  +=dn(dtbis,Vprev,n)
        mCa+=dmCa(dtbis,Vprev,mCa)
        hCa+=dhCa(dtbis,Vprev,hCa)


        Vprev = copy(V)
        VV[z] = copy(V)
    end

    return VV
end
