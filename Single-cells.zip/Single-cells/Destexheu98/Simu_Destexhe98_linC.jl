# Defines output directory
name="Destexhe98Map"

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Model
include("Destexhe98_SWITCH.jl")


# Simulation Paramaters
const T = 7000
const Ttransient = 500

const dt = 0.01
const Tdt = convert(Int64,T/dt)
const t = range(dt, T, length=Tdt)
const TdtTransient = convert(Int64,Ttransient/dt)

const dt2 = 0.001
const Tdt2 = convert(Int64,T/dt2)
const t2 = range(dt2, T, length=Tdt2)
const TdtTransient2 = convert(Int64,Ttransient/dt2)

const dt3 = 0.0001
const Tdt3 = convert(Int64,round(T/dt3))
const t3 = range(dt3, T, length=Tdt3)
const TdtTransient3 = convert(Int64,round(Ttransient/dt3))


# Models parameters
# V en mV
# g en S/cm2
const VNa = 50
const Vleak= -70
const VCa = 120
const Vtraub=-52. #au lieu de -63
const VK = -100

const gNa = 100.
const gNaleak = 0
const gK = 100.
const gKleak = 0
const gleak= 5e-2 #5 #papier 4 ?
const gCa=3.3

const Cnom = 0.88

#excitation
const Iapp=1.5
const T1= 1500
const T2= T
#const T3= 4500
#const Tstop= T


#Cvec=collect(1*Cnom:0.1*Cnom:5*Cnom)
Ivec = [ -1.6 -1.7 -1.8 -1.9 -2 -2.1 -2.2 -2.3 -2.4 -2.5]
#(switch, FP_T, FP_B, freq_T, freq_B) = computeSwitch(Tdt, dt, t, TdtTransient,  Iapp, T1, T2, Ivec, Cvec)

Cvec1=collect(1*Cnom:0.1*Cnom:5*Cnom)
Ivec1 = Ivec
(switch1, FP_T1, FP_B1, freq_T1, freq_B1) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec1, Cvec1)

Cvec2=collect(0.1*Cnom:0.1*Cnom:1*Cnom)
Ivec2 = Ivec
(switch2, FP_T2, FP_B2, freq_T2, freq_B2) = computeSwitch(Tdt2, dt2, t2, TdtTransient2,  Iapp, T1, T2, Ivec2, Cvec2)

Cvec3=collect(0.01*Cnom:0.01*Cnom:0.1*Cnom)
Ivec3 = Ivec
(switch3, FP_T3, FP_B3, freq_T3, freq_B3) = computeSwitch(Tdt3, dt3, t3, TdtTransient3,  Iapp, T1, T2, Ivec3, Cvec3)


switch_TOT = [switch3; switch2[2:end,:]; switch1[2:end,:]]#; switch[2:end,:]]
Cvec_TOT = [Cvec3; Cvec2[2:end,:]; Cvec1[2:end,:]]
writedlm("/Users/kathleen/Documents/PhD/2020-Project/Single-cells/Destexheu98/Map/Cvec_lin.dat", Cvec_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-project/Single-cells/Destexheu98/Map/switch_TOT_lin.dat", switch_TOT, header=false)
writedlm("/Users/kathleen/Documents/PhD/2020-project/Single-cells/Destexheu98/Map/Ivec_lin.dat", Ivec, header=false)


imshow(switch_TOT, cmap="gray")
