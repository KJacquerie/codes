# gating functions
V2(V::Float64) = V - Vtraub

# SODIUM activation
alpha_m(V::Float64) = 0.32 * (13 - V2(V)) / (exp((13-V2(V))/4) -1)
beta_m(V::Float64)  = 0.28 * (V2(V) - 40) / (exp((V2(V)-40)/5) -1)
tau_m(V::Float64) = 1 / (alpha_m(V) + beta_m(V))
m_inf(V::Float64) = alpha_m(V)/ (alpha_m(V) + beta_m(V))

# SODIUM inactivation
alpha_h(V::Float64) = 0.128 * exp((17-V2(V))/18)
beta_h(V::Float64)  = 4 / (1 + exp((40-V2(V))/5))
tau_h(V::Float64) = 1/ (alpha_h(V) + beta_h(V))
h_inf(V::Float64) = alpha_h(V)/ (alpha_h(V) + beta_h(V))

# POTASSIUM
alpha_n(V::Float64) = 0.032 * (15-V2(V)) / ( exp((15-V2(V))/5) - 1)
beta_n(V::Float64)  = 0.5 * exp((10-V2(V))/40)
tau_n(V::Float64) = 1/ (alpha_n(V) + beta_n(V))
n_inf(V::Float64) = alpha_n(V)/ (alpha_n(V) + beta_n(V))

# CALCIUM activation
mCa_inf(V::Float64) = 1/(1+exp(-(V+59)/6.2))
tau_mCa(V::Float64) = 0.204 + 0.333/( exp((V+18.8)/18.2) + exp(-(V+134)/16.7) ) 

# CALCIUM inactivation
hCa_inf(V::Float64) = 1/(1+exp((V+83)/4))

function tau_hCa(V::Float64)
    if(V<-80)
        tau=0.33*exp((V+469)/66.6)
    else
        tau=9.32 + 0.33*exp(-(V+24)/10.5)
    end
    return tau
end

# derivative functions
function dV(V::Float64, m::Float64, h::Float64, n::Float64, mCa::Float64, hCa::Float64, Iapp::Float64, Istep::Float64, gCa::Float64)
    (dt)*(1/C)*(-gNa*m^3*h*(V-VNa) - gK*n^4*(V-VK) - gCa*mCa^2*hCa*(V-VCa) - gNaleak*(V-VNa) -gleak*(V-Vleak) - gKleak*(V-VK) + Iapp + Istep  )
end
#=
function dV(V::Float64, m::Float64, h::Float64, n::Float64, hCa::Float64, Iapp::Float64, Istep::Float64, gCa::Float64)
    (dt)*(1/C)*(-gNa*m^3*h*(V-VNa) - gK*n^4*(V-VK) - gCa*mCa_inf(V)^2*hCa*(V-VCa) - gNaleak*(V-VNa) -gleak*(V-Vleak) - gKleak*(V-VK) + Iapp + Istep  )
end
=#

dm(V::Float64, m::Float64)     = (dt)* ((1/tau_m(V))   *(m_inf(V) - m))
dh(V::Float64, h::Float64)     = (dt)* ((1/tau_h(V))   *(h_inf(V) - h))
dn(V::Float64, n::Float64)     = (dt)* ((1/tau_n(V))   *(n_inf(V) - n))
dmCa(V::Float64, mCa::Float64) = (dt)* ((1/tau_mCa(V)) *(mCa_inf(V) - mCa))
dhCa(V::Float64, hCa::Float64) = (dt)* ((1/tau_hCa(V)) *(hCa_inf(V) - hCa))



# simulations
function simulateTC(Iapp::Float64, Tstepinit::Int64, Tstepfinal::Int64, Istep::Float64, gCa::Float64)
# initial conditions
    V::Float64 = -74. #80
    Vprev::Float64 = -74. #80
    m::Float64 = m_inf(V)
    h::Float64 = h_inf(V)
    n::Float64 = n_inf(V)
    mCa::Float64 = mCa_inf(V)
    hCa::Float64 = hCa_inf(V)

    VV = zeros(Tdt)

    Tstart::Int64 = convert(Int64, round(Tstepinit/dt))
    Tstop::Int64 = convert(Int64, round(Tstepfinal/dt))

    for z= 1:Tdt
        if z>=Tstart && z<=Tstop
            Iappstep = Istep
        else
            Iappstep = 0.
        end

        V  +=dV(V, m, h, n, mCa, hCa, Iapp, Iappstep, gCa)
        #V  +=dV(Vprev, m, h, n, hCa, Iapp, Iappstep, gCa)
        m  +=dm(Vprev,m)
        h  +=dh(Vprev,h)
        n  +=dn(Vprev,n)
        mCa+=dmCa(Vprev,mCa)
        hCa+=dhCa(Vprev,hCa)


        Vprev=copy(V)
        VV[z]=copy(V)

    end
    return VV
end
