# Defines output directory
#saved file name
file_name= "RushCa"
coef_name = [110]
const coef_mat = [10.]
test_name = "tau"
const gamma_mat=[0.2]#[0.3 0.5]


# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include model
include("RUSHCA_tau_gamma.jl")
include("RUSHCA_PARAMS_4steps.jl")


# Simulation parameters
const T = 82000
const dt = 0.005
const Ttransient = 1001
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C = 0.1

const coef_red_h = 1.5
const coef_red_m = 1/10
const coef_red_n = 5*0.035

const VNa = 55.
const VK = -85.
const VCa = 120.
const tetas= -63
const ks= -7.8
const tetah = -72.
const kh = 1.1
const sigm = 10.3
const sign = 9.3
const teta = 1

# Model parameters (mean) - Ecells
#=
const gNa_E = 120.
const gKd_E = 10.
const gNaleak_E = 0.01429
const gKleak_E = 0.08571
const gCaT_E = 0.3

# Model parameters (mean) - Icells
const gNa_I = 120.
const gKd_I = 10.
const gNaleak_I = 0.01429
const gKleak_I = 0.08571
const gCaT_I = 0.3
=#

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells


#simulateTOY_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)
const IappE = 0.
const IstepE = 0.
const tstepEinit = 41500
const tstepEfinal = 41503
const IappI = 15.
const IstepI1 = -16.2
const IstepI2 = -16.2
const IstepI3 = -16.2
const IstepI4 = -16.2
const tstepIinit1 = 41000
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

#@time (Vnoconnect, LFPnoconnect_E, LFPnoconnect_I) = simulateTOY_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepinit,tstepfinal,IstepE,IstepI,0.,0.,0.,0.,0.,0.)
const gEEAMPA = 0.0/nEcells
#const gEIAMPA = 0.1/nEcells
#const gIEGABAA = 0.4/nIcells
#const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

const n_net = 400
for jj =1:length(coef_mat)
  coef_red = coef_mat[jj]
  coef_num = coef_name[jj]
  println("coef_red=", coef_red)

  for i=1:length(gamma_mat)
   gamma = gamma_mat[i]
   println("gamma=",gamma)

   cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Tau/%s/Results_tau/tau%d/gamma%d/",file_name,coef_num, gamma*100))
  # Functions
  function simu_networks_2cells_RUSHCA(coef_red::Float64, gamma::Float64, n_net::Int64,ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,tstepEinit::Int64,tstepEfinal::Int64,IstepE::Float64,tstepIinit1::Int64,tstepIinit2::Int64,tstepIinit3::Int64,tstepIinit4::Int64,tstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64)#,gEEAMPA::Float64,gEIAMPA::Float64,gIEGABAA::Float64,gIIGABAA::Float64,gIEGABAB::Float64,gIIGABAB::Float64)

      SPB_depol1 = zeros(ncells,n_net)
      SPB_hyperpol1 = zeros(ncells,n_net)
      PER_depol1 = zeros(ncells,n_net)
      PER_hyperpol1 = zeros(ncells,n_net)
      DC_depol1 = zeros(ncells,n_net)
      DC_hyperpol1 = zeros(ncells,n_net)
      IBF_depol1 = zeros(ncells,n_net)
      IBF_hyperpol1 = zeros(ncells,n_net)
      freq_depol_vec1 = zeros(ncells,n_net)
      freq_hyperpol_vec1 = zeros(ncells,n_net)


      gsyn_mat = readdlm(@sprintf("gsyn_mat%d.dat",100*gamma))
      gE_mat   = readdlm(@sprintf("gE_mat%d.dat",100*gamma))
      gI_mat   = readdlm(@sprintf("gI_mat%d.dat",100*gamma))

      for j=1:n_net
        println(n_net-j)
        gEIAMPA = gsyn_mat[1,j]
        gIEGABAA = gsyn_mat[2,j]
        gIEGABAB = gsyn_mat[3,j]

        C_vec = C.*ones(ncells)#(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))


        gNavec_E     = gE_mat[1,j]*ones(ncells)
        gKdvec_E     = gE_mat[2,j]*ones(ncells)
        gCaTvec_E    = gE_mat[3,j]*ones(ncells)
        gNaleakvec_E = gE_mat[4,j]*ones(ncells)
        gKleakvec_E  = gE_mat[5,j]*ones(ncells)

        gNavec_I     = gI_mat[1,j]*ones(ncells)
        gKdvec_I     = gI_mat[2,j]*ones(ncells)
        gCaTvec_I    = gI_mat[3,j]*ones(ncells)
        gNaleakvec_I = gI_mat[4,j]*ones(ncells)
        gKleakvec_I  = gI_mat[5,j]*ones(ncells)


        Vconnect_spk = simulateRUSHCA_ncells_spk(coef_red, ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB,gNavec_E, gKdvec_E, gNaleakvec_E, gKleakvec_E, gCaTvec_E, gNavec_I, gKdvec_I, gNaleakvec_I, gKleakvec_I, gCaTvec_I,C_vec)

        (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)
        SPB_depol1[:,j] = PARAMS_depol[:,1]
        SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
        PER_depol1[:,j] = PARAMS_depol[:,2]
        PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
        DC_depol1[:,j] = PARAMS_depol[:,3]
        DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
        IBF_depol1[:,j] = PARAMS_depol[:,4]
        IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
        freq_depol_vec1[:,j] = freq_depol
        freq_hyperpol_vec1[:,j] = freq_hyperpol
      end

      return (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1)
    end

    @time (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1) = simu_networks_2cells_RUSHCA(coef_red, gamma, n_net,ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4)#,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)

    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)
  end
end
