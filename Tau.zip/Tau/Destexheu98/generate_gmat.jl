# Create a matrix of random conductances
filename = "Destexheu98"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

const gamma_mat=[0.]#[0.3 0.5]

# Circuit caracteristics
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells
const n_net = 1#400

const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.2/nIcells
const gIEGABAB = 1.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# Model parameters (Ecells)
const gNa_E = 100.
const gNaleak_E = 0
const gK_E = 100.
const gKleak_E = 0
const gleak_E= 5e-2
const gCa_E=3.3

# Model parameters (Icells)
const gNa_I = 100.
const gNaleak_I = 0
const gK_I = 100.
const gKleak_I = 0
const gleak_I= 5e-2
const gCa_I=3.3


# Build matrices
const gsyn_mat = 1.0*ones(3,n_net)
const gE_mat = 1.0*ones(6,n_net)
const gI_mat = 1.0*ones(6,n_net)

for i= 1:length(gamma_mat)
    gamma=gamma_mat[i]
    cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Tau/%s/g_mat/gamma%d",filename, gamma*100))

    for j=1:n_net
        gsyn_mat[1,j] = gEIAMPA*(1-2*gamma*(rand(1)[1]-0.5))
        gsyn_mat[2,j] = gIEGABAA*(1-2*gamma*(rand(1)[1]-0.5))
        gsyn_mat[3,j] = gIEGABAB*(1-2*gamma*(rand(1)[1]-0.5))

        gE_mat[1,j] = gNa_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[2,j] = gK_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[3,j] = gCa_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[4,j] = gleak_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[5,j] = gNaleak_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[6,j] = gKleak_E*(1-2*gamma*(rand(1)[1]-0.5))

        gI_mat[1,j] = gNa_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[2,j] = gK_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[3,j] = gCa_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[4,j] = gleak_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[5,j] = gNaleak_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[6,j] = gKleak_I*(1-2*gamma*(rand(1)[1]-0.5))

    end

    writedlm(@sprintf("gsyn_mat%d.dat",gamma*100), gsyn_mat, header = false)
    writedlm(@sprintf("gE_mat%d.dat",gamma*100), gE_mat, header = false)
    writedlm(@sprintf("gI_mat%d.dat",gamma*100), gI_mat, header = false)

end
