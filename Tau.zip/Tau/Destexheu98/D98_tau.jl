# gating functions
V2(V::Float64) = V - Vtraub

# SODIUM activation
alpha_m(V::Float64) = 0.32 * (13 - V2(V)) / (exp((13-V2(V))/4) -1)
beta_m(V::Float64)  = 0.28 * (V2(V) - 40) / (exp((V2(V)-40)/5) -1)
tau_m(V::Float64) = 1 / (alpha_m(V) + beta_m(V))
m_inf(V::Float64) = alpha_m(V)/ (alpha_m(V) + beta_m(V))

# SODIUM inactivation
alpha_h(V::Float64) = 0.128 * exp((17-V2(V))/18)
beta_h(V::Float64)  = 4 / (1 + exp((40-V2(V))/5))
tau_h(V::Float64) = 1/ (alpha_h(V) + beta_h(V))
h_inf(V::Float64) = alpha_h(V)/ (alpha_h(V) + beta_h(V))

# POTASSIUM
alpha_n(V::Float64) = 0.032 * (15-V2(V)) / ( exp((15-V2(V))/5) - 1)
beta_n(V::Float64)  = 0.5 * exp((10-V2(V))/40)
tau_n(V::Float64) = 1/ (alpha_n(V) + beta_n(V))
n_inf(V::Float64) = alpha_n(V)/ (alpha_n(V) + beta_n(V))

# CALCIUM activation
mCa_inf(V::Float64) = 1/(1+exp(-(V+59)/6.2))
tau_mCa(V::Float64) = coef_red*(0.204 + 0.333/( exp((V+18.8)/18.2) + exp(-(V+134)/16.7)))

# CALCIUM inactivation
hCa_inf(V::Float64) = 1/(1+exp((V+83)/4))

function tau_hCa(V::Float64)
    if(V<-80)
        tau=0.33*exp((V+469)/66.6)
    else
        tau=9.32 + 0.33*exp(-(V+24)/10.5)
    end
    return tau
end

# derivative functions
function dV_D98(C::Float64,V::Float64, m::Float64, h::Float64, n::Float64, mCa::Float64, hCa::Float64, Iapp::Float64, Istep::Float64, gNa::Float64, gNaleak::Float64, gK::Float64, gKleak::Float64, gleak::Float64, gCa::Float64 )
    (dt)*(1/C)*(-gNa*m^3*h*(V-VNa) - gK*n^4*(V-VK) - gCa*mCa^2*hCa*(V-VCa) - gNaleak*(V-VNa) -gleak*(V-Vleak) - gKleak*(V-VK) + Iapp + Istep  )
end


dm(V::Float64, m::Float64)     = (dt)* ((1/tau_m(V))   *(m_inf(V) - m))
dh(V::Float64, h::Float64)     = (dt)* ((1/tau_h(V))  *(h_inf(V) - h))
dn(V::Float64, n::Float64)     = (dt)* ((1/tau_n(V))   *(n_inf(V) - n))
dmCa(V::Float64, mCa::Float64) = (dt)* ((1/tau_mCa(V)) *(mCa_inf(V) - mCa))
dhCa(V::Float64, hCa::Float64) = (dt)* ((1/tau_hCa(V)) *(hCa_inf(V) - hCa))

dAMPA(V::Float64,AMPA::Float64) = (dt)*(1.1*Tm(V)*(1-AMPA)-0.19*AMPA)
dGABAA(V::Float64,GABAA::Float64) = (dt)*(0.53*Tm(V)*(1-GABAA)-0.18*GABAA)
dGABAB(V::Float64,GABAB::Float64) = (dt)*(0.016*Tm(V)*(1-GABAB)-0.0047*GABAB)
Tm(V::Float64) = 1/(1+exp(-(V-2)/5))

# simulations
function simulateD98_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,TstepEinit::Int64,TstepEfinal::Int64,IstepE::Float64,TstepIinit1::Int64,TstepIinit2::Int64,TstepIinit3::Int64,TstepIinit4::Int64,TstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)

    # Synaptic Connections
  #SYN = [(gEE/4)*(rand(nEcells,nEcells)-0.5*ones(nEcells, nEcells)).+gEE (gEI/4)*(rand(nEcells,nIcells)-0.5*ones(nEcells, nIcells)).+gEI;(gIE/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE (gII/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII;(gIE2/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE2 (gII2/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII2]
  SYN = [gEE*ones(nEcells,nEcells) gEI*ones(nEcells,nIcells);gIE*ones(nIcells,nEcells) gII*ones(nIcells,nIcells);gIE2*ones(nIcells,nEcells) gII2*ones(nIcells,nIcells)]

    # initial conditions
    V = -74*ones(ncells)
    Vprev = -74*ones(ncells)
    m = m_inf(V[1])*ones(ncells)
    h = h_inf(V[1])*ones(ncells)
    n = n_inf(V[1])*ones(ncells)
    mCa = mCa_inf(V[1])*ones(ncells)
    hCa = hCa_inf(V[1])*ones(ncells)

    AMPA=zeros(ncells)
    GABAA=zeros(ncells)
    GABAB=zeros(ncells)

    VV = zeros(Tdt,ncells)
    LFP_E=zeros(Tdt)
    LFP_I=zeros(Tdt)

    # Step start and stop values
    TstartE::Int64 = convert(Int64,TstepEinit/dt)
    TstopE::Int64 = convert(Int64,TstepEfinal/dt)
    TstartI1::Int64 = convert(Int64,TstepIinit1/dt)
    TstartI2::Int64 = convert(Int64,TstepIinit2/dt)
    TstartI3::Int64 = convert(Int64,TstepIinit3/dt)
    TstartI4::Int64 = convert(Int64,TstepIinit4/dt)
    TstopI::Int64 = convert(Int64,TstepIfinal/dt)

    for z= 1:Tdt

        Isyn=zeros(ncells)


        for j = 1:ncells

            if j<=nEcells
                Iapp = IappE
                if z >= TstartE && z<= TstopE
                    Iappstep = IstepE
                else
                    Iappstep = 0.
                end

                V[j] += dV_D98(C,V[j], m[j], h[j], n[j], mCa[j], hCa[j], Iapp, Iappstep, gNavec_E[j], gNaleakvec_E[j], gKvec_E[j], gKleakvec_E[j], gleakvec_E[j], gCavec_E[j] )
            end

            if j>nEcells && j<=ncells
                Iapp = IappI
                if z >= TstartI1 && z< TstartI2
                    Iappstep = IstepI1
                elseif z >= TstartI2 && z< TstartI3
                    Iappstep = IstepI2
                elseif z >= TstartI3 && z< TstartI4
                    Iappstep = IstepI3
                elseif z >= TstartI4 && z< TstopI
                    Iappstep = IstepI4
                else
                    Iappstep = 0.
                end
                V[j] += dV_D98(C,V[j], m[j], h[j], n[j], mCa[j], hCa[j], Iapp, Iappstep, gNavec_I[j], gNaleakvec_I[j], gKvec_I[j], gKleakvec_I[j], gleakvec_I[j], gCavec_I[j] )
            end

            for k = 1:nEcells
              if k!=j
                Isyn[j] += SYN[k,j]*AMPA[k]*(Vprev[j]-0)
                V[j] += (dt)*(1/C)*(-SYN[k,j]*AMPA[k]*(Vprev[j]-0))
              end
            end
            for l = nEcells+1:ncells
              if l!=j
                Isyn[j] += SYN[l,j]*GABAA[l]*(Vprev[j]+70)+SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85)
                V[j] += (dt)*(1/C)*(-SYN[l,j]*GABAA[l]*(Vprev[j]+70))
                V[j] += (dt)*(1/C)*(-SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85))
              end
            end
            m[j]   +=dm(Vprev[j],m[j])
            h[j]   +=dh(Vprev[j],h[j])
            n[j]   +=dn(Vprev[j],n[j])
            mCa[j] +=dmCa(Vprev[j],mCa[j])
            hCa[j] +=dhCa(Vprev[j],hCa[j])

            AMPA[j] += dAMPA(Vprev[j],AMPA[j])
            GABAA[j] += dGABAA(Vprev[j],GABAA[j])
            GABAB[j] += dGABAB(Vprev[j],GABAB[j])

            Vprev = copy(V)
        end

        VV[z,:] = copy(V')
        LFP_E[z] = (1/nEcells).*sum(Isyn[1:nEcells])
        LFP_I[z] = (1/nIcells).*sum(Isyn[1+nEcells:ncells])

    end

    return VV, LFP_E, LFP_I
end
