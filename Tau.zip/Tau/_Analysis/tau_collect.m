% collect tau at V=-50 [mV]
clc
clear all
close all

%% Drion
V = -50;
TmNa_d= 1.32 - 1.26/(1+exp((V+120)/-25));
TmCa_d =21.7 - 21.3/(1+exp((V+68.1)/-20.5));
V=-70;
ThCa_d = 2*(205 - 89.8/(1+exp((V+55)/-16.9))); 

T1 = [TmNa_d, TmCa_d, ThCa_d]; 

%% Des
Vdes= -60.0000000001;
V=-60;
TmCa_des= 1 + 0.33/(exp(-(V+100)/15)+exp((V+25)/10));
V=-70;
ThCa_des = 28.3 + 0.33/( exp((V+48)/4) + exp(-(V+407)/50) );
Vtraub=-63;
alpha_m = 0.32 * (13 - (Vdes-Vtraub)) / (exp((13-(Vdes-Vtraub))/4) -1);
beta_m  = 0.28 * ((V-Vtraub) - 40)/ (exp(((V-Vtraub)-40)/5) -1);
TmNa_des= 1/ (alpha_m + beta_m);

T2 = [TmNa_des, TmCa_des, ThCa_des]; 

% %% Des98
% V=-40;
% TmCa_des2= 0.204 + 0.333/(exp(-(V+134)/16.7)+exp((V+15.8)/18.2));
% V=-60;
% ThCa_des2 =9.32 + 0.33/exp(-(V+24)/10.5);
% Vtraub=-52;
% V=-40;
% alpha_m = 0.32 * (13 - (V-Vtraub))/ (exp((13-(V-Vtraub))/4) -1);
% beta_m  = 0.28 * ((V-Vtraub) - 40)/ (exp(((V-Vtraub)-40)/5) -1);
% TmNa_des2= 1/ (alpha_m + beta_m);
% 
% T3 = [TmNa_des2, TmCa_des2, ThCa_des2]; 

%% Destexheu98
V=-40; 
TmCa_desu= 0.204 + 0.333/(exp(-(V+134)/16.7)+exp((V+18.8)/18.2));
V=-60;
ThCa_desu =9.32 + 0.33/exp(-(V+24)/10.5);
Vtraub=-52;
V=-40;
alpha_m = 0.32 * (13 - (V-Vtraub))/ (exp((13-(V-Vtraub))/4) -1);
beta_m  = 0.28 * ((V-Vtraub) - 40)/ (exp(((V-Vtraub)-40)/5) -1);
TmNa_desu= 1/ (alpha_m + beta_m);

T3u = [TmNa_desu, TmCa_desu, ThCa_desu]; 

%% HM
V=-50;
TmCa_HM = 0.612 + 1/(exp(-(V+131.6)/16.7)+exp((V+16.8)/18.2));
V=-60;
%ThCa_HM = exp((V+467)/66.6);
ThCa_HM = exp(-(V+21.88)/10.2)+28;
V=-50;
alpha_mHM = 0.091*(V+38)/(1-exp(-(V+38)/5));
beta_mHM = -0.062*(V+38)/(1-exp((V+38)/5));
mNa_inf_HM = alpha_mHM / (alpha_mHM + beta_mHM);
TmNa_HM  = 1 / (alpha_mHM + beta_mHM);

T4 = [TmNa_HM, TmCa_HM, ThCa_HM]; 

%% Wang
phi_hCa_w = 2;
V=-60; 
ThCa_w =  (1/(1+exp((V+79)/5)))*exp((V+162.3)/17.8)+20.0;
ThCa_w = ThCa_w*1/phi_hCa_w;
V=-40;
sigK=10;
alphan = -0.01*(V+45.7-sigK)/(exp(-0.1*(V+45.7-sigK))-1);
betan = 0.125*exp(-(V+55.7-sigK)/80);
mKinf_w = alphan/(alphan+betan);
TmK_WangCa = 1/(alphan+betan) *(7/200);

T5 = [TmK_WangCa/10,TmK_WangCa/10, ThCa_w];

%% WangCa
theta_red = 5;
V=-40;
TmCa_WangCa = theta_red/2*(1.7 + exp(-(V+2+28.8)/13.5))/(1+exp(-(V+63+2)/7.8));
V=-60;
ThCa_WangCa = theta_red*((1/(1+exp((V+79)/5)))*exp((V+162.3)/17.8)+20.0);
ThCa_WangCa = ThCa_WangCa*1/phi_hCa_w;


T6 = [TmCa_WangCa/100,TmCa_WangCa, ThCa_WangCa];

%% Rush
V=-50;
ThCa_r = (exp((V+150)/18)/(1.5 + sqrt(0.25 + exp((V-80)/4)))) + 30;

%% Rush
V=-50;
ThCa_rA = (exp((V+150)/18)/(1.5 + sqrt(0.25 + exp((V-80)/4)))) + 30;
%ThCa_rB = ThCa_rA /3;
V=-40;
sign=9.3;
alphan = 0.01*(V+50-sign)/(1 - exp(-0.1*(V+50-sign)));
betan = 0.125*exp(-0.0125*(V+60-sign));
TmK_r = 0.05/(alphan+betan);

T7 = [TmK_r/10, TmK_r/10, ThCa_rA]; 
%% RushCa
Vs=0;
TmCa_RushCa  = (1.7 + exp(-(V+Vs+28.8)/13.5))/(1+exp(-(V+Vs+63)/7.8));% same as Wang91 for tau_mCa with Vs=0
TmCa_RushCa10 = 1/10*TmCa_RushCa;
ThCa_RushCa  = ThCa_r*1;%*1.5; 
TmK_RushCa = TmK_r*10*0.035;%*5

%T8 = [TmK_RushCa/10, TmCa_RushCa10, ThCa_RushCa]; 
T8 = [TmCa_RushCa10/100, TmCa_RushCa10, ThCa_RushCa]; 



%%
%TmCa = [TmCa_d, TmCa_des, TmCa_des2, TmCa_HM, 0, TmCa_RushCa, 0,  TmCa_WangCa];
%ThCa = [ThCa_d, ThCa_des, ThCa_des2, ThCa_HM, ThCa_r, ThCa_RushCa, ThCa_w, ThCa_WangCa];
%TmNa = [TmNa_d, TmNa_des, TmNa_des2, TmNa_HM, 0, 0, 0, 0];

T_TOT = [T1;T2;T3u;T4;T5;T6;T7;T8];

%plot(TmCa,'o')


%%
set(groot, 'defaultAxesTickLabelInterpreter','latex'); set(groot, 'defaultLegendInterpreter','latex');
pt = 16;
ptx = 9;
pty = 9;

gamma=20;
test_name = 'TAU'; 
  
    
tau_name = [100 50 20 10 8  5    4    3  2  32    1 332 22 33 44 55 88 110 220 550 1100 ];
tau_div  = [1/100 1/50 1/20 1/10 1/8 1/5 1/4 1/3 1/2 1/1.5 1 1.5  2 3 4 5 8 10 20 50 100];
    
Prop_Drion = zeros(1, length(tau_name)); 
Prop_Des = zeros(1, length(tau_name)); 
Prop_Du98 = zeros(1,length(tau_name)); 
Prop_HM = zeros(1, length(tau_name)); 
Prop_RushCa = zeros(1, length(tau_name)); 
Prop_WangCa = zeros(1, length(tau_name)); 


%%
for i=1:1:length(tau_name)  
    [Prop_Drion(i),~] = prop_tau('Drion', tau_name(i), gamma); 
    [Prop_Des(i),~] = prop_tau('Destexhe', tau_name(i), gamma);
    [Prop_Du98(i),~] = prop_tau('Destexheu98', tau_name(i), gamma);
    [Prop_HM(i),~] = prop_tau('HM', tau_name(i), gamma);
    [Prop_RushCa(i),~] = prop_tau('RushCa', tau_name(i), gamma);
    [Prop_WangCa(i),~] = prop_tau('WangCa', tau_name(i), gamma);
    
end
%%
% figure
% bar([  100*Prop_Drion', 100*Prop_Des', 100*Prop_Du98', 100*Prop_HM',  100*Prop_WangCa', 100*Prop_RushCa' ])
% box off
% le= legend ('Drion', 'Destexhe', 'D98', 'HM', 'RushCaA','WangCa');
% set(le,'location','eastoutside','interpreter','latex','fontsize',pt);
% ylim([0 100])
% yticks([0 100])
% yticklabels({'0','100'})
% xticks(1:length(tau_name))
% xticklabels({'tau/5', 'tau/4', 'tau/3','tau/2','tau/1.5','taux1', 'taux1.5', 'taux2','taux3',  'taux4', 'taux5'})
% a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'fontsize',pt)
% xlabel('time constant of mCaT','interpreter','latex','fontsize',pt)
% ylabel('Rhythmic networks $y$ [\%]','interpreter','latex','fontsize',pt)
% title('')
% set(gcf,'PaperPositionMode','auto');
% set(gcf, 'PaperUnits', 'centimeters');
% set(gcf, 'PaperPosition', [0 0 20 10]);

%%
x_tau = [6,8,11,13,15,18,20]-2;
figure
bar([  100*Prop_Drion(x_tau)', 100*Prop_Des(x_tau)', 100*Prop_Du98(x_tau)', 100*Prop_HM(x_tau)', 100*Prop_WangCa(x_tau)' , 100*Prop_RushCa(x_tau)'])
box off
le= legend ('Drion', 'Destexhe', 'D98', 'HM', 'WCa','RCa');
set(le,'location','eastoutside','interpreter','latex','fontsize',pt);
ylim([0 100])
yticks([0 100])
yticklabels({'0','100'})
xticks(1:length(tau_name(x_tau)))
xticklabels({'tau/10', 'tau/5', 'tau/2','tau','taux2','taux5', 'taux10'})%, 'taux2','taux3',  'taux4', 'taux5'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
%xlabel('time constant of mCaT','interpreter','latex','fontsize',pt)
%ylabel('Rhythmic networks $y$ [\%]','interpreter','latex','fontsize',pt)
title('')
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 20 10]);


%% not normalised |�log

% plot_tauX(Prop_Drion, T_TOT, tau_div, 1, 1)
% plot_tauX(Prop_Des, T_TOT, tau_div,2,1)
% plot_tauX(Prop_Du98, T_TOT, tau_div,3,1)
% plot_tauX(Prop_HM, T_TOT, tau_div,4,1)
% plot_tauX(Prop_WangCa, T_TOT, tau_div,6, 1)
% plot_tauX(Prop_RushCa, T_TOT, tau_div,8, 1)
%% Normalised | non-logarithmic |�y(tau)
% plot_tauX_NORM(Prop_Drion, T_TOT, tau_div, 1)
% plot_tauX_NORM(Prop_Des, T_TOT, tau_div,2)
% plot_tauX_NORM(Prop_Du98, T_TOT, tau_div,3)
% plot_tauX_NORM(Prop_HM, T_TOT, tau_div,4)
% plot_tauX_NORM(Prop_WangCa, T_TOT, tau_div,6)
% plot_tauX_NORM(Prop_RushCa, T_TOT, tau_div,8)

%% aire en subplot log |�normalised
strname = {'Drion', 'Des', 'Des98','HM','WangCa','RushCa'};
plot_logtauX_NORM(Prop_Drion, T_TOT, tau_div,1, strname,test_name, gamma)
plot_logtauX_NORM(Prop_Des, T_TOT, tau_div,2,strname, test_name, gamma)
plot_logtauX_NORM(Prop_Du98, T_TOT, tau_div,3,strname, test_name, gamma)
plot_logtauX_NORM(Prop_HM, T_TOT, tau_div,4,strname, test_name, gamma)
plot_logtauX_NORM(Prop_WangCa, T_TOT, tau_div,6,strname, test_name, gamma)
plot_logtauX_NORM(Prop_RushCa, T_TOT, tau_div,8,strname, test_name, gamma)
% 
%% aire on top of each other |�xlogscale |�normalised
figure(1000)
plot_logtauX_normSUP(Prop_Des, T_TOT,tau_div, 2,test_name, gamma)
plot_logtauX_normSUP(Prop_Drion, T_TOT,tau_div, 1,test_name, gamma)
plot_logtauX_normSUP(Prop_Du98, T_TOT,tau_div, 3,test_name, gamma)
plot_logtauX_normSUP(Prop_HM, T_TOT,tau_div, 4,test_name, gamma)
plot_logtauX_normSUP(Prop_WangCa, T_TOT, tau_div,6,test_name, gamma)
plot_logtauX_normSUP(Prop_RushCa, T_TOT,tau_div, 8,test_name, gamma)
%
% 
% 
%% figure log norm individuelle
% 
strname = {'Drion', 'Des', 'Des98','HM','WangCa', 'RushCa'};
plot_logtauX_normIND(Prop_Drion,  T_TOT, tau_div,1, strname,test_name, gamma)
plot_logtauX_normIND(Prop_Des,T_TOT, tau_div,2,strname,test_name, gamma)
plot_logtauX_normIND(Prop_Du98,T_TOT, tau_div,3,strname,test_name, gamma)
plot_logtauX_normIND(Prop_HM, T_TOT,tau_div, 4,strname,test_name, gamma)
plot_logtauX_normIND(Prop_WangCa, T_TOT,tau_div, 6,strname,test_name, gamma)
plot_logtauX_normIND(Prop_RushCa,T_TOT, tau_div,8,strname,test_name, gamma)


%%
function plot_logtauX_NORM(Prop,T_TOT, tau_div, idx,strname, test_name, gamma)
    color_map = {[91 155 233]/255, [169 37 81]/255, [60 165 148]/255, [112 173 71]/255, [255 110 5]/255, [255 212 20]/255}; 
    
    xx = zeros(length(tau_div),1); 
    for i=1:1:length(tau_div)
        xx(i) = (log(T_TOT(idx,2)*tau_div(i))-log(T_TOT(idx,1)))/(log(T_TOT(idx,3))-log(T_TOT(idx,1)));
    end
    if(idx==6)
        idx_name=5;
    subplot(2,3,5)
    else 
        if(idx==8)
            idx_name=6;
            subplot(2,3,6)
        else
            idx_name=idx;
            subplot(2,3,idx)
        end
    end
    hold on 
    pt=11;
    ar = area(xx, 100*Prop');
    ar.LineStyle='none';
    idx_color = idx; 
    if(idx ==6)
        idx_color = 5; 
    end
    if(idx==8)
        idx_color = 6; 
    end
    ar.FaceColor = color_map{idx_color};
    ar.FaceAlpha=0.75;
    plot([norm_TAU(log(T_TOT(idx,1)), log(T_TOT),idx) norm_TAU(log(T_TOT(idx,1)), log(T_TOT),idx)], [0 100], 'k:','HandleVisibility','off')
    plot([norm_TAU(log(T_TOT(idx,3)), log(T_TOT),idx) norm_TAU(log(T_TOT(idx,3)), log(T_TOT),idx)], [0 100],'k:','HandleVisibility','off')
    %plot(xx, 100*Prop,'o','MarkerSize',2,'MarkerFaceColor',color_map{idx_color}, 'MarkerEdgeColor',color_map{idx_color},'HandleVisibility','off')
    plot(xx(find(tau_div==1)), 100*Prop(find(tau_div==1)),'o','MarkerSize',4,'MarkerFaceColor',color_map{idx_color},'MarkerEdgeColor',[0.5 0.5 0.5], 'HandleVisibility','off')


    le = legend(strname{idx_name});
    set(le,'location','northoutside', 'fontsize',pt)
    hold off
    
    
%     if(min(xx)>0)
%         minX = 0; 
%     else
%         minX = min(xx);
%     end
%     if(max(xx)>1)
%         maxX = max(xx); 
%     else
%         maxX = 1;
%     end

    %minX = norm_TAU(log(T_TOT(idx,1)), log(T_TOT),idx);%
    %maxX = norm_TAU(log(T_TOT(idx,3)), log(T_TOT),idx);%
    minX = xx(find(tau_div==1/100));
    maxX = xx(find(tau_div==100));
    xlim([minX maxX])
    
    xlim([minX maxX]) 

    ylim([0 100])
    yticks([0 100])
    yticklabels({'0','100'})

    xticks([ xx(find(tau_div==1/100))  xx(find(tau_div==1/10)) xx(find(tau_div==1/2)) xx(find(tau_div==1)) xx(find(tau_div==2))  xx(find(tau_div==10))  xx(find(tau_div==100)) ])
    %xticklabels({'1/100', '1/10','/2', '1','2', '10', '100'})
    xticklabels({'$\frac{1}{100}$', '$\frac{1}{10}$','$\frac{1}{2}$', '1','2', '10', '100'})

    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    %xlabel('time constant of mCaT','interpreter','latex','fontsize',pt)
    %ylabel('Rhythmic networks $y$ [\%]','interpreter','latex','fontsize',pt)
    title('')
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 19 12]);
    print(sprintf('Figures/TOT_%s%d_new',test_name,gamma) ,'-depsc')
    print(sprintf('Figures/TOT_%s%d_new',test_name,gamma),'-dpdf')
end

%%
function plot_logtauX_normSUP(Prop,T_TOT, tau_div, idx,test_name, gamma)
    color_map = {[91 155 233]/255, [169 37 81]/255, [60 165 148]/255, [112 173 71]/255, [255 110 5]/255, [255 212 20]/255}; 
    xx = zeros(length(tau_div),1);
    for i=1:1:length(tau_div)
        xx(i) = (log(T_TOT(idx,2)*tau_div(i))-log(T_TOT(idx,1)))/(log(T_TOT(idx,3))-log(T_TOT(idx,1)));
    end
    hold on
    pt=11; 
    ar = area(xx, 100*Prop');
    ar.FaceAlpha=0.75;   
    ar.LineStyle='none';
    idx_color = idx; 
    if(idx ==6)
        idx_color = 5; 
    end
    if(idx==8)
        idx_color = 6; 
    end
    ar.FaceColor = color_map{idx_color}; 
    
    plot(xx(find(tau_div==1)), 100*Prop(find(tau_div==1)),'o','MarkerSize', 6 ,'MarkerFaceColor',color_map{idx_color},'MarkerEdgeColor',[0.5 0.5 0.5], 'HandleVisibility','off')
    plot([0 0], [0 100], '-', 'color', [1 1 1], 'HandleVisibility','off')
    %plot([1 1], [0 100], ':', 'color', [0 32 96]/255,'HandleVisibility','off')
    
    
    xlim([0 1])
    ylim([0 100])
    yticks([0 100])
    
    yticklabels({'',''})
    xticks([0 1])
    xticklabels({'',''})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    
    b = get(gca,'YTickLabel');
    set(gca,'YTickLabel',b,'fontsize',pt)
    
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 17 5]);%13
    print(sprintf('Figures/Sup_%s%d_new',test_name,gamma) ,'-depsc')
    print(sprintf('Figures/Sup_%s%d_new',test_name,gamma),'-dpdf')
end

%%
function plot_logtauX_normIND(Prop,T_TOT, tau_div, idx,strname,test_name, gamma)

    color_map = {[91 155 233]/255, [169 37 81]/255, [60 165 148]/255, [112 173 71]/255, [255 110 5]/255, [255 212 20]/255}; 
    for i=1:1:length(tau_div)
        xx(i) = (log(T_TOT(idx,2)*tau_div(i))-log(T_TOT(idx,1)))/(log(T_TOT(idx,3))-log(T_TOT(idx,1)));
    end
    figure
    if(idx==6)
        idx_name=5;
    else 
        if(idx==8)
            idx_name=6;
        else
            idx_name=idx;
        end
    end
    hold on 
    
    ar = area(xx, 100*Prop');
    ar.LineStyle='none';
    ar.FaceColor = color_map{idx_name};
    
    
    plot([norm_TAU(log(T_TOT(idx,1)), log(T_TOT),idx) norm_TAU(log(T_TOT(idx,1)), log(T_TOT),idx)], [0 100], ':', 'color', [110 137 167]/255, 'HandleVisibility','off')
    plot([norm_TAU(log(T_TOT(idx,3)), log(T_TOT),idx) norm_TAU(log(T_TOT(idx,3)), log(T_TOT),idx)], [0 100],':', 'color', [0 32 96]/255,'HandleVisibility','off')
    plot(xx, 100*Prop,'o','MarkerSize',1.5,'MarkerFaceColor',color_map{idx_name}, 'MarkerEdgeColor',color_map{idx_name},'HandleVisibility','off')
    plot(xx(find(tau_div==1)), 100*Prop(find(tau_div==1)),'o','MarkerSize',2.5,'MarkerFaceColor',color_map{idx_name},'MarkerEdgeColor',[0.5 0.5 0.5], 'HandleVisibility','off')
    plot([xx(find(tau_div==1/10)) xx(find(tau_div==1/10))], [0 4],'k-', 'HandleVisibility','off')
    plot([xx(find(tau_div==10)) xx(find(tau_div==10))], [0 4],'k-', 'HandleVisibility','off')
    plot([xx(find(tau_div==1)) xx(find(tau_div==1))], [0 4],'k-', 'HandleVisibility','off')
    plot([xx(find(tau_div==1/100)) xx(find(tau_div==1/100))], [0 4],'k-', 'HandleVisibility','off')
    plot([xx(find(tau_div==100)) xx(find(tau_div==100))], [0 4],'k-', 'HandleVisibility','off')
    
    
    %plot([xx(find(tau_div==1)) xx(find(tau_div==1))], [0 100],'-','color', [0 0 0], 'HandleVisibility','off')
    %plot([xx(find(tau_div==1/2)) xx(find(tau_div==1/2))], [0 5],'-','color', [0.25 0.25 0.25], 'HandleVisibility','off')
    %plot([xx(find(tau_div==2)) xx(find(tau_div==2))], [0 5],'-','color', [0.25 0.25 0.25], 'HandleVisibility','off')
    
    
    hold off


    minX = xx(find(tau_div==1/100));
    maxX = xx(find(tau_div==100));
    xlim([minX maxX])
    
    pt=11;
    ylim([0 100])
    yticks([0 100])
    yticklabels({'',''})
    xticks([ xx(find(tau_div==1/100))  xx(find(tau_div==1/10)) xx(find(tau_div==1/2)) xx(find(tau_div==1)) xx(find(tau_div==2))  xx(find(tau_div==10))  xx(find(tau_div==100)) ])
    %xticklabels({'$\frac{1}{100}$', '$\frac{1}{10}$','$\frac{1}{2}$', '1','2', '10', '100'})
    xticklabels({'', '','', '','', '', ''})

    
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    b = get(gca,'YTickLabel');
    set(gca,'YTickLabel',b,'fontsize',pt)
    %xlabel('time constant of mCaT','interpreter','latex','fontsize',pt)
    %ylabel('Rhythmic networks $y$ [\%]','interpreter','latex','fontsize',pt)
    title('')
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 4 2.8]);
    print(sprintf('Figures/%s%s%d_new', strname{idx_name}, test_name, gamma),'-depsc')
    print(sprintf('Figures/%s%s%d_new',strname{idx_name},  test_name, gamma),'-dpdf')
end

%% 

function res = norm_TAU(var1, T_TOT,idx)
    res = (var1-T_TOT(idx,1))/(T_TOT(idx,3)-T_TOT(idx,1)); 
end


%%

% function plot_tauX(Prop, T_TOT,tau_div,idx, bool_log)
%     xx = zeros(length(tau_div),1); 
%     for i=1:1:length(tau_div)
%         xx(i) = T_TOT(idx,2)*tau_div(i); 
%     end
%     if(bool_log==1)    
%         xx = log(xx);
%     end
%     
%     figure
%     hold on 
%     if(bool_log==1)
%         plot([log(T_TOT(idx,1)) log(T_TOT(idx,1))], [0 100], 'k:') % mNA
%         plot([log(T_TOT(idx,3)) log(T_TOT(idx,3))], [0 100],'k:')  %hCa
%     else
%         plot([T_TOT(idx,1) T_TOT(idx,1)], [0 100], 'k:') % mNA
%         plot([T_TOT(idx,3) T_TOT(idx,3)], [0 100],'k:')  %hCa
%     end
%     plot(xx, 100*Prop,'bo') 
%     plot(xx(find(tau_div==1)), 100*Prop(find(tau_div==1)),'kx') % nominal value
%     ar = area(xx, 100*Prop');
%     ar.FaceAlpha=0.3;
%     ar.LineStyle='none';
%     
% end


%% "NORMALISED GRAPH"
% 
% function plot_tauX_NORM(Prop,T_TOT, tau_div, idx)
%     %taumCa_temp = (T_TOT(idx,2)-T_TOT(idx,1))/(T_TOT(idx,3)-T_TOT(idx,1));
%     xx =zeros(length(tau_div),1); 
%     for i=1:1:length(tau_div)
%         xx(i) = ((T_TOT(idx,2)*tau_div(i))-T_TOT(idx,1))/(T_TOT(idx,3)-T_TOT(idx,1));
%     end
%      figure
%     hold on 
%     plot([norm_TAU(T_TOT(idx,1), T_TOT,idx) norm_TAU(T_TOT(idx,1), T_TOT,idx)], [0 100], 'k:')
%     plot([norm_TAU(T_TOT(idx,3), T_TOT,idx) norm_TAU(T_TOT(idx,3), T_TOT,idx)], [0 100],'k:')
%     plot(xx, 100*Prop,'bo')
%     plot(xx(find(tau_div==1)), 100*Prop(find(tau_div==1)),'kx')
%     ar = area(xx, 100*Prop');
%     ar.FaceAlpha=0.3;
%     ar.LineStyle='none';
%     ar.FaceColor='blue';
% 
% 
% end

