function [y, good_index] = prop_tau(Name, tau, manip)

    
    num_sim=1; % only take into account the first step current
    
    
    %for i = 1:1:length(center)
        %index = center(i); % remplir chaque ligne de la matrice en fonction du center choisi
        for j=1:1:length(manip)
            gamma = manip(j);
            SPB_depol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/SPB_depol%d.dat',Name,tau,gamma,num_sim));
            SPB_hyperpol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/SPB_hyperpol%d.dat',Name,tau,gamma,num_sim));
            PER_depol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/PER_depol%d.dat',Name,tau,gamma,num_sim));
            PER_hyperpol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/PER_hyperpol%d.dat',Name,tau,gamma,num_sim));
            DC_depol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/DC_depol%d.dat',Name,tau,gamma,num_sim));
            DC_hyperpol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/DC_hyperpol%d.dat',Name,tau,gamma,num_sim));
            IBF_depol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/IBF_depol%d.dat',Name,tau,gamma,num_sim));
            IBF_hyperpol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/IBF_hyperpol%d.dat',Name,tau,gamma,num_sim));
            freq_depol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/freq_depol%d.dat',Name,tau,gamma,num_sim));
            freq_hyperpol = load(sprintf('../%s/Results_tau/tau%d/gamma%d/freq_hyperpol%d.dat',Name,tau,gamma,num_sim));
    
            [synburst,synburst2] = determ_synburst(SPB_depol, SPB_hyperpol, PER_depol, PER_hyperpol, DC_depol,DC_hyperpol,IBF_depol,IBF_hyperpol,freq_depol,freq_hyperpol);

            synburst2;
            if(isempty(synburst2))
                for l=1:1:length(freq_hyperpol(2,:))
                    good_index(j,l)= 0;
                end
                
            else
                index=1;
                for l=1:1:length(freq_hyperpol(2,:))
                    if(index <=length(synburst2))
                        if(synburst2(index)==l)
                            good_index(j,l)=l;
                            index=index+1;
                        else
                            good_index(j,l)=0;
                        end
                    end
                end
            end
            
            
            
            y(j) = length(synburst2)/length(freq_hyperpol(2,:));

        end
    %end


end