function [synburst, synburst2] = determ_synburst(SPB_depol, SPB_hyperpol, PER_depol, PER_hyperpol, DC_depol,DC_hyperpol,IBF_depol,IBF_hyperpol,freq_depol,freq_hyperpol)


%% Detect firing pattern
%Norm = 100/length(freq_depol(1,:));
Norm=length(freq_depol(1,:))/100;
% E cells
FP_Ecells_depol = zeros(length(freq_depol(1,:)),4); %Silent slow_spiking Asynch_bursting Synchbursting
FP_Icells_depol = zeros(length(freq_depol(1,:)),4); %Silent slow_spiking Asynch_bursting Synchbursting
FP_Ecells_hyperpol = zeros(length(freq_depol(1,:)),4); %Silent slow_spiking Asynch_bursting Synchbursting
FP_Icells_hyperpol = zeros(length(freq_depol(1,:)),4); %Silent slow_spiking Asynch_bursting Synchbursting
for i = 1:length(freq_depol(1,:))
    if freq_depol(1,i) == Inf
        FP_Ecells_depol(i,:) = [0 0 0 1]; %silent
    elseif freq_depol(1,i) > 0
        FP_Ecells_depol(i,:) = [1 0 0 0];%tonic
    elseif PER_depol(1,i) > 0.95*PER_depol(2,i) && PER_depol(1,i) < 1.05*PER_depol(2,i)
        FP_Ecells_depol(i,:) = [0 0 1 0];
    elseif 2*PER_depol(1,i) > 0.95*PER_depol(2,i) && 2*PER_depol(1,i) < 1.05*PER_depol(2,i)
        FP_Ecells_depol(i,:) = [0 0 1 0];
    elseif 0.5*PER_depol(1,i) > 0.95*PER_depol(2,i) && 0.5*PER_depol(1,i) < 1.05*PER_depol(2,i)
        FP_Ecells_depol(i,:) = [0 0 1 0];
    else 
        FP_Ecells_depol(i,:) = [0 1 0 0];
    end
end

for i = 1:length(freq_hyperpol(1,:))
    if freq_hyperpol(1,i) == Inf
        FP_Ecells_hyperpol(i,:) = [0 0 0 1];
    elseif freq_hyperpol(1,i) > 0
        FP_Ecells_hyperpol(i,:) = [1 0 0 0];
    elseif PER_hyperpol(1,i) > 0.95*PER_hyperpol(2,i) && PER_hyperpol(1,i) < 1.05*PER_hyperpol(2,i)
        FP_Ecells_hyperpol(i,:) = [0 0 1 0];
    elseif 2*PER_hyperpol(1,i) > 0.95*PER_hyperpol(2,i) && 2*PER_hyperpol(1,i) < 1.05*PER_hyperpol(2,i)
        FP_Ecells_hyperpol(i,:) = [0 0 1 0];
    elseif 0.5*PER_hyperpol(1,i) > 0.95*PER_hyperpol(2,i) && 0.5*PER_hyperpol(1,i) < 1.05*PER_hyperpol(2,i)
        FP_Ecells_hyperpol(i,:) = [0 0 1 0];
    else 
        FP_Ecells_hyperpol(i,:) = [0 1 0 0];
    end
end

for i = 1:length(freq_depol(2,:))
    if freq_depol(2,i) == Inf
        FP_Icells_depol(i,:) = [0 0 0 1];
    elseif freq_depol(2,i) > 0
        FP_Icells_depol(i,:) = [1 0 0 0];
    elseif PER_depol(2,i) > 0.95*PER_depol(1,i) && PER_depol(2,i) < 1.05*PER_depol(1,i)
        FP_Icells_depol(i,:) = [0 0 1 0];
    elseif 2*PER_depol(2,i) > 0.95*PER_depol(1,i) && 2*PER_depol(2,i) < 1.05*PER_depol(1,i)
        FP_Icells_depol(i,:) = [0 0 1 0];
    elseif 0.5*PER_depol(2,i) > 0.95*PER_depol(1,i) && 0.5*PER_depol(2,i) < 1.05*PER_depol(1,i)
        FP_Icells_depol(i,:) = [0 0 1 0];
    else 
        FP_Icells_depol(i,:) = [0 1 0 0];
    end
end

for i = 1:length(freq_hyperpol(2,:))
    if freq_hyperpol(2,i) == Inf
        FP_Icells_hyperpol(i,:) = [0 0 0 1];
    elseif freq_hyperpol(2,i) > 0
        FP_Icells_hyperpol(i,:) = [1 0 0 0];
    elseif PER_hyperpol(2,i) > 0.95*PER_hyperpol(1,i) && PER_hyperpol(2,i) < 1.05*PER_hyperpol(1,i)
        FP_Icells_hyperpol(i,:) = [0 0 1 0];
    elseif 2*PER_hyperpol(2,i) > 0.95*PER_hyperpol(1,i) && 2*PER_hyperpol(2,i) < 1.05*PER_hyperpol(1,i)
        FP_Icells_hyperpol(i,:) = [0 0 1 0];
    elseif 0.5*PER_hyperpol(2,i) > 0.95*PER_hyperpol(1,i) && 0.5*PER_hyperpol(2,i) < 1.05*PER_hyperpol(1,i)
        FP_Icells_hyperpol(i,:) = [0 0 1 0];
    else 
        FP_Icells_hyperpol(i,:) = [0 1 0 0];
    end
end


synburst = find(FP_Icells_hyperpol(:,3) == 1);
%synburst2 = find(FP_Icells_depol(:,1) == 1 & FP_Ecells_hyperpol(:,3) == 1);
synburst2 = find(FP_Icells_depol(:,1) == 1 & FP_Ecells_hyperpol(:,3) == 1 & FP_Icells_hyperpol(:,3) == 1 & FP_Ecells_depol(:,4) == 1);
% Icells depol > tonic & Ecells hyperpol > syn.burst & Icells hyperpol > syn. burst & Ecells depol > silent

end

