clc
clear all
close 

V = -80:0.01:60; 

%% Drion
TmNa_d= 1.32 - 1.26./(1.+exp((V+120)/-25));
ThNa_d = (0.67./(1+exp((V+62.9)/-10))).*(1.5+1./(1+exp(V+34.9)/3.6));
TmCa_d =21.7 - 21.3./(1.+exp((V+68.1)/-20.5));
ThCa_d = 2*(205 - 89.8./(1+exp((V+55)/-16.9))); 
TmK_d = 7.2 - 6.4./(1+exp((V+28.3)/-19.2));

T1 = [TmNa_d; ThNa_d; TmK_d; TmCa_d; ThCa_d]; 


%% Destexhe
TmCa_des= 1 + 0.33./(exp(-(V+100)/15)+exp((V+25)/10));
ThCa_des = 28.3 + 0.33./( exp((V+48)/4) + exp(-(V+407)/50) );

Vtraub=-63;
alpha_m = 0.32 .* (13 - (V-Vtraub)) ./ (exp((13-(V-Vtraub))/4) -1);
beta_m  = 0.28 .* ((V-Vtraub) - 40)./ (exp(((V-Vtraub)-40)/5) -1);
TmNa_des= 1./ (alpha_m + beta_m);

alpha_h = 0.128 .* exp((17-(V-Vtraub))/18);
beta_h  = 4 ./ (1 + exp((40-(V-Vtraub))/5));
ThNa_des = 1./ (alpha_h + beta_h);

alpha_n = 0.032 .* (15-(V-Vtraub)) / ( exp((15-(V-Vtraub))/5) - 1);
beta_n  = 0.5 * exp((10-(V-Vtraub))/40);
TmK_des = 1./ (alpha_n + beta_n);


T2 = [TmNa_des; ThNa_des; TmK_des; TmCa_des; ThCa_des]; 
%% Des98

% TmCa_des2= 0.204 + 0.333/(exp(-(V+134)/16.7)+exp((V+15.8)/18.2));
% ThCa_des2 =9.32 + 0.33/exp(-(V+24)/10.5);
% Vtraub=-52;
% alpha_m = 0.32 * (13 - (V-Vtraub))/ (exp((13-(V-Vtraub))/4) -1);
% beta_m  = 0.28 * ((V-Vtraub) - 40)/ (exp(((V-Vtraub)-40)/5) -1);
% TmNa_des2= 1/ (alpha_m + beta_m);


%% Destexheu98

TmCa_desu= 0.204 + 0.333./(exp(-(V+134)/16.7)+exp((V+18.8)/18.2));
ThCa_desu =9.32 + 0.33./exp(-(V+24)/10.5);
Vtraub=-52;
alpha_m = 0.32 .* (13 - (V-Vtraub))./ (exp((13-(V-Vtraub))/4) -1);
beta_m  = 0.28 .* ((V-Vtraub) - 40)./ (exp(((V-Vtraub)-40)/5) -1);
TmNa_desu= 1./ (alpha_m + beta_m);

alpha_h = 0.128 .* exp((17-(V-Vtraub))/18);
beta_h  = 4 ./ (1 + exp((40-(V-Vtraub))/5));
ThNa_desu = 1./ (alpha_h + beta_h);

alpha_n = 0.032 .* (15-(V-Vtraub)) / ( exp((15-(V-Vtraub))/5) - 1);
beta_n  = 0.5 * exp((10-(V-Vtraub))/40);
TmK_desu = 1./ (alpha_n + beta_n);


T3 = [TmNa_desu; ThNa_desu; TmK_desu; TmCa_desu; ThCa_desu]; 
%% HM

TmCa_HM = 0.612 + 1./(exp(-(V+131.6)/16.7)+exp((V+16.8)/18.2));

%ThCa_HM = exp((V+467)/66.6);
ThCa_HM = exp(-(V+21.88)/10.2)+28;
alpha_mHM = 0.091*(V+38)./(1-exp(-(V+38)/5));
beta_mHM = -0.062*(V+38)./(1-exp((V+38)/5));
TmNa_HM  = 1 ./ (alpha_mHM + beta_mHM);

alpha_hHM = 0.016.*exp((-55-V)/15);
beta_hHM = 2.07./(exp((17-V)/21)+1);
ThNa_HM = 1 ./ (alpha_hHM + beta_hHM);

T4 = [TmNa_HM; ThNa_HM; zeros(1, length(V)); TmCa_HM; ThCa_HM]; 

%% Rush
ThCa_r = (exp((V+150)/18)./(1.5 + sqrt(0.25 + exp((V-80)/4)))) + 30;
sign=9.3;
alphan = 0.01*(V+50-sign)./(1 - exp(-0.1*(V+50-sign)));
betan = 0.125.*exp(-0.0125*(V+60-sign));
TmK_r = 0.05./(alphan+betan);


T6 = [zeros(1, length(V)); TmK_r; TmK_r; zeros(1, length(V)); ThCa_r]; 

%% RushCa
Vs=0;
TmCa_RushCa  = (1.7 + exp(-(V+Vs+28.8)/13.5))./(1+exp(-(V+Vs+63)/7.8));% same as Wang91 for tau_mCa with Vs=0
TmCa_RushCa = 1/10.*TmCa_RushCa;
ThCa_RushCa  = ThCa_r.*1.5; 
TmK_RushCa = TmK_r.*5*0.035;

T6b = [zeros(1, length(V)); TmK_r; TmK_RushCa; TmCa_RushCa; ThCa_RushCa]; 


%% Wang
phi_hCa_w = 2;
ThCa_Wang =  (1./(1+exp((V+79)/5))).*exp((V+162.3)/17.8)+20.0;
ThCa_Wang = ThCa_Wang.*1/phi_hCa_w;
sigK=10;
alphan = -0.01.*(V+45.7-sigK)./(exp(-0.1*(V+45.7-sigK))-1);
betan = 0.125.*exp(-(V+55.7-sigK)/80);
TmK_Wang = 1./(alphan+betan) .*(7/200);


T5 = [zeros(1, length(V)); TmK_Wang; TmK_Wang; zeros(1, length(V)); ThCa_Wang]; 

%% WangCa
theta_red = 5;
TmK_WangCa = TmK_Wang;
TmCa_WangCa = theta_red/2.*(1.7 + exp(-(V+2+28.8)/13.5))./(1+exp(-(V+63+2)/7.8));
ThCa_WangCa = theta_red.*((1./(1+exp((V+79)/5))).*exp((V+162.3)/17.8)+20.0);
ThCa_WangCa = ThCa_WangCa.*1/phi_hCa_w;

T5b = [zeros(1, length(V)); TmK_WangCa; TmK_WangCa; TmCa_WangCa; ThCa_WangCa]; 


%%
plot_T(V, T1, 'Drion')
plot_T(V, T2, 'Des')
plot_T(V, T3, 'Du98')
plot_T(V, T4, 'HM')
plot_T(V, T5, 'Wang')
plot_T(V, T5b, 'WangCa')
plot_T(V, T6, 'Rush')
plot_T(V, T6b, 'RushCa')

%%
function plot_T(V, T, Name)
    pt=11; 
    figure
    hold on
    plot(V,T(1,:), 'b')
    %plot(V,T(2,:), 'b--')
    %plot(V,T(3,:), 'g')
    plot(V,T(4,:), 'r')
    plot(V,T(5,:), 'r--')
    plot([-50 -50], [1e-2 1e4], 'k:','HandleVisibility','off')
    hold off
    set(gca, 'YScale', 'log')
    ylim([1e-2 1e4])
    xlim([-80 60])
    if(strcmp(Name, 'Drion'))
        %le= legend ( '$\tau_{m,Ca}$', '$\tau_{h,Ca}$', '$\tau_{m,K}$', '$\tau_{m,Ca}$', '$\tau_{h,Ca}$');
        le= legend ( '$\tau_{m,Ca}$', '$\tau_{m,Ca}$', '$\tau_{h,Ca}$');
        set(le,'location','northeast','interpreter','latex','fontsize',pt);
    end
    title('')
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 8 5]);
    print(sprintf('V/Tau_%s', Name),'-depsc')
    print(sprintf('V/Tau_%s', Name),'-dpdf')

end

