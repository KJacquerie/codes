# Define output directory

#saved file name
file_name= "HM"
coef_name = [200 150 100 50 20 10 8 5 4 3 2 32 1 332 22 33 44 55 88 110 220 550 1100]#[10 8 5 4 3 2 32 1 332 22 33 44 55 88 110]#[10 8 5 4 3 2 32 1 332 22 33 44 55 88 110]
const coef_mat = [1/200 1/150 1/100 1/50 1/20 1/10 1/8 1/5 1/4 1/3 1/2 1/1.5 1. 1.5 2. 3. 4. 5. 8. 10. 20 50 100]#[1/10 1/8 1/5 1/4 1/3 1/2 1/1.5 1. 1.5 2. 3. 4. 5. 8. 10.]#[ 1/10 1/8 1/5 1/4 1/3 1/2 1/1.5 1. 1.5 2. 3. 4. 5. 8. 10. ]
test_name = "tau"
const gamma_mat=[0.2]#[0.3 0.5]


# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include model
include("HM_tau_gamma.jl")
include("HM_PARAMS_4steps.jl")

# Simulation parameters
const T = 82000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const Ttransient = 1001
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C= 0.29 #nF

const VNa = 45
const VCa = 120
const VK = -105

# Model parameters - Ecells
#=
const gNa_E = 12.
const gNap_E = 7.e-3
const gNaleak_E = 2.65e-3
const gA_E = 20.e-3
const gA2_E = 15.e-3
const gKleak_E = 7.e-3
const gK2a_E = 38.e-3
const gK2b_E = 26.e-3
const gc_E = 1.
const gL_E = 0.8
const gT_E= 1.

# Model parameters - Icells
const gNa_I = 12.
const gNap_I = 7.e-3
const gNaleak_I = 2.65e-3
const gA_I = 20.e-3
const gA2_I = 15.e-3
const gKleak_I = 7.e-3
const gK2a_I = 38.e-3
const gK2b_I = 26.e-3
const gc_I = 1.
const gL_I = 0.8
const gT_I= 1.
=#

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells


# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 41500
const tstepEfinal = 41503
const IappI = 1.
const IstepI1 = -1.
const IstepI2 = -1.
const IstepI3 = -1.
const IstepI4 = -1.
const tstepIinit1 = 41000
const tstepIinit2 = copy(T)
const tstepIinit3 =  copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

#Synaptic connexion
const gEEAMPA = 0.0/nEcells
#const gEIAMPA = 0.01/nEcells
#const gIEGABAA = 0.04/nIcells
#const gIEGABAB = .01/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

const n_net = 400

for jj =1:length(coef_mat)
  coef_red = coef_mat[jj]
  coef_num = coef_name[jj]
  println("coef_red=", coef_red)

  for i=1:length(gamma_mat)
   gamma = gamma_mat[i]
   println("gamma=",gamma)

   cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Tau/%s/Results_tau/tau%d/gamma%d/",file_name,coef_num, gamma*100))

    # Functions
    function simu_networks_2cells_HM(coef_red::Float64, gamma::Float64, n_net::Int64,ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,tstepEinit::Int64,tstepEfinal::Int64,IstepE::Float64,tstepIinit1::Int64,tstepIinit2::Int64,tstepIinit3::Int64,tstepIinit4::Int64,tstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64)#,gEEAMPA::Float64,gEIAMPA::Float64,gIEGABAA::Float64,gIIGABAA::Float64,gIEGABAB::Float64,gIIGABAB::Float64)
        SPB_depol1 = zeros(ncells,n_net)
        SPB_hyperpol1 = zeros(ncells,n_net)
        PER_depol1 = zeros(ncells,n_net)
        PER_hyperpol1 = zeros(ncells,n_net)
        DC_depol1 = zeros(ncells,n_net)
        DC_hyperpol1 = zeros(ncells,n_net)
        IBF_depol1 = zeros(ncells,n_net)
        IBF_hyperpol1 = zeros(ncells,n_net)
        freq_depol_vec1 = zeros(ncells,n_net)
        freq_hyperpol_vec1 = zeros(ncells,n_net)

        gsyn_mat = readdlm(@sprintf("gsyn_mat%d.dat",100*gamma))
        gE_mat   = readdlm(@sprintf("gE_mat%d.dat",100*gamma))
        gI_mat   = readdlm(@sprintf("gI_mat%d.dat",100*gamma))


        for j=1:n_net
          println(n_net-j)

          gEIAMPA = gsyn_mat[1,j]
          gIEGABAA = gsyn_mat[2,j]
          gIEGABAB = gsyn_mat[3,j]

          C_vec = C.*ones(ncells)

          gNavec_E    = gE_mat[1,j]*ones(ncells)
          gAvec_E     = gE_mat[2,j]*ones(ncells)
          gTvec_E     = gE_mat[3,j]*ones(ncells)
          gA2vec_E    = gE_mat[4,j]*ones(ncells)
          gK2avec_E   = gE_mat[5,j]*ones(ncells)
          gK2bvec_E   = gE_mat[6,j]*ones(ncells)
          gNapvec_E   = gE_mat[7,j]*ones(ncells)
          gcvec_E     = gE_mat[8,j]*ones(ncells)
          gLvec_E     = gE_mat[9,j]*ones(ncells)
          gNaleakvec_E = gE_mat[10,j]*ones(ncells)
          gKleakvec_E = gE_mat[11,j]*ones(ncells)



          gNavec_I    = gI_mat[1,j]*ones(ncells)
          gAvec_I     = gI_mat[2,j]*ones(ncells)
          gTvec_I     = gI_mat[3,j]*ones(ncells)
          gA2vec_I    = gI_mat[4,j]*ones(ncells)
          gK2avec_I   = gI_mat[5,j]*ones(ncells)
          gK2bvec_I   = gI_mat[6,j]*ones(ncells)
          gNapvec_I   = gI_mat[7,j]*ones(ncells)
          gcvec_I     = gI_mat[8,j]*ones(ncells)
          gLvec_I      = gI_mat[9,j]*ones(ncells)
          gNaleakvec_I = gE_mat[10,j]*ones(ncells)
          gKleakvec_I = gI_mat[11,j]*ones(ncells)

          Vconnect_spk = simulateHM_ncells_spk(coef_red, ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB,gNavec_E, gNapvec_E, gK2avec_E, gK2bvec_E, gcvec_E, gTvec_E, gLvec_E, gAvec_E, gA2vec_E, gNaleakvec_E, gKleakvec_E, gNavec_I, gNapvec_I, gK2avec_I, gK2bvec_I, gcvec_I, gTvec_I, gLvec_I, gAvec_I, gA2vec_I, gNaleakvec_I, gKleakvec_I, C_vec)
          (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)
          SPB_depol1[:,j] = PARAMS_depol[:,1]
          SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
          PER_depol1[:,j] = PARAMS_depol[:,2]
          PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
          DC_depol1[:,j] = PARAMS_depol[:,3]
          DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
          IBF_depol1[:,j] = PARAMS_depol[:,4]
          IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
          freq_depol_vec1[:,j] = freq_depol
          freq_hyperpol_vec1[:,j] = freq_hyperpol

        end
        return (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1)

    end

    @time (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1) = simu_networks_2cells_HM(coef_red, gamma, n_net,ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4)#,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)



    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)
  end
end
