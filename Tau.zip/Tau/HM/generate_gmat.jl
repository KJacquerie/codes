# Create a matrix of random conductances
filename = "HM"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

const gamma_mat=[0.]#[0.3 0.5]

# Circuit caracteristics
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells
const n_net = 1

const gEEAMPA  = 0.0/nEcells
const gEIAMPA  = 0.01/nEcells
const gIEGABAA = 0.04/nIcells
const gIEGABAB = 0.01/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# Model parameters - Ecells
const gNa_E = 12.
const gNap_E = 7.e-3
const gNaleak_E = 2.65e-3
const gA_E = 20.e-3
const gA2_E = 15.e-3
const gKleak_E = 7.e-3
const gK2a_E = 38.e-3
const gK2b_E = 26.e-3
const gc_E = 1.
const gL_E = 0.8
const gT_E= 1.

# Model parameters - Icells
const gNa_I = 12.
const gNap_I = 7.e-3
const gNaleak_I = 2.65e-3
const gA_I = 20.e-3
const gA2_I = 15.e-3
const gKleak_I = 7.e-3
const gK2a_I = 38.e-3
const gK2b_I = 26.e-3
const gc_I = 1.
const gL_I = 0.8
const gT_I= 1.

# Build matrices
const gsyn_mat = 1.0*ones(3,n_net)
const gE_mat = 1.0*ones(11,n_net)
const gI_mat = 1.0*ones(11,n_net)

for i= 1:length(gamma_mat)
    gamma=gamma_mat[i]
    cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Tau/%s/g_mat/gamma%d",filename, gamma*100))

    for j=1:n_net
        gsyn_mat[1,j] = gEIAMPA*(1-2*gamma*(rand(1)[1]-0.5))
        gsyn_mat[2,j] = gIEGABAA*(1-2*gamma*(rand(1)[1]-0.5))
        gsyn_mat[3,j] = gIEGABAB*(1-2*gamma*(rand(1)[1]-0.5))

        gE_mat[1,j]  = gNa_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[2,j]  = gA_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[3,j]  = gT_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[4,j]  = gA2_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[5,j]  = gK2a_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[6,j]  = gK2b_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[7,j]  = gNap_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[8,j]  = gc_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[9,j]  = gL_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[10,j] = gNaleak_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[11,j] = gKleak_E*(1-2*gamma*(rand(1)[1]-0.5))

        gI_mat[1,j]  = gNa_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[2,j]  = gA_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[3,j]  = gT_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[4,j]  = gA2_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[5,j]  = gK2a_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[6,j]  = gK2b_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[7,j]  = gNap_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[8,j]  = gc_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[9,j]  = gL_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[10,j] = gNaleak_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[11,j] = gKleak_I*(1-2*gamma*(rand(1)[1]-0.5))

    end

    writedlm(@sprintf("gsyn_mat%d.dat",gamma*100), gsyn_mat, header = false)
    writedlm(@sprintf("gE_mat%d.dat",gamma*100), gE_mat, header = false)
    writedlm(@sprintf("gI_mat%d.dat",gamma*100), gI_mat, header = false)

end
