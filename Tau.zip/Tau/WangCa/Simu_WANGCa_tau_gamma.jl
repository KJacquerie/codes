# Defines output directory
#saved file name
file_name= "WangCa"
coef_name = [500 200]#[200 150 100 50 20 220 550 1100]#[10 8 5 4 3 2 32 1 332 22 33 44 55 88 110]#[10 8 5 4 3 2 32 1 332 22 33 44 55 88 110]
const coef_mat = [1/500 1/200]#[1/200 1/150 1/100 1/50 1/20 20 50 100]#[1/10 1/8 1/5 1/4 1/3 1/2 1/1.5 1. 1.5 2. 3. 4. 5. 8. 10.]#[ 1/10 1/8 1/5 1/4 1/3 1/2 1/1.5 1. 1.5 2. 3. 4. 5. 8. 10. ]
test_name = "tau"
const gamma_mat=[0.2]#[0.3 0.5]


# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include model
include("WangCa_tau_gamma.jl")
include("WANGCa_PARAMS_4steps.jl")


# Simulation parameters
const T = 82000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Ttransient = 1001
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const theta_red = 5.

const VCa = 120.
const VH = -40.
const VK = -80.
const VNa = 55.
const Vl = -70.
const sigK = 10.
const sigNa = 6.
const sigNaP = -5.
const thetah = -79.
const kh = 5.

const C = 1.

# Model parameters (mean) - Ecells
#=
const gCaT_E = 1.
const gH_E = 0.04
const gKd_E = 30.
const gNa_E = 42.
const gNaP_E = 9.
const gl_E = 0.12

# Model parameters (mean) - Icells
const gCaT_I = 1.
const gH_I = 0.04
const gKd_I = 30.
const gNa_I = 42.
const gNaP_I = 9.
const gl_I = 0.12
=#

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 60500
const tstepEfinal = 60503
const IappI = 3.
const IstepI1 = -4.3
const IstepI2 = -4.3
const IstepI3 = -4.3
const IstepI4 = -4.3
const tstepIinit1 = 41000
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

# Synaptic connections
const gEEAMPA = 0.0/nEcells
#const gEIAMPA = 0.1/nEcells
#const gIEGABAA = 0.4/nIcells
#const gIEGABAB = 4.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

const n_net = 400

for jj =1:length(coef_mat)
  coef_red = coef_mat[jj]
  coef_num = coef_name[jj]
  println("coef_red=", coef_red)

  for i=1:length(gamma_mat)
   gamma = gamma_mat[i]
   println("gamma=",gamma)

   cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Tau/%s/Results_tau/tau%d/gamma%d/",file_name,coef_num, gamma*100))

   # Functions
   function simu_networks_2cells_WANG(coef_red::Float64, gamma::Float64, n_net::Int64,ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,tstepEinit::Int64,tstepEfinal::Int64,IstepE::Float64,tstepIinit1::Int64,tstepIinit2::Int64,tstepIinit3::Int64,tstepIinit4::Int64,tstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64)#,gEEAMPA::Float64,gEIAMPA::Float64,gIEGABAA::Float64,gIIGABAA::Float64,gIEGABAB::Float64,gIIGABAB::Float64)

     SPB_depol1 = zeros(ncells,n_net)
     SPB_hyperpol1 = zeros(ncells,n_net)
     PER_depol1 = zeros(ncells,n_net)
     PER_hyperpol1 = zeros(ncells,n_net)
     DC_depol1 = zeros(ncells,n_net)
     DC_hyperpol1 = zeros(ncells,n_net)
     IBF_depol1 = zeros(ncells,n_net)
     IBF_hyperpol1 = zeros(ncells,n_net)
     freq_depol_vec1 = zeros(ncells,n_net)
     freq_hyperpol_vec1 = zeros(ncells,n_net)

     gsyn_mat = readdlm(@sprintf("gsyn_mat%d.dat",100*gamma))
     gE_mat   = readdlm(@sprintf("gE_mat%d.dat",100*gamma))
     gI_mat   = readdlm(@sprintf("gI_mat%d.dat",100*gamma))

      for j=1:n_net
        println(n_net-j)

        gEIAMPA = gsyn_mat[1,j]
        gIEGABAA = gsyn_mat[2,j]
        gIEGABAB = gsyn_mat[3,j]

        C_vec = C.*ones(ncells)

        gNavec_E  = gE_mat[1,j]*ones(ncells)
        gKdvec_E  = gE_mat[2,j]*ones(ncells)
        gCaTvec_E = gE_mat[3,j]*ones(ncells)
        gHvec_E   = gE_mat[4,j]*ones(ncells)
        gNaPvec_E = gE_mat[5,j]*ones(ncells)
        glvec_E   = gE_mat[6,j]*ones(ncells)

        gNavec_I  = gI_mat[1,j]*ones(ncells)
        gKdvec_I  = gI_mat[2,j]*ones(ncells)
        gCaTvec_I = gI_mat[3,j]*ones(ncells)
        gHvec_I   = gI_mat[4,j]*ones(ncells)
        gNaPvec_I = gI_mat[5,j]*ones(ncells)
        glvec_I   = gI_mat[6,j]*ones(ncells)


        Vconnect_spk = simulateWANG_ncells_spk(coef_red, ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB,gCaTvec_E, gHvec_E, gKdvec_E, gNavec_E, gNaPvec_E, glvec_E, gCaTvec_I, gHvec_I, gKdvec_I, gNavec_I, gNaPvec_I, glvec_I, C_vec)
        (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)
        SPB_depol1[:,j] = PARAMS_depol[:,1]
        SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
        PER_depol1[:,j] = PARAMS_depol[:,2]
        PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
        DC_depol1[:,j] = PARAMS_depol[:,3]
        DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
        IBF_depol1[:,j] = PARAMS_depol[:,4]
        IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
        freq_depol_vec1[:,j] = freq_depol
        freq_hyperpol_vec1[:,j] = freq_hyperpol

      end

      return (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1)
    end

    @time (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1) = simu_networks_2cells_WANG(coef_red, gamma, n_net,ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4)#,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)


    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)
  end
end
