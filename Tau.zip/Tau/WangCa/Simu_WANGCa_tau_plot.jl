# Defines output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf
# varying TmCaT
const coef_red = 1/500

# Include model
include("WangCa_tau.jl")


# Simulation parameters
const T = 1000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Ttransient = 401
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

const gamma=0.2

# Model parameters (global)
const theta_red = 5.

const VCa = 120.
const VH = -40.
const VK = -80.
const VNa = 55.
const Vl = -70.
const sigK = 10.
const sigNa = 6.
const sigNaP = -5.
const thetah = -79.
const kh = 5.

const C = 1.

# Model parameters (mean) - Ecells
const gCaT_E = 1.
const gH_E = 0.04
const gKd_E = 30.
const gNa_E = 42.
const gNaP_E = 9.
const gl_E = 0.12

# Model parameters (mean) - Icells
const gCaT_I = 1.
const gH_I = 0.04
const gKd_I = 30.
const gNa_I = 42.
const gNaP_I = 9.
const gl_I = 0.12

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

# Parameters
const C_vec = C.*ones(ncells)#*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

const gCaTvec_E = gCaT_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gHvec_E = gH_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKdvec_E = gKd_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaPvec_E = gNaP_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const glvec_E = gl_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

const gCaTvec_I = gCaT_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gHvec_I = gH_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKdvec_I = gKd_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaPvec_I = gNaP_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const glvec_I = gl_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 1500
const tstepEfinal = 1503
const IappI = 3.
const IstepI1 = -4.3
const IstepI2 = -4.3
const IstepI3 = -4.3
const IstepI4 = -4.3
const tstepIinit1 = 600
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

# Synaptic connections
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 4.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# RUN MODEL
@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateWANGCA_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)

# PLOT
Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
plot(Vplot1,Vplot2, layout=(ncells,1))
