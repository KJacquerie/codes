# Defines output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# varying tau
const coef_red = 1/8

# Include model
include("Drion_tau.jl")


# Simulation parameters
const T = 2000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,401/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C = 1
const VNa = 50
const VK = -85
const VCa = 120
const Vl = -55
const VH = -20
const Kd = 170

# Model parameters (mean) - Ecells
const gl_E = 0.055
const gNa_E = 170
const gKd_E = 40
const k1_E = 1.e-1
const k2_E = 0.1e-1
const gH_E = 0.01
const gKCa_E = 4
const gCaT_E = 0.55

# Model parameters (mean) - Icells
const gl_I = 0.055
const gNa_I = 170
const gKd_I = 40
const k1_I = 1.e-1
const k2_I = 0.1e-1
const gH_I = 0.01
const gKCa_I = 4
const gCaT_I = 0.55

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

const gNavec_E = gNa_E*ones(ncells)
const gKdvec_E = gKd_E*ones(ncells)
const gHvec_E = gH_E*ones(ncells)
const gCaTvec_E = gCaT_E*ones(ncells)
const gKCavec_E = gKCa_E*ones(ncells)
const glvec_E = gl_E*ones(ncells)
const k1vec_E = k1_E*ones(ncells)
const k2vec_E = k2_E*ones(ncells)

const gNavec_I = gNa_I*ones(ncells)
const gKdvec_I = gKd_I*ones(ncells)
const gHvec_I = gH_I*ones(ncells)
const gCaTvec_I = gCaT_I*ones(ncells)
const gKCavec_I = gKCa_I*ones(ncells)
const glvec_I = gl_I*ones(ncells)
const k1vec_I = k1_I*ones(ncells)
const k2vec_I = k2_I*ones(ncells)

# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 4500
const tstepEfinal = 4503
const IappI = 1.
const IstepI1 = -3.6
const IstepI2 = -3.6
const IstepI3 = -3.6
const IstepI4 = -3.6
const tstepIinit1 = 750
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

# Connectivity
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# RUN MODEL
@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateTOY_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)


Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
plot(Vplot1,Vplot2, layout=(ncells,1))
