# Create a matrix of random conductances
filename = "Drion"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

const gamma_mat=[0.]#[0.3 0.5]

# Circuit caracteristics
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells
const n_net = 1#400

const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# Model parameters - Ecells
const gl_E = 0.055
const gNa_E = 170
const gKd_E = 40
const k1_E = 1.e-1
const k2_E = 0.1e-1
const gH_E = 0.01
const gKCa_E = 4
const gCaT_E = 0.55
# Model parameters - Icells
const gl_I = 0.055
const gNa_I = 170
const gKd_I = 40
const k1_I = 1.e-1
const k2_I = 0.1e-1
const gH_I = 0.01
const gKCa_I = 4
const gCaT_I = 0.55

# Build matrices
const gsyn_mat = 1.0*ones(3,n_net)
const gE_mat = 1.0*ones(8,n_net)
const gI_mat = 1.0*ones(8,n_net)

for i= 1:length(gamma_mat)
    gamma=gamma_mat[i]
    cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Tau/%s/g_mat/gamma%d",filename, gamma*100))

    for j=1:n_net
        gsyn_mat[1,j] = gEIAMPA*(1-2*gamma*(rand(1)[1]-0.5))
        gsyn_mat[2,j] = gIEGABAA*(1-2*gamma*(rand(1)[1]-0.5))
        gsyn_mat[3,j] = gIEGABAB*(1-2*gamma*(rand(1)[1]-0.5))

        gE_mat[1,j] = gNa_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[2,j] = gKd_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[3,j] = gCaT_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[4,j]= gH_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[5,j] = gKCa_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[6,j] = gl_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[7,j] = k1_E*(1-2*gamma*(rand(1)[1]-0.5))
        gE_mat[8,j] = k2_E*(1-2*gamma*(rand(1)[1]-0.5))

        gI_mat[1,j] = gNa_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[2,j] = gKd_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[3,j] = gCaT_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[4,j] = gH_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[5,j] = gKCa_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[6,j] = gl_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[7,j] = k1_I*(1-2*gamma*(rand(1)[1]-0.5))
        gI_mat[8,j] = k2_I*(1-2*gamma*(rand(1)[1]-0.5))
    end

    writedlm(@sprintf("gsyn_mat%d.dat",gamma*100), gsyn_mat, header = false)
    writedlm(@sprintf("gE_mat%d.dat",gamma*100), gE_mat, header = false)
    writedlm(@sprintf("gI_mat%d.dat",gamma*100), gI_mat, header = false)

end
