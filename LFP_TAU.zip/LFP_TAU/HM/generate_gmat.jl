# Create a matrix of random conductances
filename = "HM"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

const gamma_mat=[0.05 0.15]

# Circuit caracteristics
const nEcells = 100 # Number of excitatory cells
const nIcells = 100 # Number of inhibitory cells
const ncells = nEcells+nIcells
const n_net = 1

const gEEAMPA  = 0.0/nEcells
const gEIAMPA  = 0.01/nEcells
const gIEGABAA = 0.04/nIcells
const gIEGABAB = 0.01/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# Model parameters - Ecells
const gNa_E = 12.
const gNap_E = 7.e-3
const gNaleak_E = 2.65e-3
const gA_E = 20.e-3
const gA2_E = 15.e-3
const gKleak_E = 7.e-3
const gK2a_E = 38.e-3
const gK2b_E = 26.e-3
const gc_E = 1.
const gL_E = 0.8
const gT_E= 1.

# Model parameters - Icells
const gNa_I = 12.
const gNap_I = 7.e-3
const gNaleak_I = 2.65e-3
const gA_I = 20.e-3
const gA2_I = 15.e-3
const gKleak_I = 7.e-3
const gK2a_I = 38.e-3
const gK2b_I = 26.e-3
const gc_I = 1.
const gL_I = 0.8
const gT_I= 1.

# Build matrices
const gEI_mat = 1.0*ones(nEcells,nIcells)
const gIE_mat = 1.0*ones(nIcells,nEcells)
const gIE2_mat = 1.0*ones(nIcells,nEcells)
const gE_mat = 1.0*ones(ncells,11)
const gI_mat = 1.0*ones(ncells,11)


for i= 1:length(gamma_mat)
    gamma=gamma_mat[i]
    cd(@sprintf("/Volumes/SSD250/PhD/2020-Project/LFP_Tau_ok/%s/g_mat/gamma%d",filename, gamma*100))



    gEI_mat  = gEIAMPA*(ones(nEcells, nIcells)-2*gamma*(rand(nEcells, nIcells)-0.5*ones(nEcells, nIcells)))
    gIE_mat  = gIEGABAA*(ones(nIcells, nEcells)-2*gamma*(rand(nIcells, nEcells)-0.5*ones(nIcells, nEcells)))
    gIE2_mat = gIEGABAB*(ones(nIcells, nEcells)-2*gamma*(rand(nIcells, nEcells)-0.5*ones(nIcells, nEcells)))

    gE_mat[:,1]  = gNa_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,2]  = gA_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,3]  = gT_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,4]  = gA2_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,5]  = gK2a_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,6]  = gK2b_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,7]  = gNap_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,8]  = gc_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,9]  = gL_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,10] = gNaleak_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gE_mat[:,11] = gKleak_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))

    gI_mat[:,1]  = gNa_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,2]  = gA_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,3]  = gT_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,4]  = gA2_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,5]  = gK2a_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,6]  = gK2b_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,7]  = gNap_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,8]  = gc_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,9]  = gL_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,10] = gNaleak_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))
    gI_mat[:,11] = gKleak_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))#*(1-2*gamma*(rand(1)[1]-0.5))


    writedlm(@sprintf("gEI_mat%d.dat",gamma*100), gEI_mat, header = false)
    writedlm(@sprintf("gIE_mat%d.dat",gamma*100), gIE_mat, header = false)
    writedlm(@sprintf("gIE2_mat%d.dat",gamma*100), gIE2_mat, header = false)
    writedlm(@sprintf("gE_mat%d.dat",gamma*100), gE_mat, header = false)
    writedlm(@sprintf("gI_mat%d.dat",gamma*100), gI_mat, header = false)

end
