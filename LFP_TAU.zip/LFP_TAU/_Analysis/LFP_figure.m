%MEAN FIELD PLOT
function LFP_figure(Name, tau, var, dt, freq_max, SNR)
%figure settings
set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');

pt = 11; 

noverlap = 100/dt; %100
window = 5000/dt; %5000
fs=1000/dt;
close all

%% cell E

tmp = load(sprintf('../%s/Results_LFP/tau%d/gamma%d/LFP_E_%d.dat',Name,tau, var,var));
 
figure(1)
spectrogram(tmp,window,noverlap,[],fs,'MinThreshold',-SNR,'yaxis')



xlabel('', 'interpreter','latex','fontsize',pt)
ylabel('','interpreter','latex','fontsize',pt)
ptx = 11;%8.5; 
pty = 4;%3;

%if(strcmp(Name,'Wang'))
    %xlabel('Time [s]', 'interpreter','latex','fontsize',pt)
%    pty=4;
%end
%if(strcmp(Name,'HM') && var ==0)
    %ylabel('Frequency [Hz]','interpreter','latex','fontsize',pt)
   % pt=5;
%end

ylim([0 freq_max])
if(var==0)
    %ylabel('Frequency [Hz]','interpreter','latex','fontsize',pt)
    yticks([0 freq_max])
    yticklabels({'0',num2str(freq_max*10^3)} )
    colorbar('off');
%    c= colorbar;
%     c.LineWidth = 1;
%     % Legende
%     c.Label.String = '';
% 
%     % Latex
%     c.TickLabelInterpreter = 'latex';
%     c.Label.Interpreter = 'latex';
%     c.Label.FontSize = 11;
else
    ylabel('','interpreter','latex','fontsize',pt)
yticks([0 freq_max])
yticklabels({'0',num2str(freq_max*10^3)} )
    colorbar('off');
%    c= colorbar;
%     c.LineWidth = 1;
%     % Legende
%     c.Label.String = ''%'P/f [dB/Hz]';
% 
%     % Latex
%     c.TickLabelInterpreter = 'latex';
%     c.Label.Interpreter = 'latex';
%     c.Label.FontSize = 11;
end

% if(var==0)
%     colorbar('off')
%     ptx = 8.5; 
%     pty = 4; 
% else
%     ptx = 10; 
%     pty = 4;
% end

%colorbar('fontsize',pt)



set(gca,'TickLabelInterpreter','latex','fontsize', pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);


saveas(figure(1),sprintf('Figures/%s/%s_LFP_E_tau%d_%d',Name, Name,tau, var),'epsc')
%print(sprintf('Figures/%s_LFP_E_n%d_%d',Name,ncells,var),'-dpdf')


 %% cell I

tmp = load(sprintf('../%s/Results_LFP/tau%d/gamma%d/LFP_I_%d.dat',Name,tau, var,var));
 
figure(1)
spectrogram(tmp,window,noverlap,[],fs,'MinThreshold',-SNR,'yaxis')



xlabel('', 'interpreter','latex','fontsize',pt)
ylabel('','interpreter','latex','fontsize',pt)
ptx = 11;%8.5; 
pty = 4;%3;

%if(strcmp(Name,'Wang'))
    %xlabel('Time [s]', 'interpreter','latex','fontsize',pt)
%    pty=4;
%end
%if(strcmp(Name,'HM') && var ==0)
    %ylabel('Frequency [Hz]','interpreter','latex','fontsize',pt)
   % pt=5;
%end

ylim([0 freq_max])
if(var==0)
    %ylabel('Frequency [Hz]','interpreter','latex','fontsize',pt)
    yticks([0 freq_max])
    yticklabels({'0',num2str(freq_max*10^3)} )
    colorbar('off');
%    c= colorbar;
%     c.LineWidth = 1;
%     % Legende
%     c.Label.String = '';
% 
%     % Latex
%     c.TickLabelInterpreter = 'latex';
%     c.Label.Interpreter = 'latex';
%     c.Label.FontSize = 11;
else
    ylabel('','interpreter','latex','fontsize',pt)
yticks([0 freq_max])
yticklabels({'0',num2str(freq_max*10^3)} )
    colorbar('off');
%    c= colorbar;
%     c.LineWidth = 1;
%     % Legende
%     c.Label.String = ''%'P/f [dB/Hz]';
% 
%     % Latex
%     c.TickLabelInterpreter = 'latex';
%     c.Label.Interpreter = 'latex';
%     c.Label.FontSize = 11;
end

% if(var==0)
%     colorbar('off')
%     ptx = 8.5; 
%     pty = 4; 
% else
%     ptx = 10; 
%     pty = 4;
% end

%colorbar('fontsize',pt)



set(gca,'TickLabelInterpreter','latex','fontsize', pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);


saveas(figure(1),sprintf('Figures/%s/%s_LFP_I_tau%d_%d',Name, Name,tau, var),'epsc')
%print(sprintf('Figures/%s_LFP_I_n%d_%d',Name,ncells,var),'-dpdf')


end
