%MEAN FIELD PLOT
function LFP_curve(Name, tau, gamma, dt, freq_vec, SNR_vec)
    set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
    set(groot, 'defaultLegendInterpreter','latex');
    pt = 11; 
    ptx = 3.5;
    pty = 4; 
    
    T = 42000;
    %Tdt = T/dt;
    t = dt:dt:T;
    
    for i=1:1:length(gamma)
        ptx = 3.5;
        pty = 3; 
    
        var = gamma(i);
        freq_max = freq_vec(i);
        SNR = SNR_vec(i);
        noverlap = 50/dt; %100
        window = 5000/dt; %5000
        fs=1000/dt;

        tmp = load(sprintf('../%s/Results_LFP/tau%d/gamma%d/LFP_I_%d.dat',Name,tau, var,var));
        tmpE = load(sprintf('../%s/Results_LFP/tau%d/gamma%d/LFP_E_%d.dat',Name,tau, var,var));
        
        % Spectogram
        figure(1)
        subplot(1,length(gamma), i)
        spectrogram(tmp,window,noverlap,[],fs,'MinThreshold',-SNR,'yaxis')

        xlabel('', 'interpreter','latex','fontsize',pt)
        ylabel('','interpreter','latex','fontsize',pt)
        ylim([0 freq_max])
        yticks([0 freq_max])
        yticklabels({'0',num2str(freq_max*10^3)} )
        colorbar('off');
       
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(1),'PaperPositionMode','auto');
        set(figure(1), 'PaperUnits', 'centimeters');
        set(figure(1), 'PaperPosition', [0 0 ptx pty]);
        
        % LFP curve
        interv = 19400/dt:24000/dt; 
        color_vec = [1/256 1/256 1/256]*110;
        
        figure(2)
        subplot(1,length(gamma),i)
        plot(t(interv)*1e-3, tmp(interv), 'color', color_vec)
        xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
        if(isnan(min(tmp(interv))) || isnan(max(tmp(interv))))
        else
            if(min(tmp(interv)) ~= max(tmp(interv)) )
                ylim([min(tmp(interv)) max(tmp(interv))])
            end
        end
        box off
        title('')
        xticks([21,22])
        xticklabels({'0','1'})
        
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(2),'PaperPositionMode','auto');
        set(figure(2), 'PaperUnits', 'centimeters');
        set(figure(2), 'PaperPosition', [0 0 ptx pty]);
        
        % LFP curve large
        interv = 20800/dt:30000/dt; 
        color_vec = [1/256 1/256 1/256]*110;
        
        figure(3)
        subplot(1,length(gamma),i)
        plot(t(interv)*1e-3, tmp(interv), 'color', color_vec)
        xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
        if(isnan(min(tmp(interv))) || isnan(max(tmp(interv))))
        else
            if(min(tmp(interv)) ~= max(tmp(interv)) )
                ylim([min(tmp(interv)) max(tmp(interv))])
            end
        end
        box off
        tit = title(sprintf('%d',var));
        set(tit, 'FontName', 'latex', 'FontSize', pt); 
        xticks([21,22])
        xticklabels({'0','1'})
        
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(3),'PaperPositionMode','auto');
        set(figure(3), 'PaperUnits', 'centimeters');
        set(figure(3), 'PaperPosition', [0 0 ptx+0.5 pty+0.5]);
        
        % LFP curve large DEUX
        interv = 30000/dt:40000/dt; 
        color_vec = [1/256 1/256 1/256]*110;
        
        figure(4)
        subplot(1,length(gamma),i)
        plot(t(interv)*1e-3, tmp(interv), 'color', color_vec)
        xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
        if(isnan(min(tmp(interv))) || isnan(max(tmp(interv))))
        else
            if(min(tmp(interv)) ~= max(tmp(interv)) )
                ylim([min(tmp(interv)) max(tmp(interv))])
            end
        end
        box off
        tit = title(sprintf('%d',var));
        set(tit, 'FontName', 'latex', 'FontSize', pt); 
        xticks([31,32])
        xticklabels({'0','1'})
        
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(4),'PaperPositionMode','auto');
        set(figure(4), 'PaperUnits', 'centimeters');
        set(figure(4), 'PaperPosition', [0 0 ptx+0.5 pty+0.5]);
        
        %% E-cell
        figure(5)
        subplot(1,length(gamma), i)
        spectrogram(tmpE,window,noverlap,[],fs,'MinThreshold',-SNR,'yaxis')

        xlabel('', 'interpreter','latex','fontsize',pt)
        ylabel('','interpreter','latex','fontsize',pt)
        ylim([0 freq_max])
        yticks([0 freq_max])
        yticklabels({'0',num2str(freq_max*10^3)} )
        colorbar('off');
       
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(5),'PaperPositionMode','auto');
        set(figure(5), 'PaperUnits', 'centimeters');
        set(figure(5), 'PaperPosition', [0 0 ptx pty]);
         
         % LFP curve
        interv = 19400/dt:24000/dt; 
        color_vec = [1/256 1/256 1/256]*110;
        
        figure(6)
        subplot(1,length(gamma),i)
        plot(t(interv)*1e-3, tmpE(interv), 'color', color_vec)
        xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
        if(isnan(min(tmpE(interv))) || isnan(max(tmpE(interv))))
        else
            if(min(tmpE(interv)) ~= max(tmpE(interv)) )
                ylim([min(tmpE(interv)) max(tmpE(interv))])
            end
        end
        box off
        title('')
        xticks([21,22])
        xticklabels({'0','1'})
        
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(6),'PaperPositionMode','auto');
        set(figure(6), 'PaperUnits', 'centimeters');
        set(figure(6), 'PaperPosition', [0 0 ptx pty]);
        
        % LFP curve large
        interv = 20800/dt:30000/dt; 
        color_vec = [1/256 1/256 1/256]*110;
        
        figure(7)
        subplot(1,length(gamma),i)
        plot(t(interv)*1e-3, tmpE(interv), 'color', color_vec)
        xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
        if(isnan(min(tmpE(interv))) || isnan(max(tmpE(interv))))
        else
            if(min(tmpE(interv)) ~= max(tmpE(interv)) )
                ylim([min(tmpE(interv)) max(tmpE(interv))])
            end
        end
        box off
        tit = title(sprintf('%d',var));
        set(tit, 'FontName', 'latex', 'FontSize', pt); 
        xticks([21,22])
        xticklabels({'0','1'})
        
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(7),'PaperPositionMode','auto');
        set(figure(7), 'PaperUnits', 'centimeters');
        set(figure(7), 'PaperPosition', [0 0 ptx+0.5 pty+0.5]);
        
        % LFP curve large DEUX
        interv = 30000/dt:40000/dt; 
        color_vec = [1/256 1/256 1/256]*110;
        
        figure(8)
        subplot(1,length(gamma),i)
        plot(t(interv)*1e-3, tmpE(interv), 'color', color_vec)
        xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])   
        if(isnan(min(tmpE(interv))) || isnan(max(tmpE(interv))))
        else
            if(min(tmpE(interv)) ~= max(tmpE(interv)) )
                ylim([min(tmpE(interv)) max(tmpE(interv))])
            end
        end
        box off
        tit = title(sprintf('%d',var));
        set(tit, 'FontName', 'latex', 'FontSize', pt); 
        xticks([31,32])
        xticklabels({'0','1'})
        
        set(gca,'TickLabelInterpreter','latex','fontsize', pt)
        set(figure(8),'PaperPositionMode','auto');
        set(figure(8), 'PaperUnits', 'centimeters');
        set(figure(8), 'PaperPosition', [0 0 ptx+0.5 pty+0.5]);
        
         

    end
    
    %% SAVE: I-cell
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(1),'PaperPositionMode','auto');
    set(figure(1), 'PaperUnits', 'centimeters');
    set(figure(1), 'PaperPosition', [0 0 ptx*length(gamma) pty+0.25]);
    saveas(figure(1),sprintf('Figures/%s/%s_LFP_I_tau%d',Name, Name,tau),'epsc')
    
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(2),'PaperPositionMode','auto');
    set(figure(2), 'PaperUnits', 'centimeters');
    set(figure(2), 'PaperPosition', [0 0 ptx*length(gamma) pty+0.5]);
    saveas(figure(2),sprintf('Figures/%s/%s_LFP_I_tau%d_zoom',Name, Name,tau),'epsc') 
    
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(3),'PaperPositionMode','auto');
    set(figure(3), 'PaperUnits', 'centimeters');
    set(figure(3), 'PaperPosition', [0 0 ptx*length(gamma)*1.2 pty+0.5]);
    saveas(figure(3),sprintf('Figures/%s/%s_LFP_I_tau%d_curve',Name, Name,tau),'epsc') 
    
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(4),'PaperPositionMode','auto');
    set(figure(4), 'PaperUnits', 'centimeters');
    set(figure(4), 'PaperPosition', [0 0 ptx*length(gamma)*1.2 pty+0.5]);
    saveas(figure(4),sprintf('Figures/%s/%s_LFP_I_tau%d_curve2',Name, Name,tau),'epsc') 
    
    %% SAVE E-cell
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(5),'PaperPositionMode','auto');
    set(figure(5), 'PaperUnits', 'centimeters');
    set(figure(5), 'PaperPosition', [0 0 ptx*length(gamma) pty+0.25]);
    saveas(figure(5),sprintf('Figures/%s/%s_LFP_E_tau%d',Name, Name,tau),'epsc')
    
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(6),'PaperPositionMode','auto');
    set(figure(6), 'PaperUnits', 'centimeters');
    set(figure(6), 'PaperPosition', [0 0 ptx*length(gamma) pty+0.5]);
    saveas(figure(6),sprintf('Figures/%s/%s_LFP_E_tau%d_zoom',Name, Name,tau),'epsc') 
        
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(7),'PaperPositionMode','auto');
    set(figure(7), 'PaperUnits', 'centimeters');
    set(figure(7), 'PaperPosition', [0 0 ptx*length(gamma)*1.2 pty+0.5]);
    saveas(figure(7),sprintf('Figures/%s/%s_LFP_E_tau%d_curve',Name, Name,tau),'epsc') 
    
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(figure(8),'PaperPositionMode','auto');
    set(figure(8), 'PaperUnits', 'centimeters');
    set(figure(8), 'PaperPosition', [0 0 ptx*length(gamma)*1.2 pty+0.5]);
    saveas(figure(8),sprintf('Figures/%s/%s_LFP_E_tau%d_curve2',Name, Name,tau),'epsc') 
end
