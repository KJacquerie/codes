clear ALL
close all
clc 

%%
% time vector
T = 42000;
dt = 0.005;
Tdt = T/dt;
t = dt:dt:T;


%%
Name = 'Destexhe'; 
ncells = 200; 
var = 0; 
tau=55 ;

% LFP vector
LFP_I= load(sprintf('../%s/Results_LFP/tau%d/gamma%d/LFP_I_%d.dat',Name,tau, var,var));


%% ZOOM FIGURE
interv = 20500/dt:23000/dt; 
pt=11;
ptx = 6.2; 
pty = 1.75; 
color_vec = [1/256 1/256 1/256]*110;


figure
plot(t(interv)*1e-3, LFP_I(interv), 'color', color_vec)
xlim([min(t(interv))*1e-3 max(t(interv))*1e-3])
box off
title('')
xticks([21,22])
xticklabels({'0','1'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 ptx pty]);
% print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-depsc')
% print(sprintf('Figures/V/LFPtrace%s_%d_zoom', Name, var),'-dpdf')

%%