%MEAN FIELD PLOT
function LFP_figure_subplot(Name, tau, gamma, dt, freq_vec, SNR_vec)
    set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
    set(groot, 'defaultLegendInterpreter','latex');
    pt = 11; 
    figure
    for i=1:1:length(gamma)
        var = gamma(i);
        freq_max = freq_vec(i);
        SNR = SNR_vec(i);
        noverlap = 100/dt; %100
        window = 5000/dt; %5000
        fs=1000/dt;

        tmp = load(sprintf('../%s/Results_LFP/tau%d/gamma%d/LFP_I_%d.dat',Name,tau, var,var));
        
        subplot(1,length(gamma), i)
        spectrogram(tmp,window,noverlap,[],fs,'MinThreshold',-SNR,'yaxis')


        xlabel('', 'interpreter','latex','fontsize',pt)
        ylabel('','interpreter','latex','fontsize',pt)
        ylim([0 freq_max])
        yticks([0 freq_max])
        yticklabels({'0',num2str(freq_max*10^3)} )
        colorbar('off');

    end
    ptx = 3.5;
    pty = 3.25; 
    set(gca,'TickLabelInterpreter','latex','fontsize', pt)
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 ptx*length(gamma) pty]);

    saveas(figure(1),sprintf('Figures/%s/%s_LFP_I_tau%d',Name, Name,tau),'epsc')
     
end
