# Create a matrix of random conductances
filename = "WangCa"
# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

const gamma_mat=[0.05 0.15 0.25]

# Circuit caracteristics
const nEcells = 100 # Number of excitatory cells
const nIcells = 100 # Number of inhibitory cells
const ncells = nEcells+nIcells
const n_net = 1#

const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 4.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# Model parameters - Ecells
const gCaT_E = 1.
const gH_E = 0.04
const gKd_E = 30.
const gNa_E = 42.
const gNaP_E = 9.
const gl_E = 0.12

# Model parameters - Icells
const gCaT_I = 1.
const gH_I = 0.04
const gKd_I = 30.
const gNa_I = 42.
const gNaP_I = 9.
const gl_I = 0.12

# Build matrices
const gEI_mat = 1.0*ones(nEcells,nIcells)
const gIE_mat = 1.0*ones(nIcells,nEcells)
const gIE2_mat = 1.0*ones(nIcells,nEcells)
const gE_mat = 1.0*ones(ncells,6)
const gI_mat = 1.0*ones(ncells,6)

for i= 1:length(gamma_mat)
    gamma=gamma_mat[i]
    cd(@sprintf("/Volumes/SSD250/PhD/2020-Project/LFP_Tau_ok/%s/g_mat/gamma%d",filename, gamma*100))

    gEI_mat  = gEIAMPA*(ones(nEcells, nIcells)-2*gamma*(rand(nEcells, nIcells)-0.5*ones(nEcells, nIcells)))
    gIE_mat  = gIEGABAA*(ones(nIcells, nEcells)-2*gamma*(rand(nIcells, nEcells)-0.5*ones(nIcells, nEcells)))
    gIE2_mat = gIEGABAB*(ones(nIcells, nEcells)-2*gamma*(rand(nIcells, nEcells)-0.5*ones(nIcells, nEcells)))

    gE_mat[:,1] = gNa_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gE_mat[:,2] = gKd_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gE_mat[:,3] = gCaT_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gE_mat[:,4] = gH_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gE_mat[:,5] = gNaP_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gE_mat[:,6] = gl_E*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    gI_mat[:,1] = gNa_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gI_mat[:,2] = gKd_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gI_mat[:,3] = gCaT_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gI_mat[:,4] = gH_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gI_mat[:,5] = gNaP_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
    gI_mat[:,6] = gl_I*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

    writedlm(@sprintf("gEI_mat%d.dat",gamma*100), gEI_mat, header = false)
    writedlm(@sprintf("gIE_mat%d.dat",gamma*100), gIE_mat, header = false)
    writedlm(@sprintf("gIE2_mat%d.dat",gamma*100), gIE2_mat, header = false)
    writedlm(@sprintf("gE_mat%d.dat",gamma*100), gE_mat, header = false)
    writedlm(@sprintf("gI_mat%d.dat",gamma*100), gI_mat, header = false)

end
