function y = prop_computation(Name, manip)
   
    num_sim=1; % only take into account the first step current
    
    for j=1:1:length(manip)
        gamma = manip(j);
        SPB_depol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/SPB_depol%d.dat',Name,gamma,num_sim));
        SPB_hyperpol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/SPB_hyperpol%d.dat',Name,gamma,num_sim));
        PER_depol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/PER_depol%d.dat',Name,gamma,num_sim));
        PER_hyperpol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/PER_hyperpol%d.dat',Name,gamma,num_sim));
        DC_depol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/DC_depol%d.dat',Name,gamma,num_sim));
        DC_hyperpol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/DC_hyperpol%d.dat',Name,gamma,num_sim));
        IBF_depol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/IBF_depol%d.dat',Name,gamma,num_sim));
        IBF_hyperpol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/IBF_hyperpol%d.dat',Name,gamma,num_sim));
        freq_depol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/freq_depol%d.dat',Name,gamma,num_sim));
        freq_hyperpol = load(sprintf('/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/freq_hyperpol%d.dat',Name,gamma,num_sim));

        [synburst,synburst2] = determ_synburst(SPB_depol, SPB_hyperpol, PER_depol, PER_hyperpol, DC_depol,DC_hyperpol,IBF_depol,IBF_hyperpol,freq_depol,freq_hyperpol);
        y(j) = length(synburst2)/length(freq_hyperpol(2,:));

    end



end