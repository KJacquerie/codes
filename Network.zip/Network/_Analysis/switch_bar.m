close all
set(groot, 'defaultAxesTickLabelInterpreter','latex'); set(groot, 'defaultLegendInterpreter','latex');
pt = 11;
ptx = 9;
pty = 9;



manip =  [0 10 20 30]% 40 50]; 

Prop_Drion = prop_computation('Drion',manip);
%Prop_Drion3 = prop_computation('Drion3',manip);

Prop_Destexhe = prop_computation('Destexhe',manip);

%Prop_D98 = prop_computation('Destexhe98',manip);
Prop_Du98 = prop_computation('Destexheu98',manip);

Prop_HM = prop_computation('HM',manip);

Prop_Wang = prop_computation('Wang',manip);
Prop_WangCa = prop_computation('WangCa',manip);


Prop_Rush = prop_computation('Rush',manip);
Prop_RushCa = prop_computation('RushCa',manip);
Prop_RushCa2 = prop_computation('RushCa2',manip);
Prop_RushCa3 = prop_computation('RushCa3',manip);

%%
figure(1)
bb= bar([  100*Prop_Drion', 100*Prop_Destexhe', 100*Prop_Du98', 100*Prop_HM', 100*Prop_Wang', 100*Prop_WangCa', 100*Prop_Rush',  100*Prop_RushCa']);

box off
%le= legend ('Drion', 'Destexhe', 'D98', 'HM', 'Wang', 'WangCa', 'RushA', 'RushCaA','RushA10');%, 'RushCaB2');
%set(le,'location','northeast','interpreter','latex','fontsize',pt);
xticks([1 2 3 4 5 6 ])
%xticklabels({'0', '5','10','15','20', '25','30'})%,'40', '50'})
%xticklabels({'0','10','20', '30', '50'})

bb(1).FaceColor=[132 180 239]./255;
bb(2).FaceColor=[149 37 81]./255;
bb(3).FaceColor=[60 145 148]./255;
bb(4).FaceColor=[112 173 71]./255;
bb(5).FaceColor=[237 125 57]./255;
bb(7).FaceColor=[248 192 69]./255;
bb(6).FaceColor=[237 125 57]./255;
bb(8).FaceColor=[248 192 69]./255;

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
xticks([1:6])
xticklabels({'0','10','20','30','40', '50'})
%xlabel('Relative intrinsic variability[\%]','interpreter','latex','fontsize',pt)
%ylabel('Rhythmic networks $y$ [\%]','interpreter','latex','fontsize',pt)
title('')
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 8 6]);
print('Figures/BAR_tot','-depsc')
print('Figures/BAR_tot','-dpdf')

%%
interv = 2:4;
figure(2)
bb= bar([  100*Prop_Drion(interv)', 100*Prop_Destexhe(interv)', 100*Prop_Du98(interv)', 100*Prop_HM(interv)', 100*Prop_Wang(interv)', 100*Prop_WangCa(interv)', 100*Prop_Rush(interv)',  100*Prop_RushCa(interv)']);

box off
%le= legend ('Drion', 'Destexhe', 'D98', 'HM', 'Wang', 'WangCa', 'RushA', 'RushCaA','RushA10');%, 'RushCaB2');
%set(le,'location','northeast','interpreter','latex','fontsize',pt);

bb(1).FaceColor=[132 180 239]./255;
bb(2).FaceColor=[149 37 81]./255;
bb(3).FaceColor=[60 145 148]./255;
bb(4).FaceColor=[112 173 71]./255;
bb(5).FaceColor=[237 125 57]./255;
bb(7).FaceColor=[248 192 69]./255;
bb(6).FaceColor=[237 125 57]./255;
bb(8).FaceColor=[248 192 69]./255;
hatch(bb(5))
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',pt)
xticks([1:3])
xticklabels({'10','20','30'})
%xlabel('Relative intrinsic variability[\%]','interpreter','latex','fontsize',pt)
%ylabel('Rhythmic networks $y$ [\%]','interpreter','latex','fontsize',pt)
title('')
set(gcf,'PaperPositionMode','auto');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 10 4]);
print('Figures/BAR','-depsc')
print('Figures/BAR','-dpdf')

final_mat = [  100*Prop_Drion(interv)', 100*Prop_Destexhe(interv)', 100*Prop_Du98(interv)', 100*Prop_HM(interv)', 100*Prop_Wang(interv)', 100*Prop_WangCa(interv)', 100*Prop_Rush(interv)',  100*Prop_RushCa(interv)'];
%%
figure(3)
hold on
plot(Prop_Drion,'-o')
plot(Prop_Destexhe,'-o')
%plot(Prop_D98,'-o')
plot(Prop_HM,'-o')
plot(Prop_Wang,'-o')
plot(Prop_WangCa,'-o')
plot(Prop_Rush,'-o')
plot(Prop_RushCa,'-o')
hold off
