close all 
clear all 
clc


set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');


%%
  plot_V('Drion', 'ok', 0.01)
  plot_V('Drion', 'ko',0.01)
 
   
  plot_V('Wang', 'ok',0.01)
  plot_V('Wang', 'ko', 0.01)
 
%%
function plot_V (Name, Name_expm, dt)
    pt=11;
    T_start = 1600/dt; 
    T_end = 3500/dt; 
    
    t= load(sprintf('../%s/V/t_%s.dat',Name, Name_expm));
    V = load(sprintf('../%s/V/V_%s.dat',Name, Name_expm));
    figure
    subplot(2,1,1)
    plot(t(T_start:T_end),V(T_start:T_end,1), 'color', [64/256 64/256 64/256])
    ylim([-110 70])
    xlim([min(t(T_start:T_end))-100 max(t(T_start:T_end))+100])
    box off
    yticks([-20,30])
    yticklabels({'0','50'})
    b = get(gca,'YTickLabel');
    set(gca,'YTickLabel',b,'fontsize',pt)

    xticks([0])
    xticklabels({''})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    title('')
    subplot(2,1,2)
    plot(t(T_start:T_end),V(T_start:T_end,2), 'color', [64/256 64/256 64/256])
    ylim([-110 70])
    xlim([min(t(T_start:T_end))-100 max(t(T_start:T_end))+100])
    xticks([1500,2000])
    xticklabels({'1500','2000'})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',pt)
    box off
    yticks([-20,30])
    yticklabels({'0','50'})
    b = get(gca,'YTickLabel');
    set(gca,'YTickLabel',b,'fontsize',pt)
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 4 4]);

    print(sprintf('Figures/V/%s_%s', Name, Name_expm),'-depsc')
    print(sprintf('Figures/V/%s_%s', Name, Name_expm),'-dpdf')

end