# gating functions
# calcium activation
mCaTinf(V::Float64) = 1/(1+exp((V-tetas)/ks))
taumCaT(V::Float64) = coef_red_m*((1.7 + exp(-(V+28.8)/13.5))/(1+exp(-(V+63)/7.8)))

#calcium inactivation
hCaTinf(V::Float64) = 1/(0.5 + sqrt(0.25 + exp((V-tetah)/kh)))
tauhCaT(V::Float64) = coef_red_h*(exp((V+150)/18)/(1.5 + sqrt(0.25 + exp((V-80)/4))) + 30)

#sodium activation
alpham(V::Float64) = 0.1*(V+35-sigm)/(1 - exp(-0.1*(V+35-sigm)))
betam(V::Float64) = 4*exp(-0.05*(V+60-sigm))
minf(V::Float64) = alpham(V)/(alpham(V)+betam(V))

#sodium inactivation
alphan(V::Float64) = 0.01*(V+50-sign)/(1 - exp(-0.1*(V+50-sign)))
betan(V::Float64) = 0.125*exp(-0.0125*(V+60-sign))
ninf(V::Float64) = alphan(V)/(alphan(V)+betan(V))
taun(V::Float64) = coef_red_n*(0.05/(alphan(V)+betan(V)))


Tm(V::Float64) = 1/(1+exp(-(V-2)/5))

function dV(C::Float64, V::Float64, n::Float64, mCaT::Float64, hCaT::Float64, Iapp::Float64, Istep::Float64, gNa::Float64, gKd::Float64, gCaT::Float64, gNaleak::Float64, gKleak::Float64)
  (dt)*(1/C)*(-gNa*minf(V)^3*(0.85-n)*(V-VNa) - gKd*n^4*(V-VK) - gCaT*mCaT^3*hCaT*(V-VCa) - gNaleak*(V-VNa) - gKleak*(V-VK) + Iapp + Istep )
end

dhCaT(V::Float64,hCaT::Float64) = (dt)*((teta/tauhCaT(V))*(hCaTinf(V) - hCaT))
dn(V::Float64,n::Float64) = (dt)*((1/taun(V))*(ninf(V) - n))
dmCaT(V::Float64,mCaT::Float64) = (dt)*((1/taumCaT(V))*(mCaTinf(V) - mCaT))


dAMPA(V::Float64,AMPA::Float64) = (dt)*(1.1*Tm(V)*(1-AMPA)-0.19*AMPA)
dGABAA(V::Float64,GABAA::Float64) = (dt)*(0.53*Tm(V)*(1-GABAA)-0.18*GABAA)
dGABAB(V::Float64,GABAB::Float64) = (dt)*(0.016*Tm(V)*(1-GABAB)-0.0047*GABAB)

function simulateRUSHCA_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,TstepEinit::Int64,TstepEfinal::Int64,IstepE::Float64,TstepIinit1::Int64,TstepIinit2::Int64,TstepIinit3::Int64,TstepIinit4::Int64,TstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)


    # Synaptic Connections
  SYN = [(gEE/4)*(rand(nEcells,nEcells)-0.5*ones(nEcells, nEcells)).+gEE (gEI/4)*(rand(nEcells,nIcells)-0.5*ones(nEcells, nIcells)).+gEI;(gIE/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE (gII/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII;(gIE2/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE2 (gII2/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII2]
  #SYN = [gEE*ones(nEcells,nEcells) gEI*ones(nEcells,nIcells);gIE*ones(nIcells,nEcells) gII*ones(nIcells,nIcells);gIE2*ones(nIcells,nEcells) gII2*ones(nIcells,nIcells)]

  # Initial conditions
  V=-60*ones(ncells)
  Vprev=-60*ones(ncells)
  hCaT=hCaTinf(V[1])*ones(ncells)
  n=ninf(V[1])*ones(ncells)
  mCaT = mCaTinf(V[1])*ones(ncells)

  AMPA=zeros(ncells)
  GABAA=zeros(ncells)
  GABAB=zeros(ncells)

  VV = zeros(Tdt,ncells)
  LFP_E=zeros(Tdt)
  LFP_I=zeros(Tdt)

  # Step start and stop values
  TstartE::Int64 = convert(Int64,TstepEinit/dt)
  TstopE::Int64 = convert(Int64,TstepEfinal/dt)
  TstartI1::Int64 = convert(Int64,TstepIinit1/dt)
  TstartI2::Int64 = convert(Int64,TstepIinit2/dt)
  TstartI3::Int64 = convert(Int64,TstepIinit3/dt)
  TstartI4::Int64 = convert(Int64,TstepIinit4/dt)
  TstopI::Int64 = convert(Int64,TstepIfinal/dt)

  for z = 1:Tdt
    Isyn=zeros(ncells)

    for j = 1:ncells

      if j<=nEcells
        Iapp = IappE
        if z >= TstartE && z<= TstopE
          Iappstep = IstepE
        else
          Iappstep = 0.
        end

        V[j] += dV(C, V[j], n[j], mCaT[j], hCaT[j], Iapp, Iappstep, gNavec_E[j], gKdvec_E[j], gCaTvec_E[j], gNaleakvec_E[j], gKleakvec_E[j])
      end

      if j>nEcells && j<=ncells
        Iapp = IappI
        if z >= TstartI1 && z< TstartI2
          Iappstep = IstepI1
        elseif z >= TstartI2 && z< TstartI3
          Iappstep = IstepI2
        elseif z >= TstartI3 && z< TstartI4
          Iappstep = IstepI3
        elseif z >= TstartI4 && z< TstopI
          Iappstep = IstepI4
        else
          Iappstep = 0.
        end

        V[j] += dV(C, V[j], n[j], mCaT[j], hCaT[j], Iapp, Iappstep, gNavec_I[j], gKdvec_I[j], gCaTvec_I[j], gNaleakvec_I[j], gKleakvec_I[j])

      end

      for k = 1:nEcells
        if k!=j
          Isyn[j] += SYN[k,j]*AMPA[k]*(Vprev[j]-0)
          V[j] += (dt)*(1/C)*(-SYN[k,j]*AMPA[k]*(Vprev[j]-0))
        end
      end
      for l = nEcells+1:ncells
        if l!=j
          Isyn[j] += SYN[l,j]*GABAA[l]*(Vprev[j]+70)+SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85)
          V[j] += (dt)*(1/C)*(-SYN[l,j]*GABAA[l]*(Vprev[j]+70))
          V[j] += (dt)*(1/C)*(-SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85))
        end
      end

      n[j] += dn(V[j],n[j])
      hCaT[j] += dhCaT(V[j],hCaT[j])
      mCaT[j] += dmCaT(V[j], mCaT[j])

      AMPA[j] += dAMPA(Vprev[j],AMPA[j])
      GABAA[j] += dGABAA(Vprev[j],GABAA[j])
      GABAB[j] += dGABAB(Vprev[j],GABAB[j])

      Vprev = copy(V)
    end

    VV[z,:] = copy(V')
    LFP_E[z] = (1/nEcells).*sum(Isyn[1:nEcells])
    LFP_I[z] = (1/nIcells).*sum(Isyn[1+nEcells:ncells])

  end

  return VV, LFP_E, LFP_I
end
