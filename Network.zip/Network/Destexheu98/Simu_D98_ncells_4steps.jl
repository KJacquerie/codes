# Defines output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include model
include("D98_ncells_4steps.jl")


# Simulation parameters
const T = 4000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,401/dt)
const t = range(dt,T,length=Tdt)
const gamma=0.

# Single-cell
const C= 0.88 # nF
const VNa = 50
const Vleak= -70
const VCa = 120
const Vtraub=-52.
const VK = -100

const gNa_E = 100.
const gNaleak_E = 0
const gK_E = 100.
const gKleak_E = 0
const gleak_E= 5e-2
const gCa_E=3.3

const gNa_I = 100.
const gNaleak_I = 0
const gK_I = 100.
const gKleak_I = 0
const gleak_I= 5e-2
const gCa_I=3.3


# Network
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

const gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaleakvec_E = gNaleak_E .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKvec_E = gK_E .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKleakvec_E = gKleak_E .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gleakvec_E = gleak_E .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gCavec_E = gCa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))


const gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaleakvec_I = gNaleak_I .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKvec_I = gK_I .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKleakvec_I = gKleak_I .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gleakvec_I = gleak_I .*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gCavec_I = gCa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

# Excitation
const IappE = 0.0
const IstepE = 0.
const tstepEinit = 2500
const tstepEfinal = 2503
const IappI = 1.5
const IstepI1 = -3.2
const IstepI2 = -3.2
const IstepI3 = -3.2
const IstepI4 = -3.2
const tstepIinit1 = 2000
const tstepIinit2 = 4000
const tstepIinit3 = 6000
const tstepIinit4 = 8000
const tstepIfinal = copy(T)

#Synaptic connexion
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.2/nIcells
const gIEGABAB = 1.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells


# Launch Simulation
@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateD98_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)

Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
plot(Vplot1,Vplot2, layout=(ncells,1))
