# Defines output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include model
include("Drion_ncells_4steps.jl")


# Simulation parameters
const T = 4000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,401/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C = 1
const VNa = 50
const VK = -85
const VCa = 120
const Vl = -55
const VH = -20
const Kd = 170

# Model parameters (mean) - Ecells
const gl_E = 0.055
const gNa_E = 170
const gKd_E = 40
const k1_E = 1.e-1
const k2_E = 0.1e-1
const gH_E = 0.01
const gKCa_E = 4#/10
const gCaT_E = 0.55#/5

# Model parameters (mean) - Icells
const gl_I = 0.055
const gNa_I = 170
const gKd_I = 40
const k1_I = 1.e-1
const k2_I = 0.1e-1
const gH_I = 0.01
const gKCa_I = 4#/10
const gCaT_I = 0.55#/5

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

const gNavec_E = gNa_E*ones(ncells) #- 70*(rand(ncells)-0.5)
const gKdvec_E = gKd_E*ones(ncells) #- 40*(rand(ncells)-0.5)
const gHvec_E = gH_E*ones(ncells) #- 0.002*(rand(ncells)-0.5)
const gCaTvec_E = gCaT_E*ones(ncells) #- 0.35*(rand(ncells)-0.5)
const gKCavec_E = gKCa_E*ones(ncells) #- 2*(rand(ncells)-0.5)
const glvec_E = gl_E*ones(ncells) #- 0.015*(rand(ncells)-0.5)
const k1vec_E = k1_E*ones(ncells) #- 0.05*(rand(ncells))
const k2vec_E = k2_E*ones(ncells) #- 0.005*(rand(ncells))

const gNavec_I = gNa_I*ones(ncells) #- 70*(rand(ncells)-0.5)
const gKdvec_I = gKd_I*ones(ncells) #- 40*(rand(ncells)-0.5)
const gHvec_I = gH_I*ones(ncells) #- 0.002*(rand(ncells)-0.5)
const gCaTvec_I = gCaT_I*ones(ncells) #- 0.35*(rand(ncells)-0.5)
const gKCavec_I = gKCa_I*ones(ncells) #- 2*(rand(ncells)-0.5)
const glvec_I = gl_I*ones(ncells) #- 0.015*(rand(ncells)-0.5)
const k1vec_I = k1_I*ones(ncells) #- 0.05*(rand(ncells))
const k2vec_I = k2_I*ones(ncells) #- 0.005*(rand(ncells))

#simulateTOY_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)
const IappE = 0.
const IstepE = 0.
const tstepEinit = 4500
const tstepEfinal = 4503
const IappI = 1.
const IstepI1 = -3.6
const IstepI2 = -3.6
const IstepI3 = -3.6
const IstepI4 = -3.6
const tstepIinit1 = 2000
const tstepIinit2 = 4000
const tstepIinit3 = 6000
const tstepIinit4 = T
const tstepIfinal = copy(T)

# connectivity
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells #2 for 5 cells
const gIIGABAB = 0.0/nIcells #1 for 5 cells

# RUN MODEL
@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateTOY_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)


#=
responsetype = Lowpass(100; fs=1000/(dt))
designmethod = Butterworth(4)
LFPconnect_E_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_E)
LFPconnect_I_filt = filt(digitalfilter(responsetype, designmethod), LFPconnect_I)
LFPconnectinf_E_filt = filt(digitalfilter(responsetype, designmethod), LFPconnectinf_E)
LFPconnectinf_I_filt = filt(digitalfilter(responsetype, designmethod), LFPconnectinf_I)
=#

Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
cd("/Users/kathleen/Documents/PhD/2020-Project/Network/Drion/V/")
writedlm("V_ko.dat", Vconnect, header = false)
writedlm("t_ko.dat", t, header = false)

plot(Vplot1,Vplot2, layout=(ncells,1))
