# Defines output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include model
include("RUSH_ncells_4steps.jl")



# Simulation parameters
const T = 7000
const dt = 0.005
const Ttransient = 401
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)
const gamma=0.0
# Model parameters (global)
const C = 1.

const VNa = 55.
const VK = -85.
const VCa = 120.
const tetas= -63
const ks= -7.8
const tetah = -72.
const kh = 1.1
const sigm = 10.3
const sign = 9.3
const teta = 1

# Model parameters (mean) - Ecells
const gNa_E = 120.
const gKd_E = 10.
const gNaleak_E = 0.01429
const gKleak_E = 0.08571
const gCaT_E = 0.3

# Model parameters (mean) - Icells
const gNa_I = 120.
const gKd_I = 10.
const gNaleak_I = 0.01429
const gKleak_I = 0.08571
const gCaT_I = 0.3


# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

const C_vec = C.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

const gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKdvec_E = gKd_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaleakvec_E = gNaleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKleakvec_E = gKleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gCaTvec_E = gCaT_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

const gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKdvec_I = gKd_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaleakvec_I = gNaleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKleakvec_I = gKleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gCaTvec_I = gCaT_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))


const IappE = 0.
const IstepE = 0.
const tstepEinit = 41500
const tstepEfinal = 41503
const IappI = 15.
const IstepI1 = -16.2
const IstepI2 = -16.2
const IstepI3 = -16.2
const IstepI4 = -16.2
const tstepIinit1 = 2000
const tstepIinit2 = 4000
const tstepIinit3 = 6000
const tstepIinit4 = 8000
const tstepIfinal = copy(T)

# Synaptic connections
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1/nEcells
const gIEGABAA = 0.4/nIcells
const gIEGABAB = 2.0/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

# Launch Simulation
@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateRUSH_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)


Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
plot(Vplot1,Vplot2, layout=(ncells,1))
