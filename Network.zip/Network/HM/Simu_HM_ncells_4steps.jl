# Define output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include model
include("HM_ncells_4steps.jl")

# Simulation parameters
const T = 4000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,401/dt)
const t = range(dt,T,length=Tdt)

const gamma=0.0

# Model parameters (global)
const C= 0.29
const VNa = 45
const VCa = 120
const VK = -105

# Model parameters - Ecells
const gNa_E = 12.
const gNap_E = 7.e-3
const gNaleak_E = 2.65e-3
const gA_E = 20.e-3
const gA2_E = 15.e-3
const gKleak_E = 7.e-3
const gK2a_E = 38.e-3
const gK2b_E = 26.e-3
const gc_E = 1.
const gL_E = 0.8
const gT_E= 1.

# Model parameters - Icells
const gNa_I = 12.
const gNap_I = 7.e-3
const gNaleak_I = 2.65e-3
const gA_I = 20.e-3
const gA2_I = 15.e-3
const gKleak_I = 7.e-3
const gK2a_I = 38.e-3
const gK2b_I = 26.e-3
const gc_I = 1.
const gL_I = 0.8
const gT_I= 1.

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells


const gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNapvec_E = gNap_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaleakvec_E = gNaleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gAvec_E = gA_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gA2vec_E = gA2_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKleakvec_E = gKleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gK2avec_E = gK2a_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gK2bvec_E = gK2b_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gcvec_E = gc_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gLvec_E = gL_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gTvec_E = gT_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

const gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNapvec_I = gNap_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gNaleakvec_I = gNaleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gAvec_I = gA_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gA2vec_I = gA2_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gKleakvec_I = gKleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gK2avec_I = gK2a_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gK2bvec_I = gK2b_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gcvec_I = gc_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gLvec_I = gL_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
const gTvec_I = gT_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))


# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 4500
const tstepEfinal = 4503
const IappI = 1.
const IstepI1 = -1.
const IstepI2 = -1.
const IstepI3 = -1.
const IstepI4 = -1.
const tstepIinit1 = 2000
const tstepIinit2 = 4000
const tstepIinit3 = 6000
const tstepIinit4 = T
const tstepIfinal = copy(T)

#Synaptic connexion
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.01/nEcells
const gIEGABAA = 0.04/nIcells # 0.4e-3
const gIEGABAB = .01/nIcells # 2e-3
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells


# Launch Simulation
@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateHM_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)


Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
plot(Vplot1,Vplot2, layout=(ncells,1))
