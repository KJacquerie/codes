# Define output directory
#save filename

file_name = "HM"
test_name = "gamma"
const gamma_mat = [0. 0.1 0.2 0.3 0.4 0.5]

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView
using Printf

# Include model
include("HM_ncells_spk_gamma.jl")
include("HM_PARAMS_4steps.jl")

# Simulation parameters
const T = 82000
const dt = 0.01
const Tdt = convert(Int64,T/dt)
const Ttransient = 1001
const Tlow = convert(Int64,Ttransient/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C= 0.29 #nF
const VNa = 45
const VCa = 120
const VK = -105

# Model parameters - Ecells
const gNa_E = 12.
const gNap_E = 7.e-3
const gNaleak_E = 2.65e-3
const gA_E = 20.e-3
const gA2_E = 15.e-3
const gKleak_E = 7.e-3
const gK2a_E = 38.e-3
const gK2b_E = 26.e-3
const gc_E = 1.
const gL_E = 0.8
const gT_E= 1.

# Model parameters - Icells
const gNa_I = 12.
const gNap_I = 7.e-3
const gNaleak_I = 2.65e-3
const gA_I = 20.e-3
const gA2_I = 15.e-3
const gKleak_I = 7.e-3
const gK2a_I = 38.e-3
const gK2b_I = 26.e-3
const gc_I = 1.
const gL_I = 0.8
const gT_I= 1.

# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells


# Excitation
const IappE = 0.
const IstepE = 0.
const tstepEinit = 41500
const tstepEfinal = 41503
const IappI = 1.
const IstepI1 = -1.
const IstepI2 = -1.
const IstepI3 = -1.
const IstepI4 = -1.
const tstepIinit1 = 41000
const tstepIinit2 = copy(T)
const tstepIinit3 =  copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)

#Synaptic connexion
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.01/nEcells
const gIEGABAA = 0.04/nIcells
const gIEGABAB = .01/nIcells
const gIIGABAA = 0.0/nIcells
const gIIGABAB = 0.0/nIcells

const n_net =1000

for i=1:length(gamma_mat)
    gamma = gamma_mat[i]
    println("gamma=",gamma)
    cd(@sprintf("/Users/kathleen/Documents/PhD/2020-Project/Network/%s/Results_GAMMA/gamma%d/",file_name,gamma*100))

    # Functions
    function simu_networks_2cells_HM(n_net::Int64,ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,tstepEinit::Int64,tstepEfinal::Int64,IstepE::Float64,tstepIinit1::Int64,tstepIinit2::Int64,tstepIinit3::Int64,tstepIinit4::Int64,tstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEEAMPA::Float64,gEIAMPA::Float64,gIEGABAA::Float64,gIIGABAA::Float64,gIEGABAB::Float64,gIIGABAB::Float64)
        SPB_depol1 = zeros(ncells,n_net)
        SPB_hyperpol1 = zeros(ncells,n_net)
        PER_depol1 = zeros(ncells,n_net)
        PER_hyperpol1 = zeros(ncells,n_net)
        DC_depol1 = zeros(ncells,n_net)
        DC_hyperpol1 = zeros(ncells,n_net)
        IBF_depol1 = zeros(ncells,n_net)
        IBF_hyperpol1 = zeros(ncells,n_net)
        freq_depol_vec1 = zeros(ncells,n_net)
        freq_hyperpol_vec1 = zeros(ncells,n_net)

        SPB_depol2 = zeros(ncells,n_net)
        SPB_hyperpol2 = zeros(ncells,n_net)
        PER_depol2 = zeros(ncells,n_net)
        PER_hyperpol2 = zeros(ncells,n_net)
        DC_depol2 = zeros(ncells,n_net)
        DC_hyperpol2 = zeros(ncells,n_net)
        IBF_depol2 = zeros(ncells,n_net)
        IBF_hyperpol2 = zeros(ncells,n_net)
        freq_depol_vec2 = zeros(ncells,n_net)
        freq_hyperpol_vec2 = zeros(ncells,n_net)

        SPB_depol3 = zeros(ncells,n_net)
        SPB_hyperpol3 = zeros(ncells,n_net)
        PER_depol3 = zeros(ncells,n_net)
        PER_hyperpol3 = zeros(ncells,n_net)
        DC_depol3 = zeros(ncells,n_net)
        DC_hyperpol3 = zeros(ncells,n_net)
        IBF_depol3 = zeros(ncells,n_net)
        IBF_hyperpol3 = zeros(ncells,n_net)
        freq_depol_vec3 = zeros(ncells,n_net)
        freq_hyperpol_vec3 = zeros(ncells,n_net)

        SPB_depol4 = zeros(ncells,n_net)
        SPB_hyperpol4 = zeros(ncells,n_net)
        PER_depol4 = zeros(ncells,n_net)
        PER_hyperpol4 = zeros(ncells,n_net)
        DC_depol4 = zeros(ncells,n_net)
        DC_hyperpol4 = zeros(ncells,n_net)
        IBF_depol4 = zeros(ncells,n_net)
        IBF_hyperpol4 = zeros(ncells,n_net)
        freq_depol_vec4 = zeros(ncells,n_net)
        freq_hyperpol_vec4 = zeros(ncells,n_net)

        for j=1:n_net
          println(n_net-j)
          C_vec = C.*ones(ncells)

          gNavec_E = gNa_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gNapvec_E = gNap_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gNaleakvec_E = gNaleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gAvec_E = gA_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gA2vec_E = gA2_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gKleakvec_E = gKleak_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gK2avec_E = gK2a_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gK2bvec_E = gK2b_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gcvec_E = gc_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gLvec_E = gL_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gTvec_E = gT_E.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

          gNavec_I = gNa_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gNapvec_I = gNap_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gNaleakvec_I = gNaleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gAvec_I = gA_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gA2vec_I = gA2_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gKleakvec_I = gKleak_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gK2avec_I = gK2a_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gK2bvec_I = gK2b_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gcvec_I = gc_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gLvec_I = gL_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))
          gTvec_I = gT_I.*(ones(ncells)-2*gamma*(rand(ncells)-0.5*ones(ncells)))

          Vconnect_spk = simulateHM_ncells_spk(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB,gNavec_E, gNapvec_E, gK2avec_E, gK2bvec_E, gcvec_E, gTvec_E, gLvec_E, gAvec_E, gA2vec_E, gNaleakvec_E, gKleakvec_E, gNavec_I, gNapvec_I, gK2avec_I, gK2bvec_I, gcvec_I, gTvec_I, gLvec_I, gAvec_I, gA2vec_I, gNaleakvec_I, gKleakvec_I, C_vec)
          (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit1,tstepIinit2)
          SPB_depol1[:,j] = PARAMS_depol[:,1]
          SPB_hyperpol1[:,j] = PARAMS_hyperpol[:,1]
          PER_depol1[:,j] = PARAMS_depol[:,2]
          PER_hyperpol1[:,j] = PARAMS_hyperpol[:,2]
          DC_depol1[:,j] = PARAMS_depol[:,3]
          DC_hyperpol1[:,j] = PARAMS_hyperpol[:,3]
          IBF_depol1[:,j] = PARAMS_depol[:,4]
          IBF_hyperpol1[:,j] = PARAMS_hyperpol[:,4]
          freq_depol_vec1[:,j] = freq_depol
          freq_hyperpol_vec1[:,j] = freq_hyperpol

          (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit2,tstepIinit3)
          SPB_depol2[:,j] = PARAMS_depol[:,1]
          SPB_hyperpol2[:,j] = PARAMS_hyperpol[:,1]
          PER_depol2[:,j] = PARAMS_depol[:,2]
          PER_hyperpol2[:,j] = PARAMS_hyperpol[:,2]
          DC_depol2[:,j] = PARAMS_depol[:,3]
          DC_hyperpol2[:,j] = PARAMS_hyperpol[:,3]
          IBF_depol2[:,j] = PARAMS_depol[:,4]
          IBF_hyperpol2[:,j] = PARAMS_hyperpol[:,4]
          freq_depol_vec2[:,j] = freq_depol
          freq_hyperpol_vec2[:,j] = freq_hyperpol

          (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit3,tstepIinit4)
          SPB_depol3[:,j] = PARAMS_depol[:,1]
          SPB_hyperpol3[:,j] = PARAMS_hyperpol[:,1]
          PER_depol3[:,j] = PARAMS_depol[:,2]
          PER_hyperpol3[:,j] = PARAMS_hyperpol[:,2]
          DC_depol3[:,j] = PARAMS_depol[:,3]
          DC_hyperpol3[:,j] = PARAMS_hyperpol[:,3]
          IBF_depol3[:,j] = PARAMS_depol[:,4]
          IBF_hyperpol3[:,j] = PARAMS_hyperpol[:,4]
          freq_depol_vec3[:,j] = freq_depol
          freq_hyperpol_vec3[:,j] = freq_hyperpol

          (ISIs_depol, ISIs_hyperpol, PARAMS_depol, PARAMS_hyperpol, freq_depol, freq_hyperpol) = compute_params(Vconnect_spk,Ttransient,tstepIinit1,tstepIinit4,tstepIfinal)
          SPB_depol4[:,j] = PARAMS_depol[:,1]
          SPB_hyperpol4[:,j] = PARAMS_hyperpol[:,1]
          PER_depol4[:,j] = PARAMS_depol[:,2]
          PER_hyperpol4[:,j] = PARAMS_hyperpol[:,2]
          DC_depol4[:,j] = PARAMS_depol[:,3]
          DC_hyperpol4[:,j] = PARAMS_hyperpol[:,3]
          IBF_depol4[:,j] = PARAMS_depol[:,4]
          IBF_hyperpol4[:,j] = PARAMS_hyperpol[:,4]
          freq_depol_vec4[:,j] = freq_depol
          freq_hyperpol_vec4[:,j] = freq_hyperpol


        end
        return (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1, SPB_depol2, SPB_hyperpol2, PER_depol2, PER_hyperpol2, DC_depol2, DC_hyperpol2, IBF_depol2, IBF_hyperpol2, freq_depol_vec2, freq_hyperpol_vec2, SPB_depol3, SPB_hyperpol3, PER_depol3, PER_hyperpol3, DC_depol3, DC_hyperpol3, IBF_depol3, IBF_hyperpol3, freq_depol_vec3, freq_hyperpol_vec3, SPB_depol4, SPB_hyperpol4, PER_depol4, PER_hyperpol4, DC_depol4, DC_hyperpol4, IBF_depol4, IBF_hyperpol4, freq_depol_vec4, freq_hyperpol_vec4)

    end

    @time (SPB_depol1, SPB_hyperpol1, PER_depol1, PER_hyperpol1, DC_depol1, DC_hyperpol1, IBF_depol1, IBF_hyperpol1, freq_depol_vec1, freq_hyperpol_vec1, SPB_depol2, SPB_hyperpol2, PER_depol2, PER_hyperpol2, DC_depol2, DC_hyperpol2, IBF_depol2, IBF_hyperpol2, freq_depol_vec2, freq_hyperpol_vec2, SPB_depol3, SPB_hyperpol3, PER_depol3, PER_hyperpol3, DC_depol3, DC_hyperpol3, IBF_depol3, IBF_hyperpol3, freq_depol_vec3, freq_hyperpol_vec3, SPB_depol4, SPB_hyperpol4, PER_depol4, PER_hyperpol4, DC_depol4, DC_hyperpol4, IBF_depol4, IBF_hyperpol4, freq_depol_vec4, freq_hyperpol_vec4) = simu_networks_2cells_HM(n_net,ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)



    writedlm("SPB_depol1.dat", SPB_depol1, header = false)
    writedlm("SPB_hyperpol1.dat", SPB_hyperpol1, header = false)
    writedlm("PER_depol1.dat", PER_depol1, header = false)
    writedlm("PER_hyperpol1.dat", PER_hyperpol1, header = false)
    writedlm("DC_depol1.dat", DC_depol1, header = false)
    writedlm("DC_hyperpol1.dat", DC_hyperpol1, header = false)
    writedlm("IBF_depol1.dat", IBF_depol1, header = false)
    writedlm("IBF_hyperpol1.dat", IBF_hyperpol1, header = false)
    writedlm("freq_depol1.dat", freq_depol_vec1, header = false)
    writedlm("freq_hyperpol1.dat", freq_hyperpol_vec1, header = false)

    writedlm("SPB_depol2.dat", SPB_depol2, header = false)
    writedlm("SPB_hyperpol2.dat", SPB_hyperpol2, header = false)
    writedlm("PER_depol2.dat", PER_depol2, header = false)
    writedlm("PER_hyperpol2.dat", PER_hyperpol2, header = false)
    writedlm("DC_depol2.dat", DC_depol2, header = false)
    writedlm("DC_hyperpol2.dat", DC_hyperpol2, header = false)
    writedlm("IBF_depol2.dat", IBF_depol2, header = false)
    writedlm("IBF_hyperpol2.dat", IBF_hyperpol2, header = false)
    writedlm("freq_depol2.dat", freq_depol_vec2, header = false)
    writedlm("freq_hyperpol2.dat", freq_hyperpol_vec2, header = false)

    writedlm("SPB_depol3.dat", SPB_depol3, header = false)
    writedlm("SPB_hyperpol3.dat", SPB_hyperpol3, header = false)
    writedlm("PER_depol3.dat", PER_depol3, header = false)
    writedlm("PER_hyperpol3.dat", PER_hyperpol3, header = false)
    writedlm("DC_depol3.dat", DC_depol3, header = false)
    writedlm("DC_hyperpol3.dat", DC_hyperpol3, header = false)
    writedlm("IBF_depol3.dat", IBF_depol3, header = false)
    writedlm("IBF_hyperpol3.dat", IBF_hyperpol3, header = false)
    writedlm("freq_depol3.dat", freq_depol_vec3, header = false)
    writedlm("freq_hyperpol3.dat", freq_hyperpol_vec3, header = false)

    writedlm("SPB_depol4.dat", SPB_depol4, header = false)
    writedlm("SPB_hyperpol4.dat", SPB_hyperpol4, header = false)
    writedlm("PER_depol4.dat", PER_depol4, header = false)
    writedlm("PER_hyperpol4.dat", PER_hyperpol4, header = false)
    writedlm("DC_depol4.dat", DC_depol4, header = false)
    writedlm("DC_hyperpol4.dat", DC_hyperpol4, header = false)
    writedlm("IBF_depol4.dat", IBF_depol4, header = false)
    writedlm("IBF_hyperpol4.dat", IBF_hyperpol4, header = false)
    writedlm("freq_depol4.dat", freq_depol_vec4, header = false)
    writedlm("freq_hyperpol4.dat", freq_hyperpol_vec4, header = false)

end
