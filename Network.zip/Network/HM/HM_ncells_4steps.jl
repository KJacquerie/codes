# gating functions

# sodium activation
alpha_m(V::Float64) = 0.091*(V+38)/(1-exp(-(V+38)/5))
beta_m(V::Float64) = -0.062*(V+38)/(1-exp((V+38)/5))
m_inf(V::Float64) = alpha_m(V) / (alpha_m(V) + beta_m(V))
tau_m(V::Float64) = 1 / (alpha_m(V) + beta_m(V))

# sodium inactivation
alpha_h(V::Float64) = 0.016*exp((-55-V)/15)
beta_h(V::Float64) = 2.07/(exp((17-V)/21)+1)
h_inf(V::Float64) = alpha_h(V) / (alpha_h(V) + beta_h(V))
tau_h(V::Float64) = 1 / (alpha_h(V) + beta_h(V))

# NaP
alpha_mp(V::Float64) = 0.091*(V+38)/(1-exp(-(V+38)/5))
beta_mp(V::Float64) = -0.062*(V+38)/(1-exp((V+38)/5))
mp_inf(V::Float64) = 1/(1+exp((-49-V)/5)) # c'est normal ici que alpha et beta n'apparaissent pas ?
tau_mp(V::Float64) = 1 / (alpha_mp(V) + beta_mp(V))

# A activation
mA_inf(V::Float64) = 1/(1+exp(-(V+60)/8.5))
tau_mA(V::Float64) = 0.37 + 1/(exp((V+35.82)/19.697)+exp((V+79.69)/-12.7))


# A inactivation
hA_inf(V::Float64) = 1/(1+exp((V+78)/6))
function tau_hA(V::Float64)
    if V < -63
        tau_hA = 1/(exp((V+46.05)/5)+exp((V+238.4)/-37.45))
    else
        tau_hA = 19
    end
    return tau_hA
end

# CALCIUM T-type activation
mt_inf(V::Float64) = 1/(1+exp(-(V+57)/6.2))
tau_mt(V::Float64) = 0.612 + 1/(exp(-(V+131.6)/16.7)+exp((V+16.8)/18.2))

# CALCIUM T-Type inactivation
ht_inf(V::Float64) = 1/(1+exp((V+81)/4.03))
function tau_ht(V::Float64)
    if V < -80
        tau_ht = exp((V+467)/66.6)
    else
        tau_ht = exp(-(V+21.88)/10.2)+28
    end
    return tau_ht
end

# Potassium activation
mK2_inf(V::Float64) = 1/(1+exp((V+43)/-17))
tau_mK2(V::Float64) = 1/(exp((V-81)/25.6)+exp((V+132)/-18)) + 9.9

#Potassium inactivation type A
hK2a_inf(V::Float64) = 1/(1+exp((V+58)/10.6))
tau_hK2a(V::Float64) = 1/(exp((V-1.329)/200)+exp((V+130)/-7.1))+120

#Potassium inactivation type B
hK2b_inf(V::Float64) = 1/(1+exp((V+58)/10.6))
function tau_hK2b(V::Float64)
    if V < -70
        tau_hK2b = 1/(exp((V-1.329)/200)+exp((V+130)/-7.1))+120
    else
        tau_hK2b = 8.9
    end
    return tau_hK2b
end


# C-type Potassium
alpha_mc(V::Float64, CaL::Float64) = 2500*CaL*exp(V/24)
beta_mc(V::Float64) = 0.1*exp(-V/24)
mc_inf(V::Float64, CaL::Float64) = alpha_mc(V, CaL) / (alpha_mc(V, CaL) + beta_mc(V))
tau_mc(V::Float64, CaL::Float64) = 1 / (alpha_mc(V, CaL) + beta_mc(V))

# L-Type calcium
alpha_ml(V::Float64) = 1.6/(1+exp(-0.072*(V-5)))
beta_ml(V::Float64) = 0.02*(V-1.31)/(exp((V-1.31)/5.36)-1)
ml_inf(V::Float64) = alpha_ml(V) / (alpha_ml(V) + beta_ml(V))
tau_ml(V::Float64) = 1 / (alpha_ml(V) + beta_ml(V))

# potassium type A2 activation
mA2_inf(V::Float64) = 1/(1+exp(-(V+36)/20))
tau_mA2(V::Float64) = 0.37 + 1/(exp((V+35.82)/19.697)+exp((V+79.69)/-12.7))
#=
function tau_mA2(V::Float64)
    if V < -63
        tau_mA2 = 0.37 + 1/(exp((V+35.82)/19.697)+exp((V+79.69)/-12.7))
    else
        tau_mA2 = 19
    end
    return tau_mA2
end
=#


# potassium type A2 inactivation
hA2_inf(V::Float64) = 1/(1+exp((V+78)/6))
function tau_hA2(V::Float64)
    if V < -73
        tau_hA2 = 1/(exp((V+46.05)/5)+exp((V+238.4)/-37.45))
    else
        tau_hA2 = 60
    end
    return tau_hA2
end

# GHK equation of the IT calcium current
#=
function ITGHK(V::Float64, Ca::Float64)
    z = 2
    F = 96485.3399e-3
    R = 8.314
    T = 310
    Cao = 2e-3

    G = ((z^2*F^2*V)/(R*T))*((Ca-(Cao*exp(-(z*F*V)/(R*T))))/(1-exp(-(z*F*V)/(R*T))))
    return G
end
=#

## DIFFERENTIAL EQUATIONS FOR THE 17 VARIABLES
function dV_HM(V::Float64, m::Float64, h::Float64, mp::Float64, mK2::Float64, hK2a::Float64, hK2b::Float64, mc::Float64, mt::Float64, ht::Float64, ml::Float64, mA::Float64, hA::Float64, mA2::Float64, hA2::Float64, Iapp::Float64, Istep::Float64, gNa::Float64, gNap::Float64, gK2a::Float64, gK2b::Float64, gc::Float64, gT::Float64, gL::Float64, gA::Float64, gA2::Float64, gNaleak::Float64, gKleak::Float64)
(dt)*(1/C)*(-gNa*m^3*h*(V-VNa) - gNap*mp*(V-VNa) - gK2a*mK2*hK2a*(V-VK) - gK2b*mK2*hK2b*(V-VK) - gc*mc*(V-VK) - gT*mt^2*ht*(V-VCa) - gL*ml^2*(V-VCa) - gA*mA^4*hA*(V-VK) - gA2*mA2^4*hA2*(V-VK) - gNaleak*(V-VNa) - gKleak*(V-VK) + Iapp + Istep)
end

dm(V::Float64, m::Float64)                 = (dt)* (1/tau_m(V)) * (m_inf(V) - m)
dh(V::Float64, h::Float64)                 = (dt)* (1/tau_h(V)) * (h_inf(V) - h)
dmp(V::Float64,mp::Float64)                = (dt)* (1/tau_mp(V)) * (mp_inf(V) - mp)
dmA(V::Float64, mA::Float64)               = (dt)* (1/tau_mA(V)) * (mA_inf(V) - mA)
dhA(V::Float64, hA::Float64)               = (dt)* (1/tau_hA(V)) * (hA_inf(V) - hA)
dmt(V::Float64, mt::Float64)               = (dt)* (1/tau_mt(V)) * (mt_inf(V) - mt)
dht(V::Float64, ht::Float64)               = (dt)* (1/tau_ht(V)) * (ht_inf(V) - ht)
dmK2(V::Float64, mK2::Float64)             = (dt)* (1/tau_mK2(V)) * (mK2_inf(V) - mK2)
dhK2a(V::Float64, hK2a::Float64)           = (dt)* (1/tau_hK2a(V)) * (hK2a_inf(V) - hK2a)
dhK2b(V::Float64, hK2b::Float64)           = (dt)* (1/tau_hK2b(V)) * (hK2b_inf(V) - hK2b)
dmc(V::Float64, mc::Float64, CaL::Float64) = (dt)* (1/tau_mc(V,CaL)) * (mc_inf(V,CaL) - mc)
dml(V::Float64, ml::Float64)               = (dt)* (1/tau_ml(V)) * (ml_inf(V) - ml)
dCaT(V::Float64, mt::Float64,ht::Float64, CaT::Float64, gT::Float64) = (dt) * (((-5.18e-3*(gT*mt^2*ht*(V-VCa)))/(0.1*29000)) - CaT)  #??
dCaL(V::Float64, ml::Float64, CaL::Float64, gL::Float64) = (dt) * (((-5.18e-3*(gL*ml^2*(V-VCa)))/(0.1*29000)) - CaL); #??
dmA2(V::Float64, mA2::Float64)             = (dt)* (1/tau_mA2(V)) * (mA2_inf(V) - mA2)
dhA2(V::Float64, hA2::Float64)             = (dt)* (1/tau_hA2(V)) * (hA2_inf(V) - hA2)

dAMPA(V::Float64,AMPA::Float64) = (dt)*(1.1*Tm(V)*(1-AMPA)-0.19*AMPA)
dGABAA(V::Float64,GABAA::Float64) = (dt)*(0.53*Tm(V)*(1-GABAA)-0.18*GABAA)
dGABAB(V::Float64,GABAB::Float64) = (dt)*(0.016*Tm(V)*(1-GABAB)-0.0047*GABAB)
Tm(V::Float64) = 1/(1+exp(-(V-2)/5))

function simulateHM_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,IappE::Float64,IappI::Float64,TstepEinit::Int64,TstepEfinal::Int64,IstepE::Float64,TstepIinit1::Int64,TstepIinit2::Int64,TstepIinit3::Int64,TstepIinit4::Int64,TstepIfinal::Int64,IstepI1::Float64,IstepI2::Float64,IstepI3::Float64,IstepI4::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)

    # Synaptic Connections
  SYN = [(gEE/4)*(rand(nEcells,nEcells)-0.5*ones(nEcells, nEcells)).+gEE (gEI/4)*(rand(nEcells,nIcells)-0.5*ones(nEcells, nIcells)).+gEI;(gIE/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE (gII/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII;(gIE2/4)*(rand(nIcells,nEcells)-0.5*ones(nIcells, nEcells)).+gIE2 (gII2/4)*(rand(nIcells,nIcells)-0.5*ones(nIcells, nIcells)).+gII2]
  #SYN = [gEE*ones(nEcells,nEcells) gEI*ones(nEcells,nIcells);gIE*ones(nIcells,nEcells) gII*ones(nIcells,nIcells);gIE2*ones(nIcells,nEcells) gII2*ones(nIcells,nIcells)]


    # Initial values
    V = -60*ones(ncells)
    Vprev = -60*ones(ncells)
    CaT = 50.e-9*ones(ncells)
    CaL = 50.e-9*ones(ncells)
    m = m_inf(V[1])*ones(ncells)
    h = h_inf(V[1])*ones(ncells)
    mp = mp_inf(V[1])*ones(ncells)
    mA = mA_inf(V[1])*ones(ncells)
    hA = hA_inf(V[1])*ones(ncells)
    mt = mt_inf(V[1])*ones(ncells)
    ht = ht_inf(V[1])*ones(ncells)
    mK2 = mK2_inf(V[1])*ones(ncells)
    hK2a = hK2a_inf(V[1])*ones(ncells)
    hK2b = hK2b_inf(V[1])*ones(ncells)
    mc = mc_inf(V[1], CaL[1])*ones(ncells)
    ml = ml_inf(V[1])*ones(ncells)
    mA2 = mA2_inf(V[1])*ones(ncells)
    hA2 = hA2_inf(V[1])*ones(ncells)

    AMPA=zeros(ncells)
    GABAA=zeros(ncells)
    GABAB=zeros(ncells)

    VV = zeros(Tdt,ncells)
    LFP_E=zeros(Tdt)
    LFP_I=zeros(Tdt)

    # Step start and stop values
    TstartE::Int64 = convert(Int64,TstepEinit/dt)
    TstopE::Int64 = convert(Int64,TstepEfinal/dt)
    TstartI1::Int64 = convert(Int64,TstepIinit1/dt)
    TstartI2::Int64 = convert(Int64,TstepIinit2/dt)
    TstartI3::Int64 = convert(Int64,TstepIinit3/dt)
    TstartI4::Int64 = convert(Int64,TstepIinit4/dt)
    TstopI::Int64   = convert(Int64,TstepIfinal/dt)


    for z= 1:Tdt
        Isyn=zeros(ncells)

        for j = 1:ncells

          if j<=nEcells
            Iapp = IappE
            if z >= TstartE && z<= TstopE
              Iappstep = IstepE
            else
              Iappstep = 0.
            end

            V[j] += dV_HM(V[j], m[j], h[j], mp[j], mK2[j], hK2a[j], hK2b[j], mc[j], mt[j], ht[j], ml[j], mA[j], hA[j], mA2[j], hA2[j], Iapp, Iappstep, gNavec_E[j], gNapvec_E[j], gK2avec_E[j], gK2bvec_E[j], gcvec_E[j], gTvec_E[j], gLvec_E[j], gAvec_E[j], gA2vec_E[j], gNaleakvec_E[j], gKleakvec_E[j])
            CaT[j] += dCaT(Vprev[j],mt[j],ht[j],CaT[j], gTvec_E[j])
            CaL[j] += dCaL(Vprev[j],ml[j],CaL[j], gLvec_E[j])
         end

         if j>nEcells && j<=ncells
           Iapp = IappI
           if z >= TstartI1 && z< TstartI2
             Iappstep = IstepI1
           elseif z >= TstartI2 && z< TstartI3
             Iappstep = IstepI2
           elseif z >= TstartI3 && z< TstartI4
             Iappstep = IstepI3
           elseif z >= TstartI4 && z< TstopI
             Iappstep = IstepI4
           else
             Iappstep = 0.
           end
           V[j] += dV_HM(V[j], m[j], h[j], mp[j], mK2[j], hK2a[j], hK2b[j], mc[j], mt[j], ht[j], ml[j], mA[j], hA[j], mA2[j], hA2[j], Iapp, Iappstep, gNavec_I[j], gNapvec_I[j], gK2avec_I[j], gK2bvec_I[j], gcvec_I[j], gTvec_I[j], gLvec_I[j], gAvec_I[j], gA2vec_I[j], gNaleakvec_I[j], gKleakvec_I[j])
           CaT[j] += dCaT(Vprev[j],mt[j],ht[j],CaT[j], gTvec_I[j])
           CaL[j] += dCaL(Vprev[j],ml[j],CaL[j], gLvec_I[j])
         end

         for k = 1:nEcells
           if k!=j
             Isyn[j] += SYN[k,j]*AMPA[k]*(Vprev[j]-0)
             V[j] += (dt)*(1/C)*(-SYN[k,j]*AMPA[k]*(Vprev[j]-0))
           end
         end
         for l = nEcells+1:ncells
           if l!=j
             Isyn[j] += SYN[l,j]*GABAA[l]*(Vprev[j]+70)+SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85)
             V[j] += (dt)*(1/C)*(-SYN[l,j]*GABAA[l]*(Vprev[j]+70))
             V[j] += (dt)*(1/C)*(-SYN[l+nIcells,j]*GABAB[l]*(Vprev[j]+85))
           end
         end




        m[j] +=dm(Vprev[j],m[j])
        h[j] +=dh(Vprev[j],h[j])
        mp[j] +=dmp(Vprev[j],mp[j])
        mA[j] +=dmA(Vprev[j],mA[j])
        hA[j] +=dhA(Vprev[j],hA[j])
        mt[j] +=dmt(Vprev[j],mt[j])
        ht[j] +=dht(Vprev[j],ht[j])
        mK2[j] +=dmK2(Vprev[j],mK2[j])
        hK2a[j] +=dhK2a(Vprev[j],hK2a[j])
        hK2b[j] +=dhK2b(Vprev[j],hK2b[j])
        mc[j] +=dmc(Vprev[j],mc[j], CaL[j])
        ml[j] +=dml(Vprev[j],ml[j])
        mA2[j] += dmA2(Vprev[j],mA2[j])
        hA2[j] += dhA2(Vprev[j],hA2[j])

        AMPA[j] += dAMPA(Vprev[j],AMPA[j])
        GABAA[j] += dGABAA(Vprev[j],GABAA[j])
        GABAB[j] += dGABAB(Vprev[j],GABAB[j])


        Vprev = copy(V)
      end

      VV[z,:] = copy(V')
      LFP_E[z] = (1/nEcells).*sum(Isyn[1:nEcells])
      LFP_I[z] = (1/nIcells).*sum(Isyn[1+nEcells:ncells])

    end

    return VV, LFP_E, LFP_I
end
