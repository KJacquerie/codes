# Defines output directory

# Loads packages
using Plots
using DelimitedFiles
using Statistics
using Images, ImageView

# Include DCN model
include("DESTEXHE_ncells_4steps.jl")


# Simulation parameters
const T = 4000
const dt = 0.005
const Tdt = convert(Int64,T/dt)
const Tlow = convert(Int64,401/dt)
const t = range(dt,T,length=Tdt)

# Model parameters (global)
const C = 1e-3 # nF

const VNa = 50.
const VK = -100.
const Vleak=-82
const VCa = 120
const Vtraub=-63.

# Model parameters (mean) - Ecells
const gNa_E = 0.4
const gNaleak_E = 0.
const gKleak_E = 0.
const gleak_E= 5e-5
const gK_E = 0.08
const gCa_E = 0.006

# Model parameters (mean) - Icells
const gNa_I = 0.4
const gNaleak_I = 0.
const gKleak_I = 0.
const gleak_I= 5e-5
const gK_I = 0.08
const gCa_I = 0.006


# Simulations
const nEcells = 1 # Number of excitatory cells
const nIcells = 1 # Number of inhibitory cells
const ncells = nEcells+nIcells

const C_vec = C*ones(ncells)

const gNavec_E = gNa_E*ones(ncells)
const gNaleakvec_E = gNaleak_E*ones(ncells)
const gKleakvec_E = gKleak_E*ones(ncells)
const gleakvec_E = gleak_E*ones(ncells)
const gKvec_E = gK_E*ones(ncells)
const gCavec_E = gCa_E*ones(ncells)

const gNavec_I = gNa_I*ones(ncells)
const gNaleakvec_I = gNaleak_I*ones(ncells)
const gKleakvec_I = gKleak_I*ones(ncells)
const gleakvec_I= gleak_I*ones(ncells)
const gKvec_I = gK_I*ones(ncells)
const gCavec_I = gCa_I*ones(ncells)

#simulateTOY_ncells(ncells::Int64,nEcells::Int64,nIcells::Int64,Iapp::Float64,Tstepinit::Int64,Tstepfinal::Int64,Istep::Float64,gEE::Float64,gEI::Float64,gIE::Float64,gII::Float64,gIE2::Float64,gII2::Float64)
const IappE = 0.1e-3
const IstepE = 0.
const tstepEinit = 2150
const tstepEfinal = 41503
const IappI = 0.4e-3
const IstepI1 = -0.7e-3
const IstepI2 = -0.7e-3
const IstepI3 = -0.7e-3
const IstepI4 = -0.7e-3
const tstepIinit1 = 2100
const tstepIinit2 = copy(T)
const tstepIinit3 = copy(T)
const tstepIinit4 = copy(T)
const tstepIfinal = copy(T)


# connectivity
const gEEAMPA = 0.0/nEcells
const gEIAMPA = 0.1e-3/nEcells
const gIEGABAA = 0.2e-3/nIcells
const gIEGABAB = 1.e-3/nIcells
const gIIGABAA = 0.0/nIcells #2 for 5 cells
const gIIGABAB = 0.0/nIcells #1 for 5 cells


@time (Vconnect, LFPconnect_E, LFPconnect_I) = simulateDESTEXHE_ncells(ncells,nEcells,nIcells,IappE,IappI,tstepEinit,tstepEfinal,IstepE,tstepIinit1,tstepIinit2,tstepIinit3,tstepIinit4,tstepIfinal,IstepI1,IstepI2,IstepI3,IstepI4,gEEAMPA,gEIAMPA,gIEGABAA,gIIGABAA,gIEGABAB,gIIGABAB)


Vplot1 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,1:nEcells], color="blue")
Vplot2 = plot(t[Tlow:Tdt],Vconnect[Tlow:Tdt,nEcells+1:ncells], color="red")
plot(Vplot1,Vplot2, layout=(ncells,1))
